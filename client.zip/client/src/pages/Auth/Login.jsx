import React, { useState, useContext, useEffect } from 'react';
import { Link as RouterLink, useNavigate } from 'react-router-dom';
import {
  Button,
  TextField,
  Link,
  Grid,
  Box,
  Typography,
  Container,
  Alert,
  Paper,
  InputAdornment,
  IconButton,
  useMediaQuery,
  Slide,
  CircularProgress
} from '@mui/material';
import { useTheme } from '@mui/material/styles';
import {
  Person as PersonIcon,
  Visibility,
  VisibilityOff,
  ChevronRight as ChevronRightIcon
} from '@mui/icons-material';
import { AuthContext } from '../../context/AuthContext';

export default function Login() {
  const { login, error, clearErrors, isAuthenticated } = useContext(AuthContext);
  const navigate = useNavigate();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  
  const [showPassword, setShowPassword] = useState(false);
  const [localError, setLocalError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  // Redirect if user is already authenticated
  useEffect(() => {
    if (isAuthenticated) {
      navigate('/');
    }
  }, [isAuthenticated, navigate]);
  
  const { email, password } = formData;
  
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    setLocalError('');
    if (error) clearErrors();
  };
  
  const toggleShowPassword = () => {
    setShowPassword(!showPassword);
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Simple validation
    if (!email || !password) {
      setLocalError('Please fill in all fields');
      return;
    }
    
    // Show loading state
    setIsLoading(true);
    
    // Attempt login
    const success = await login({ email, password });
    setIsLoading(false);
    
    if (success) {
      navigate('/');
    }
  };
  
  return (
    <Container component="main" maxWidth="xs" sx={{ pt: isMobile ? 8 : 12, pb: 8 }}>
      <Slide direction="up" in={true} mountOnEnter unmountOnExit>
        <Paper
          elevation={0}
          className="ios-shadow"
          sx={{
            p: 4,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            borderRadius: 4,
            overflow: 'hidden',
            backgroundColor: 'white'
          }}
        >
          <Box 
            sx={{
              mb: 4, 
              width: 80, 
              height: 80, 
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              borderRadius: '50%',
              background: 'linear-gradient(45deg, #007AFF, #5AC8FA)',
              color: 'white',
              boxShadow: '0 10px 20px rgba(0, 122, 255, 0.2)'
            }}
          >
            <PersonIcon sx={{ fontSize: 40 }} />
          </Box>
          
          <Typography 
            component="h1" 
            variant="h4" 
            sx={{ 
              fontWeight: 700, 
              mb: 1, 
              textAlign: 'center',
              background: 'linear-gradient(45deg, #007AFF, #5AC8FA)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent'
            }}
          >
            Welcome Back
          </Typography>
          
          <Typography 
            variant="body1" 
            color="text.secondary" 
            sx={{ mb: 4, textAlign: 'center' }}
          >
            Sign in to continue to FinTools
          </Typography>
          
          {(error || localError) && (
            <Alert 
              severity="error" 
              sx={{ 
                width: '100%', 
                mb: 3,
                borderRadius: 3,
                border: '1px solid rgba(255, 59, 48, 0.1)',
                '& .MuiAlert-icon': {
                  color: theme.palette.error.main
                }
              }}
            >
              {error || localError}
            </Alert>
          )}
          
          <Box component="form" onSubmit={handleSubmit} noValidate sx={{ width: '100%' }}>
            <TextField
              margin="normal"
              required
              fullWidth
              id="email"
              label="Email Address"
              name="email"
              autoComplete="email"
              autoFocus
              value={email}
              onChange={handleChange}
              sx={{
                mb: 2,
                '& .MuiOutlinedInput-root': {
                  borderRadius: 3
                }
              }}
            />
            <TextField
              margin="normal"
              required
              fullWidth
              name="password"
              label="Password"
              type={showPassword ? 'text' : 'password'}
              id="password"
              autoComplete="current-password"
              value={password}
              onChange={handleChange}
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton
                      aria-label="toggle password visibility"
                      onClick={toggleShowPassword}
                      edge="end"
                    >
                      {showPassword ? <VisibilityOff /> : <Visibility />}
                    </IconButton>
                  </InputAdornment>
                ),
              }}
              sx={{
                mb: 3,
                '& .MuiOutlinedInput-root': {
                  borderRadius: 3
                }
              }}
            />
            <Button
              type="submit"
              fullWidth
              variant="contained"
              disabled={isLoading}
              sx={{ 
                mt: 2, 
                mb: 3, 
                py: 1.5,
                borderRadius: 3,
                fontSize: '1rem',
                fontWeight: 600,
                boxShadow: '0 4px 10px rgba(0, 122, 255, 0.3)',
                position: 'relative',
                overflow: 'hidden',
                '&::after': {
                  content: '""',
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  width: '100%',
                  height: '100%',
                  background: 'linear-gradient(rgba(255, 255, 255, 0.15), rgba(255, 255, 255, 0))',
                  zIndex: 1
                }
              }}
            >
              {isLoading ? 'Signing in...' : 'Sign In'}
            </Button>
            
            <Grid container justifyContent="center" alignItems="center" sx={{ mt: 2 }}>
              <Grid item>
                <Link 
                  component={RouterLink} 
                  to="/register" 
                  variant="body2"
                  sx={{ 
                    display: 'flex',
                    alignItems: 'center',
                    color: theme.palette.primary.main,
                    textDecoration: 'none',
                    fontWeight: 500,
                    '&:hover': {
                      textDecoration: 'none',
                    }
                  }}
                >
                  Don't have an account? Create one 
                  <ChevronRightIcon sx={{ ml: 0.5, fontSize: '1rem' }} />
                </Link>
              </Grid>
            </Grid>
          </Box>
        </Paper>
      </Slide>
      <Typography 
        variant="body2" 
        color="text.secondary" 
        align="center" 
        sx={{ mt: 4 }}
      >
        FinTools • Financial Management Application
      </Typography>
    </Container>
  );
} 