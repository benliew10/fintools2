import React, { useState, useContext } from 'react';
import { Link as RouterLink, useNavigate } from 'react-router-dom';
import {
  Button,
  TextField,
  Link,
  Grid,
  Box,
  Typography,
  Container,
  Alert,
  Paper,
  InputAdornment,
  IconButton,
  useMediaQuery,
  Slide,
  Stepper,
  Step,
  StepLabel
} from '@mui/material';
import { useTheme } from '@mui/material/styles';
import {
  AccountCircle as AccountCircleIcon,
  Visibility,
  VisibilityOff,
  ChevronRight as ChevronRightIcon,
  ArrowBack as ArrowBackIcon,
  Email as EmailIcon,
  Lock as LockIcon
} from '@mui/icons-material';
import { AuthContext } from '../../context/AuthContext';

export default function Register() {
  const { register, error, clearErrors } = useContext(AuthContext);
  const navigate = useNavigate();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  
  const [showPassword, setShowPassword] = useState(false);
  const [localError, setLocalError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [activeStep, setActiveStep] = useState(0);
  
  const { name, email, password, confirmPassword } = formData;
  
  const steps = ['Personal Info', 'Security'];
  
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    setLocalError('');
    if (error) clearErrors();
  };
  
  const toggleShowPassword = () => {
    setShowPassword(!showPassword);
  };
  
  const handleNext = () => {
    if (activeStep === 0) {
      if (!name || !email) {
        setLocalError('Please fill in all fields');
        return;
      }
      
      // Validate email format
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email)) {
        setLocalError('Please enter a valid email address');
        return;
      }
    }
    
    setActiveStep((prevStep) => prevStep + 1);
  };
  
  const handleBack = () => {
    setActiveStep((prevStep) => prevStep - 1);
    setLocalError('');
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Form validation
    if (!name || !email || !password || !confirmPassword) {
      setLocalError('Please fill in all fields');
      return;
    }
    
    if (password !== confirmPassword) {
      setLocalError('Passwords do not match');
      return;
    }
    
    if (password.length < 6) {
      setLocalError('Password must be at least 6 characters long');
      return;
    }
    
    // Show loading state
    setIsLoading(true);
    
    // Register user
    const success = await register({
      name,
      email,
      password
    });
    
    setIsLoading(false);
    
    if (success) {
      navigate('/');
    }
  };
  
  return (
    <Container component="main" maxWidth="xs" sx={{ pt: isMobile ? 8 : 12, pb: 8 }}>
      <Slide direction="up" in={true} mountOnEnter unmountOnExit>
        <Paper
          elevation={0}
          className="ios-shadow"
          sx={{
            p: 4,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            borderRadius: 4,
            overflow: 'hidden',
            backgroundColor: 'white'
          }}
        >
          <Box 
            sx={{
              mb: 3, 
              width: 80, 
              height: 80, 
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              borderRadius: '50%',
              background: 'linear-gradient(45deg, #34C759, #5AC8FA)',
              color: 'white',
              boxShadow: '0 10px 20px rgba(52, 199, 89, 0.2)'
            }}
          >
            <AccountCircleIcon sx={{ fontSize: 40 }} />
          </Box>
          
          <Typography 
            component="h1" 
            variant="h4" 
            sx={{ 
              fontWeight: 700, 
              mb: 1, 
              textAlign: 'center',
              background: 'linear-gradient(45deg, #34C759, #5AC8FA)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent'
            }}
          >
            Create Account
          </Typography>
          
          <Typography 
            variant="body1" 
            color="text.secondary" 
            sx={{ mb: 4, textAlign: 'center' }}
          >
            Join FinTools to manage your business finances
          </Typography>
          
          {/* Stepper for registration process */}
          <Stepper 
            activeStep={activeStep} 
            alternativeLabel 
            sx={{ 
              width: '100%', 
              mb: 4,
              '& .MuiStepLabel-root .Mui-completed': {
                color: '#34C759'
              },
              '& .MuiStepLabel-root .Mui-active': {
                color: '#007AFF'
              }
            }}
          >
            {steps.map((label) => (
              <Step key={label}>
                <StepLabel>{label}</StepLabel>
              </Step>
            ))}
          </Stepper>
          
          {(error || localError) && (
            <Alert 
              severity="error" 
              sx={{ 
                width: '100%', 
                mb: 3,
                borderRadius: 3,
                border: '1px solid rgba(255, 59, 48, 0.1)',
                '& .MuiAlert-icon': {
                  color: theme.palette.error.main
                }
              }}
            >
              {error || localError}
            </Alert>
          )}
          
          <Box component="form" onSubmit={handleSubmit} noValidate sx={{ width: '100%' }}>
            {activeStep === 0 ? (
              <Box>
                <TextField
                  autoComplete="name"
                  name="name"
                  required
                  fullWidth
                  id="name"
                  label="Full Name"
                  autoFocus
                  value={name}
                  onChange={handleChange}
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <AccountCircleIcon sx={{ color: 'text.secondary' }} />
                      </InputAdornment>
                    ),
                  }}
                  sx={{
                    mb: 2,
                    '& .MuiOutlinedInput-root': {
                      borderRadius: 3
                    }
                  }}
                />
                <TextField
                  required
                  fullWidth
                  id="email"
                  label="Email Address"
                  name="email"
                  autoComplete="email"
                  value={email}
                  onChange={handleChange}
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <EmailIcon sx={{ color: 'text.secondary' }} />
                      </InputAdornment>
                    ),
                  }}
                  sx={{
                    mb: 3,
                    '& .MuiOutlinedInput-root': {
                      borderRadius: 3
                    }
                  }}
                />
                <Button
                  fullWidth
                  variant="contained"
                  onClick={handleNext}
                  sx={{ 
                    mt: 2, 
                    mb: 3, 
                    py: 1.5,
                    borderRadius: 3,
                    fontSize: '1rem',
                    fontWeight: 600,
                    boxShadow: '0 4px 10px rgba(0, 122, 255, 0.3)',
                    position: 'relative',
                    overflow: 'hidden',
                    '&::after': {
                      content: '""',
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      width: '100%',
                      height: '100%',
                      background: 'linear-gradient(rgba(255, 255, 255, 0.15), rgba(255, 255, 255, 0))',
                      zIndex: 1
                    }
                  }}
                >
                  Continue
                </Button>
              </Box>
            ) : (
              <Box>
                <TextField
                  required
                  fullWidth
                  name="password"
                  label="Password"
                  type={showPassword ? 'text' : 'password'}
                  id="password"
                  autoComplete="new-password"
                  value={password}
                  onChange={handleChange}
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <LockIcon sx={{ color: 'text.secondary' }} />
                      </InputAdornment>
                    ),
                    endAdornment: (
                      <InputAdornment position="end">
                        <IconButton
                          aria-label="toggle password visibility"
                          onClick={toggleShowPassword}
                          edge="end"
                        >
                          {showPassword ? <VisibilityOff /> : <Visibility />}
                        </IconButton>
                      </InputAdornment>
                    ),
                  }}
                  sx={{
                    mb: 2,
                    '& .MuiOutlinedInput-root': {
                      borderRadius: 3
                    }
                  }}
                />
                <TextField
                  required
                  fullWidth
                  name="confirmPassword"
                  label="Confirm Password"
                  type={showPassword ? 'text' : 'password'}
                  id="confirmPassword"
                  value={confirmPassword}
                  onChange={handleChange}
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <LockIcon sx={{ color: 'text.secondary' }} />
                      </InputAdornment>
                    )
                  }}
                  sx={{
                    mb: 3,
                    '& .MuiOutlinedInput-root': {
                      borderRadius: 3
                    }
                  }}
                />
                
                <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 3 }}>
                  Password must be at least 6 characters long.
                </Typography>
                
                <Grid container spacing={2}>
                  <Grid item xs={5}>
                    <Button
                      fullWidth
                      variant="outlined"
                      onClick={handleBack}
                      startIcon={<ArrowBackIcon />}
                      sx={{ 
                        py: 1.5,
                        borderRadius: 3,
                        fontWeight: 600
                      }}
                    >
                      Back
                    </Button>
                  </Grid>
                  <Grid item xs={7}>
                    <Button
                      type="submit"
                      fullWidth
                      variant="contained"
                      disabled={isLoading}
                      sx={{ 
                        py: 1.5,
                        borderRadius: 3,
                        fontSize: '1rem',
                        fontWeight: 600,
                        boxShadow: '0 4px 10px rgba(0, 122, 255, 0.3)',
                        position: 'relative',
                        overflow: 'hidden',
                        '&::after': {
                          content: '""',
                          position: 'absolute',
                          top: 0,
                          left: 0,
                          width: '100%',
                          height: '100%',
                          background: 'linear-gradient(rgba(255, 255, 255, 0.15), rgba(255, 255, 255, 0))',
                          zIndex: 1
                        }
                      }}
                    >
                      {isLoading ? 'Signing up...' : 'Sign Up'}
                    </Button>
                  </Grid>
                </Grid>
              </Box>
            )}
            
            <Grid container justifyContent="center" alignItems="center" sx={{ mt: 3 }}>
              <Grid item>
                <Link 
                  component={RouterLink} 
                  to="/login" 
                  variant="body2"
                  sx={{ 
                    display: 'flex',
                    alignItems: 'center',
                    color: theme.palette.primary.main,
                    textDecoration: 'none',
                    fontWeight: 500,
                    '&:hover': {
                      textDecoration: 'none',
                    }
                  }}
                >
                  Already have an account? Sign in
                  <ChevronRightIcon sx={{ ml: 0.5, fontSize: '1rem' }} />
                </Link>
              </Grid>
            </Grid>
          </Box>
        </Paper>
      </Slide>
      <Typography 
        variant="body2" 
        color="text.secondary" 
        align="center" 
        sx={{ mt: 4 }}
      >
        FinTools • Financial Management Application
      </Typography>
    </Container>
  );
} 