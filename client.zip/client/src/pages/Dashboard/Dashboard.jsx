import React, { useContext, useState, useEffect } from 'react';
import { 
  Grid,  
  Typography, 
  Box, 
  CircularProgress, 
  useMediaQuery, 
  Card, 
  CardContent, 
  Divider, 
  IconButton,
  Tooltip,
  Stack
} from '@mui/material';
import { useTheme } from '@mui/material/styles';
import {
  TrendingUp as TrendingUpIcon,
  TrendingDown as TrendingDownIcon,
  DateRange as DateRangeIcon,
  ArrowUpward as ArrowUpwardIcon,
  ArrowDownward as ArrowDownwardIcon,
  Refresh as RefreshIcon
} from '@mui/icons-material';
import { FinancialContext } from '../../context/FinancialContext';
import { PieChart, Pie, Cell, ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, Legend } from 'recharts';
import FinanceSummary from '../../components/FinanceSummary';
import RecentTransactions from '../../components/RecentTransactions';

const Dashboard = () => {
  const { 
    financialSummary, 
    revenues, 
    expenses, 
    loading, 
    expensesLoading, 
    revenuesLoading,
    refreshData,
    loadFinancialSummary
  } = useContext(FinancialContext);
  
  const [refreshing, setRefreshing] = useState(false);
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

  // Refresh data when dashboard is loaded, but only if needed
  useEffect(() => {
    // Track component mount state
    let isMounted = true;
    console.log('Dashboard component mounted');
    
    const refreshDashboardData = async () => {
      // Skip if already refreshing
      if (refreshing) {
        console.log('Already refreshing data, skipping');
        return;
      }
      
      // Skip if financial summary is already loaded
      if (financialSummary.dataLoaded) {
        console.log('Financial summary already loaded, skipping refresh');
        return;
      }
      
      console.log('Refreshing financial data');
      setRefreshing(true);
      
      try {
        // Refresh financial summary to ensure dashboard shows latest data
        await loadFinancialSummary();
        if (isMounted) {
          console.log('Financial summary refreshed on dashboard mount');
        }
      } catch (error) {
        console.error('Error refreshing dashboard data:', error);
      } finally {
        if (isMounted) {
          setRefreshing(false);
        }
      }
    };
    
    refreshDashboardData();
    
    // Cleanup function
    return () => {
      isMounted = false;
    };
  }, [loadFinancialSummary, refreshing, financialSummary.dataLoaded]);

  const handleRefresh = async () => {
    setRefreshing(true);
    try {
      await refreshData();
    } catch (error) {
      console.error("Error refreshing dashboard data:", error);
    } finally {
      setRefreshing(false);
    }
  };

  // Prepare data for charts
  const pieData = [
    { name: 'Revenue', value: financialSummary.totalRevenue || 0 },
    { name: 'Expenses', value: financialSummary.totalExpenses || 0 }
  ];

  // Get month names for line chart
  const getMonthData = () => {
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const currentMonth = new Date().getMonth();
    const last6Months = [];
    
    for (let i = 5; i >= 0; i--) {
      const monthIndex = (currentMonth - i + 12) % 12;
      last6Months.push(monthNames[monthIndex]);
    }
    
    // Combine month names with revenue and expense data
    return last6Months.map(month => {
      const revenuesInMonth = revenues.filter(rev => {
        const revDate = new Date(rev.date);
        const revMonth = revDate.getMonth();
        const monthIndex = monthNames.indexOf(month);
        return revMonth === monthIndex;
      });
      
      const expensesInMonth = expenses.filter(exp => {
        const expDate = new Date(exp.date);
        const expMonth = expDate.getMonth();
        const monthIndex = monthNames.indexOf(month);
        return expMonth === monthIndex;
      });
      
      const totalRevenue = revenuesInMonth.reduce((sum, rev) => sum + rev.amount, 0);
      const totalExpense = expensesInMonth.reduce((sum, exp) => sum + exp.amount, 0);
      
      return {
        name: month,
        revenue: totalRevenue,
        expense: totalExpense,
        profit: totalRevenue - totalExpense
      };
    });
  };
  
  const lineChartData = getMonthData();

  // Calculate profit percentage change
  const calculateGrowth = () => {
    if (lineChartData.length < 2) return 0;
    
    const currentMonth = lineChartData[lineChartData.length - 1].profit;
    const previousMonth = lineChartData[lineChartData.length - 2].profit;
    
    if (previousMonth === 0) return currentMonth > 0 ? 100 : 0;
    
    return ((currentMonth - previousMonth) / Math.abs(previousMonth)) * 100;
  };
  
  const profitGrowth = calculateGrowth();
  const isPositiveGrowth = profitGrowth >= 0;

  // Format currency function
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-MY', {
      style: 'currency',
      currency: 'MYR',
      minimumFractionDigits: 2
    }).format(amount);
  };

  // Show loading indicator while data is loading from context
  if (loading || expensesLoading || revenuesLoading) {
    return (
      <Box sx={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', height: '80vh' }}>
        <CircularProgress size={60} thickness={4} sx={{ mb: 2 }} />
        <Typography variant="h6" color="text.secondary">
          Loading Dashboard Data...
        </Typography>
      </Box>
    );
  }

  return (
    <Box sx={{ flexGrow: 1, p: isMobile ? 1 : 3 }}>
      <Box sx={{ 
        display: 'flex', 
        justifyContent: 'space-between', 
        alignItems: 'center', 
        mb: 4,
        px: isMobile ? 1 : 0
      }}>
        <Typography 
          variant={isMobile ? 'h5' : 'h4'} 
          component="h1" 
          sx={{ 
            fontWeight: 700, 
            fontSize: isMobile ? '1.5rem' : '2.125rem',
            background: 'linear-gradient(45deg, #007AFF, #5AC8FA)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
          }}
        >
          Dashboard
        </Typography>
        <Tooltip title="Refresh data">
          <IconButton 
            onClick={handleRefresh} 
            disabled={refreshing}
            sx={{ 
              background: 'rgba(0, 122, 255, 0.1)',
              '&:hover': {
                background: 'rgba(0, 122, 255, 0.2)',
              }
            }}
          >
            <RefreshIcon 
              sx={{ 
                animation: refreshing ? 'spin 1s linear infinite' : 'none',
                '@keyframes spin': {
                  '0%': {
                    transform: 'rotate(0deg)',
                  },
                  '100%': {
                    transform: 'rotate(360deg)',
                  },
                },
              }} 
            />
          </IconButton>
        </Tooltip>
      </Box>

      <Grid container spacing={isMobile ? 2 : 3}>
        {/* Financial Summary */}
        <Grid item xs={12} md={6}>
          <Card 
            elevation={0}
            className="ios-shadow"
            sx={{ 
              borderRadius: 4,
              height: '100%',
              overflow: 'hidden',
              background: 'linear-gradient(135deg, rgba(255,255,255,0.9) 0%, rgba(255,255,255,1) 100%)',
              backdropFilter: 'blur(20px)',
            }}
          >
            <CardContent sx={{ p: 0 }}>
              <Box sx={{ p: 3, pb: 1 }}>
                <Typography 
                  variant="h6" 
                  component="h2" 
                  sx={{ 
                    fontWeight: 600, 
                    display: 'flex', 
                    alignItems: 'center', 
                    mb: 3,
                    fontSize: isMobile ? '1rem' : '1.25rem'
                  }}
                >
                  <DateRangeIcon sx={{ mr: 1, color: theme.palette.primary.main }} />
                  Financial Summary
                </Typography>
              </Box>
              <Divider />
              <FinanceSummary isMobile={isMobile} />
            </CardContent>
          </Card>
        </Grid>

        {/* Profit Trend */}
        <Grid item xs={12} md={6}>
          <Card 
            elevation={0}
            className="ios-shadow"
            sx={{ 
              borderRadius: 4,
              height: '100%',
              overflow: 'hidden',
              background: 'linear-gradient(135deg, rgba(255,255,255,0.9) 0%, rgba(255,255,255,1) 100%)',
              backdropFilter: 'blur(20px)',
            }}
          >
            <CardContent>
              <Box sx={{ 
                display: 'flex', 
                justifyContent: 'space-between', 
                alignItems: 'center', 
                mb: 2 
              }}>
                <Typography 
                  variant="h6" 
                  component="h2" 
                  sx={{ 
                    fontWeight: 600, 
                    display: 'flex', 
                    alignItems: 'center',
                    fontSize: isMobile ? '1rem' : '1.25rem'
                  }}
                >
                  {isPositiveGrowth ? (
                    <TrendingUpIcon sx={{ mr: 1, color: '#34C759' }} />
                  ) : (
                    <TrendingDownIcon sx={{ mr: 1, color: '#FF3B30' }} />
                  )}
                  Profit Trend
                </Typography>
                <Box 
                  sx={{ 
                    display: 'flex', 
                    alignItems: 'center',
                    px: 1.5,
                    py: 0.5,
                    borderRadius: 5,
                    backgroundColor: isPositiveGrowth ? 'rgba(52, 199, 89, 0.1)' : 'rgba(255, 59, 48, 0.1)',
                    color: isPositiveGrowth ? '#34C759' : '#FF3B30',
                  }}
                >
                  {isPositiveGrowth ? (
                    <ArrowUpwardIcon sx={{ fontSize: '0.875rem', mr: 0.5 }} />
                  ) : (
                    <ArrowDownwardIcon sx={{ fontSize: '0.875rem', mr: 0.5 }} />
                  )}
                  <Typography variant="body2" sx={{ fontWeight: 600 }}>
                    {Math.abs(profitGrowth).toFixed(1)}%
                  </Typography>
                </Box>
              </Box>
              
              <Box sx={{ height: 250, mt: 3 }}>
                {revenues.length > 0 || expenses.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={lineChartData}
                      margin={{
                        top: 5,
                        right: 20,
                        left: 0,
                        bottom: 5,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.05)" />
                      <XAxis 
                        dataKey="name"
                        tick={{ fontSize: 12 }}
                        tickLine={false}
                        axisLine={{ stroke: 'rgba(0,0,0,0.1)' }}
                      />
                      <YAxis 
                        tickFormatter={(value) => `RM${value}`} 
                        tick={{ fontSize: 12 }}
                        tickLine={false}
                        axisLine={{ stroke: 'rgba(0,0,0,0.1)' }}
                      />
                      <RechartsTooltip 
                        formatter={(value) => formatCurrency(value)}
                        labelStyle={{ fontWeight: 'bold' }}
                        contentStyle={{ 
                          borderRadius: 8, 
                          border: 'none', 
                          boxShadow: '0 4px 20px rgba(0,0,0,0.1)',
                          padding: '8px 12px'
                        }}
                      />
                      <Legend wrapperStyle={{ fontSize: 12, paddingTop: 10 }} />
                      <Line 
                        type="monotone" 
                        dataKey="revenue" 
                        stroke="#34C759" 
                        strokeWidth={2}
                        dot={{ stroke: '#34C759', strokeWidth: 2, r: 4, fill: 'white' }}
                        activeDot={{ r: 6, stroke: '#34C759', strokeWidth: 2, fill: 'white' }}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="expense" 
                        stroke="#FF3B30" 
                        strokeWidth={2}
                        dot={{ stroke: '#FF3B30', strokeWidth: 2, r: 4, fill: 'white' }}
                        activeDot={{ r: 6, stroke: '#FF3B30', strokeWidth: 2, fill: 'white' }}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="profit" 
                        stroke="#007AFF" 
                        strokeWidth={2.5}
                        dot={{ stroke: '#007AFF', strokeWidth: 2, r: 4, fill: 'white' }}
                        activeDot={{ r: 6, stroke: '#007AFF', strokeWidth: 2, fill: 'white' }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                ) : (
                  <Box sx={{ 
                    height: '100%', 
                    display: 'flex', 
                    alignItems: 'center', 
                    justifyContent: 'center',
                    flexDirection: 'column',
                    p: 3,
                    backgroundColor: 'rgba(0,0,0,0.02)',
                    borderRadius: 2
                  }}>
                    <Typography variant="body1" color="text.secondary" align="center">
                      No transaction data available
                    </Typography>
                    <Typography variant="body2" color="text.secondary" align="center" sx={{ mt: 1 }}>
                      Add revenues and expenses to see your financial trend
                    </Typography>
                  </Box>
                )}
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* Revenue & Expense Distribution */}
        <Grid item xs={12} md={5}>
          <Card 
            elevation={0}
            className="ios-shadow"
            sx={{ 
              borderRadius: 4,
              height: '100%',
              overflow: 'hidden',
              background: 'linear-gradient(135deg, rgba(255,255,255,0.9) 0%, rgba(255,255,255,1) 100%)',
              backdropFilter: 'blur(20px)',
            }}
          >
            <CardContent>
              <Typography 
                variant="h6" 
                component="h2" 
                sx={{ 
                  fontWeight: 600, 
                  mb: 3,
                  fontSize: isMobile ? '1rem' : '1.25rem'
                }}
              >
                Revenue & Expense Distribution
              </Typography>
              
              <Box sx={{ height: 250, display: 'flex', justifyContent: 'center' }}>
                {(financialSummary.totalRevenue > 0 || financialSummary.totalExpenses > 0) ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={pieData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {pieData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={index === 0 ? '#34C759' : '#FF3B30'} />
                        ))}
                      </Pie>
                      <RechartsTooltip 
                        formatter={(value) => formatCurrency(value)}
                        contentStyle={{ 
                          borderRadius: 8, 
                          border: 'none', 
                          boxShadow: '0 4px 20px rgba(0,0,0,0.1)',
                          padding: '8px 12px'
                        }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                ) : (
                  <Box sx={{ 
                    width: '100%', 
                    height: '100%',
                    display: 'flex', 
                    alignItems: 'center', 
                    justifyContent: 'center',
                    p: 3,
                    backgroundColor: 'rgba(0,0,0,0.02)',
                    borderRadius: 2
                  }}>
                    <Typography variant="body1" color="text.secondary" align="center">
                      No data available for distribution chart
                    </Typography>
                  </Box>
                )}
              </Box>
              
              <Box sx={{ mt: 2 }}>
                <Stack direction="row" spacing={2} sx={{ mt: 2 }}>
                  <Box sx={{ flex: 1 }}>
                    <Typography variant="body2" color="text.secondary">
                      Total Revenue
                    </Typography>
                    <Typography 
                      variant="h6" 
                      sx={{ 
                        color: '#34C759',
                        fontWeight: 600
                      }}
                    >
                      {formatCurrency(financialSummary.totalRevenue || 0)}
                    </Typography>
                  </Box>
                  <Box sx={{ flex: 1 }}>
                    <Typography variant="body2" color="text.secondary">
                      Total Expenses
                    </Typography>
                    <Typography 
                      variant="h6" 
                      sx={{ 
                        color: '#FF3B30',
                        fontWeight: 600
                      }}
                    >
                      {formatCurrency(financialSummary.totalExpenses || 0)}
                    </Typography>
                  </Box>
                </Stack>
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* Recent Transactions */}
        <Grid item xs={12} md={7}>
          <Card 
            elevation={0}
            className="ios-shadow"
            sx={{ 
              borderRadius: 4,
              height: '100%',
              overflow: 'hidden',
              background: 'linear-gradient(135deg, rgba(255,255,255,0.9) 0%, rgba(255,255,255,1) 100%)',
              backdropFilter: 'blur(20px)',
            }}
          >
            <CardContent sx={{ p: 0 }}>
              <Box sx={{ p: 3, pb: 1 }}>
                <Typography 
                  variant="h6" 
                  component="h2" 
                  sx={{ 
                    fontWeight: 600,
                    fontSize: isMobile ? '1rem' : '1.25rem'
                  }}
                >
                  Recent Transactions
                </Typography>
              </Box>
              <Divider />
              <RecentTransactions isMobile={isMobile} />
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default Dashboard; 