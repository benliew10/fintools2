import React, { useEffect, useContext, useState } from 'react';
import {
  Container,
  Typography,
  Box,
  Button,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  CircularProgress,
  Grid,
  Chip,
  Tooltip,
  TablePagination,
  InputAdornment,
  FormControlLabel,
  Checkbox,
  Card,
  CardContent,
  Divider,
  useMediaQuery,
  Fab,
  Slide,
  SwipeableDrawer,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  LinearProgress,
  Stack,
  Avatar,
  Alert
} from '@mui/material';
import { useTheme } from '@mui/material/styles';
import {
  Add as AddIcon,
  Delete as DeleteIcon,
  Edit as EditIcon,
  Visibility as VisibilityIcon,
  FileDownload as FileDownloadIcon,
  Search as SearchIcon,
  FilterList as FilterListIcon,
  Close as CloseIcon,
  MoreVert as MoreVertIcon,
  Phone as PhoneIcon,
  Home as HomeIcon,
  Person as PersonIcon,
  Devices as DevicesIcon,
  Campaign as CampaignIcon,
  DirectionsCar as DirectionsCarIcon,
  LocalShipping as LocalShippingIcon,
  CardGiftcard as CardGiftcardIcon,
  Storefront as StorefrontIcon,
  Category as CategoryIcon,
  Refresh as RefreshIcon,
  Save as SaveIcon,
  FilterAlt as FilterAltIcon,
  ArrowUpward as ArrowUpwardIcon,
  ArrowDownward as ArrowDownwardIcon
} from '@mui/icons-material';
import { FinancialContext } from '../../context/FinancialContext';
import { AuthContext } from '../../context/AuthContext';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { LocalizationProvider, DatePicker } from '@mui/x-date-pickers';
import { format } from 'date-fns';

// Transition component for dialogs
const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

export default function Expenses() {
  const { 
    expenses, 
    loading, 
    error, 
    loadExpenses, 
    addExpense, 
    updateExpense, 
    deleteExpense,
    createProductFromExpense,
    expensesLoaded,
    expensesLoading
  } = useContext(FinancialContext);
  
  const { user } = useContext(AuthContext);
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  
  // Dialog state
  const [openDialog, setOpenDialog] = useState(false);
  const [dialogMode, setDialogMode] = useState('add'); // 'add' or 'edit'
  const [selectedExpense, setSelectedExpense] = useState(null);
  const [viewDialog, setViewDialog] = useState(false);
  const [deleteConfirmDialog, setDeleteConfirmDialog] = useState(false);
  const [filterDrawerOpen, setFilterDrawerOpen] = useState(false);
  
  // Form state
  const [formData, setFormData] = useState({
    description: '',
    amount: '',
    category: '',
    date: new Date(),
    notes: '',
    isAsset: false
  });
  
  // Table pagination
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(isMobile ? 5 : 10);
  
  // Search and filter
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState('');
  
  // Load expenses on component mount only if not already loaded
  useEffect(() => {
    const fetchData = async () => {
      if (!expensesLoaded && !expensesLoading) {
        try {
          await loadExpenses();
        } catch (error) {
          console.error("Error loading expenses:", error);
        }
      }
    };
    
    fetchData();
  }, [loadExpenses, expensesLoaded, expensesLoading]);
  
  // Update rows per page based on screen size
  useEffect(() => {
    setRowsPerPage(isMobile ? 5 : 10);
  }, [isMobile]);
  
  // Handle dialog open for adding
  const handleAddClick = () => {
    setDialogMode('add');
    setFormData({
      description: '',
      amount: '',
      category: '',
      date: new Date(),
      notes: '',
      isAsset: false
    });
    setOpenDialog(true);
  };
  
  // Handle dialog open for editing
  const handleEditClick = (expense) => {
    setDialogMode('edit');
    setSelectedExpense(expense);
    setFormData({
      description: expense.description,
      amount: expense.amount,
      category: expense.category,
      date: new Date(expense.date),
      notes: expense.notes || '',
      isAsset: expense.isAsset || false
    });
    setOpenDialog(true);
  };
  
  // Handle dialog close
  const handleDialogClose = () => {
    setOpenDialog(false);
    setViewDialog(false);
    setDeleteConfirmDialog(false);
    setFilterDrawerOpen(false);
  };
  
  // Handle form input change
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prevState => ({
      ...prevState,
      [name]: value
    }));
  };
  
  // Handle checkbox change
  const handleCheckboxChange = (e) => {
    const { name, checked } = e.target;
    setFormData(prevState => ({
      ...prevState,
      [name]: checked
    }));
  };
  
  // Handle date change
  const handleDateChange = (newDate) => {
    setFormData(prevState => ({
      ...prevState,
      date: newDate
    }));
  };
  
  // Format currency with Malaysian Ringgit
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('ms-MY', {
      style: 'currency',
      currency: 'MYR',
      minimumFractionDigits: 2
    }).format(amount);
  };
  
  // Get icon for a category
  const getCategoryIcon = (category) => {
    switch(category) {
      case 'Phone': return <PhoneIcon />;
      case 'Rental': return <HomeIcon />;
      case 'Salary': return <PersonIcon />;
      case 'Accessories': return <DevicesIcon />;
      case 'Marketing': return <CampaignIcon />;
      case 'Transport': return <DirectionsCarIcon />;
      case 'Courier': return <LocalShippingIcon />;
      case 'Bonus': return <CardGiftcardIcon />;
      case 'Advertisement': return <StorefrontIcon />;
      default: return <CategoryIcon />;
    }
  };
  
  // Get color for a category
  const getCategoryColor = (category) => {
    switch(category) {
      case 'Phone': return 'warning';
      case 'Rental': return 'error';
      case 'Salary': return 'primary';
      case 'Accessories': return 'info';
      case 'Marketing': return 'success';
      case 'Transport': return 'secondary';
      case 'Courier': return 'default';
      case 'Bonus': return 'warning';
      case 'Advertisement': return 'info';
      default: return 'default';
    }
  };
  
  // Check if category can be an asset
  const canBeAsset = (category) => {
    return ['Phone', 'Accessories', 'Marketing', 'Transport', 'Other'].includes(category);
  };
  
  // Check if category should be tracked as product
  const shouldTrackAsProduct = (category) => {
    return ['Phone', 'Accessories'].includes(category);
  };
  
  // Get overall expense statistics
  const getTotalExpenses = () => {
    return expenses.reduce((sum, expense) => sum + expense.amount, 0);
  };
  
  const getExpensesByCategory = () => {
    const categoryCounts = {};
    const categoryTotals = {};
    
    expenses.forEach(expense => {
      if (!categoryCounts[expense.category]) {
        categoryCounts[expense.category] = 0;
        categoryTotals[expense.category] = 0;
      }
      categoryCounts[expense.category]++;
      categoryTotals[expense.category] += expense.amount;
    });
    
    return { categoryCounts, categoryTotals };
  };
  
  // Handle form submission
  const handleSubmit = async () => {
    // Improved validation with user feedback
    if (!formData.description || !formData.amount || !formData.category) {
      // Add error handling with alert
      alert('Please fill in all required fields: Description, Amount, and Category');
      return;
    }
    
    try {
      const expenseData = {
        ...formData,
        amount: parseFloat(formData.amount),
        paidBy: user._id
      };
      
      // For Phone and Accessories, automatically set isAsset to true
      if (shouldTrackAsProduct(formData.category)) {
        expenseData.isAsset = true;
      }
      
      let savedExpense;
      
      if (dialogMode === 'add') {
        savedExpense = await addExpense(expenseData);
      } else {
        savedExpense = await updateExpense(selectedExpense._id, expenseData);
      }
      
      // If expense is Phone or Accessories, create a product automatically
      if (savedExpense && shouldTrackAsProduct(savedExpense.category)) {
        try {
          const productData = {
            name: savedExpense.description,
            description: savedExpense.notes || `${savedExpense.category} expense`,
            category: savedExpense.category,
            purchasePrice: savedExpense.amount,
            quantity: 1,
            purchaseDate: savedExpense.date,
            isAsset: true,
            relatedExpense: savedExpense._id
          };
          
          await createProductFromExpense(productData);
          console.log('Product created successfully from expense');
        } catch (error) {
          console.error('Error creating product from expense:', error);
        }
      }
      
      handleDialogClose();
    } catch (error) {
      console.error('Error submitting expense:', error);
      alert('Error saving expense. Please try again.');
    }
  };
  
  // Handle expense view
  const handleViewClick = (expense) => {
    setSelectedExpense(expense);
    setViewDialog(true);
  };
  
  // Handle expense delete confirmation
  const handleDeleteClick = (expense) => {
    setSelectedExpense(expense);
    setDeleteConfirmDialog(true);
  };
  
  // Handle expense delete
  const handleDeleteConfirm = async () => {
    try {
      setDeleteConfirmDialog(true); // Keep dialog open during deletion
      
      console.log(`Attempting to delete expense: ${selectedExpense._id}`);
      const result = await deleteExpense(selectedExpense._id);
      
      if (result) {
        console.log('Delete successful, closing dialogs');
        // Success - close dialogs
        setDeleteConfirmDialog(false);
        handleDialogClose();
      } else {
        // Error already set in context
        console.error(`Delete failed, error: ${error}`);
        
        // Keep dialog open to show error, but don't add extra alert
        if (!error) {
          // If no error was set in context, set a generic one
          alert("Failed to delete expense: Unknown error");
        }
      }
    } catch (err) {
      console.error("Error in delete confirmation:", err);
      alert(`Failed to delete expense: ${err.message || 'Unknown error'}`);
    }
  };
  
  // Handle pagination change
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };
  
  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };
  
  // Filter expenses
  const filteredExpenses = expenses.filter(expense => {
    return (
      expense.description.toLowerCase().includes(searchTerm.toLowerCase()) &&
      (filterCategory === '' || expense.category === filterCategory)
    );
  });
  
  // Paginated expenses
  const paginatedExpenses = filteredExpenses.slice(
    page * rowsPerPage,
    page * rowsPerPage + rowsPerPage
  );
  
  // Format date
  const formatDate = (dateString) => {
    try {
      return format(new Date(dateString), 'dd MMM yyyy');
    } catch (error) {
      return 'Invalid date';
    }
  };
  
  // Get data for stats
  const { categoryTotals } = getExpensesByCategory();
  const totalExpenses = getTotalExpenses();
  
  // Categories for expenses (as requested by user)
  const expenseCategories = [
    'Phone',
    'Rental',
    'Salary',
    'Accessories',
    'Marketing',
    'Transport',
    'Courier',
    'Bonus',
    'Advertisement',
    'Other'
  ];
  
  // Show loading indicator when data is loading
  if (expensesLoading) {
    return (
      <Box sx={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', height: '80vh' }}>
        <CircularProgress size={60} thickness={4} sx={{ mb: 2 }} />
        <Typography variant="h6" color="text.secondary">
          Loading Expenses Data...
        </Typography>
      </Box>
    );
  }
  
  // Enhanced error message with iOS-style design
  if (error) {
    return (
      <Container sx={{ py: 4 }}>
        <Alert 
          severity="error" 
          variant="filled"
          action={
            <Button 
              color="inherit" 
              size="small" 
              onClick={loadExpenses}
              startIcon={<RefreshIcon />}
            >
              Retry
            </Button>
          }
          sx={{ 
            borderRadius: 4,
            boxShadow: '0 4px 12px rgba(211, 47, 47, 0.2)'
          }}
        >
          {error}
        </Alert>
      </Container>
    );
  }
  
  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <Container disableGutters={isMobile} sx={{ pb: isMobile ? 7 : 3 }}>
        {/* Header Section with Gradient Background */}
        <Box sx={{ 
          pt: isMobile ? 2 : 3, 
          pb: 2,
          px: isMobile ? 2 : 3,
          background: theme.palette.mode === 'dark' 
            ? `linear-gradient(135deg, ${theme.palette.error.dark}, ${theme.palette.primary.dark})` 
            : `linear-gradient(135deg, ${theme.palette.error.main}, ${theme.palette.primary.main})`,
          borderRadius: isMobile ? '0 0 24px 24px' : '0 0 16px 16px',
          mb: 3,
          color: 'white',
          boxShadow: '0 4px 20px rgba(0,0,0,0.1)'
        }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: isMobile ? 1 : 2 }}>
            <Typography 
              variant={isMobile ? "h5" : "h4"} 
              sx={{ 
                fontWeight: 600,
              }}
            >
              Expenses
            </Typography>
            {!isMobile && (
              <Button
                variant="contained"
                startIcon={<AddIcon />}
                onClick={handleAddClick}
                sx={{ 
                  borderRadius: 8,
                  px: 3,
                  py: 1,
                  bgcolor: 'white',
                  color: theme.palette.error.main,
                  '&:hover': {
                    bgcolor: 'rgba(255,255,255,0.9)',
                  },
                  boxShadow: '0 4px 8px rgba(0,0,0,0.1)'
                }}
              >
                Add Expense
              </Button>
            )}
          </Box>
          
          {/* Summary for Desktop */}
          {!isMobile && (
            <Grid container spacing={2} sx={{ mt: 1 }}>
              <Grid item xs={12} md={4}>
                <Paper 
                  elevation={2}
                  sx={{ 
                    p: 2, 
                    borderRadius: 4,
                    bgcolor: 'rgba(255,255,255,0.9)',
                    display: 'flex',
                    alignItems: 'center',
                    backdropFilter: 'blur(10px)',
                    boxShadow: '0 4px 8px rgba(0,0,0,0.1)'
                  }}
                >
                  <Avatar sx={{ bgcolor: theme.palette.error.main, mr: 2 }}>
                    {getCategoryIcon('Rental')}
                  </Avatar>
                  <Box>
                    <Typography variant="body2" color="text.secondary">Total Expenses</Typography>
                    <Typography variant="h6" color="error.main" sx={{ fontWeight: 'bold' }}>
                      {formatCurrency(totalExpenses)}
                    </Typography>
                  </Box>
                </Paper>
              </Grid>
              
              <Grid item xs={12} md={4}>
                <Paper 
                  elevation={2}
                  sx={{ 
                    p: 2, 
                    borderRadius: 4,
                    bgcolor: 'rgba(255,255,255,0.9)',
                    display: 'flex',
                    alignItems: 'center',
                    backdropFilter: 'blur(10px)',
                    boxShadow: '0 4px 8px rgba(0,0,0,0.1)'
                  }}
                >
                  <Avatar sx={{ bgcolor: theme.palette.primary.main, mr: 2 }}>
                    {getCategoryIcon('Salary')}
                  </Avatar>
                  <Box>
                    <Typography variant="body2" color="text.secondary">This Month</Typography>
                    <Typography variant="h6" sx={{ fontWeight: 'bold' }}>
                      {formatCurrency(expenses
                        .filter(e => new Date(e.date).getMonth() === new Date().getMonth())
                        .reduce((sum, e) => sum + e.amount, 0)
                      )}
                    </Typography>
                  </Box>
                </Paper>
              </Grid>
              
              <Grid item xs={12} md={4}>
                <Paper 
                  elevation={2}
                  sx={{ 
                    p: 2, 
                    borderRadius: 4,
                    bgcolor: 'rgba(255,255,255,0.9)',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'flex-start',
                    backdropFilter: 'blur(10px)',
                    boxShadow: '0 4px 8px rgba(0,0,0,0.1)'
                  }}
                >
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>Top Category</Typography>
                  {Object.entries(categoryTotals).length > 0 ? (
                    Object.entries(categoryTotals)
                      .sort((a, b) => b[1] - a[1])
                      .slice(0, 1)
                      .map(([category, amount]) => (
                        <Box key={category} sx={{ display: 'flex', alignItems: 'center', width: '100%' }}>
                          <Chip 
                            icon={getCategoryIcon(category)} 
                            label={category}
                            color={getCategoryColor(category)} 
                            sx={{ mr: 1 }}
                          />
                          <Typography variant="body1" sx={{ fontWeight: 'bold', ml: 'auto' }}>
                            {formatCurrency(amount)}
                          </Typography>
                        </Box>
                      ))
                  ) : (
                    <Typography variant="body1">No expenses yet</Typography>
                  )}
                </Paper>
              </Grid>
            </Grid>
          )}
        </Box>

        {/* Summary for Mobile */}
        {isMobile && (
          <Box sx={{ px: 2, mb: 3 }}>
            <Card 
              elevation={2}
              sx={{ 
                borderRadius: 4,
                overflow: 'hidden',
                boxShadow: '0 2px 10px rgba(0,0,0,0.08)'
              }}
            >
              <CardContent sx={{ p: 2 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Typography variant="body2" color="text.secondary">Total Expenses</Typography>
                  <Chip
                    label={`${expenses.length} items`}
                    size="small"
                    sx={{ 
                      height: 24, 
                      '& .MuiChip-label': { px: 1, py: 0 },
                      fontWeight: 500,
                      bgcolor: 'rgba(0,0,0,0.05)' 
                    }}
                  />
                </Box>
                <Typography variant="h4" sx={{ fontWeight: 700, color: 'error.main', my: 1 }}>
                  {formatCurrency(totalExpenses)}
                </Typography>
                
                <Divider sx={{ my: 1.5 }} />
                
                {Object.entries(categoryTotals).length > 0 ? (
                  <Stack spacing={1}>
                    {Object.entries(categoryTotals)
                      .sort((a, b) => b[1] - a[1])
                      .slice(0, 2)
                      .map(([category, amount]) => (
                        <Box key={category} sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                          <Box sx={{ display: 'flex', alignItems: 'center' }}>
                            <Box 
                              sx={{ 
                                borderRadius: '8px', 
                                p: 0.5, 
                                mr: 1,
                                bgcolor: `${getCategoryColor(category)}.light`,
                                color: `${getCategoryColor(category)}.main`,
                                display: 'flex'
                              }}
                            >
                              {getCategoryIcon(category)}
                            </Box>
                            <Typography variant="body2">{category}</Typography>
                          </Box>
                          <Typography variant="body2" sx={{ fontWeight: 600 }}>
                            {formatCurrency(amount)}
                          </Typography>
                        </Box>
                      ))}
                  </Stack>
                ) : (
                  <Typography variant="body2" color="text.secondary" sx={{ textAlign: 'center', py: 1 }}>
                    No expenses recorded yet
                  </Typography>
                )}
              </CardContent>
            </Card>
          </Box>
        )}
        
        {/* Search and Filter */}
        <Box sx={{ mb: 3, px: isMobile ? 2 : 0 }}>
          <Grid container spacing={2} alignItems="center">
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                placeholder="Search expenses"
                variant="outlined"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchIcon />
                    </InputAdornment>
                  ),
                  sx: {
                    borderRadius: 8,
                    backgroundColor: 'white',
                    '& fieldset': {
                      borderColor: 'rgba(0, 0, 0, 0.08)',
                    },
                    boxShadow: '0 2px 8px rgba(0, 0, 0, 0.05)'
                  }
                }}
              />
            </Grid>
            
            {!isMobile && (
              <Grid item xs={12} sm={6} md={4}>
                <FormControl fullWidth variant="outlined">
                  <InputLabel>Filter by Category</InputLabel>
                  <Select
                    value={filterCategory}
                    onChange={(e) => setFilterCategory(e.target.value)}
                    label="Filter by Category"
                    sx={{
                      borderRadius: 8,
                      backgroundColor: 'white',
                      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.05)'
                    }}
                    startAdornment={
                      filterCategory ? (
                        <InputAdornment position="start" sx={{ ml: 1 }}>
                          {getCategoryIcon(filterCategory)}
                        </InputAdornment>
                      ) : null
                    }
                  >
                    <MenuItem value="">All Categories</MenuItem>
                    {expenseCategories.map(category => (
                      <MenuItem key={category} value={category}>
                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                          <Box sx={{ mr: 1, color: `${getCategoryColor(category)}.main`, display: 'flex' }}>
                            {getCategoryIcon(category)}
                          </Box>
                          {category}
                        </Box>
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
            )}
            
            <Grid item xs={12} sm={12} md={4} sx={{ display: 'flex', justifyContent: { xs: 'flex-end', md: 'flex-end' } }}>
              <Button 
                variant="contained" 
                color="primary" 
                startIcon={<AddIcon />}
                onClick={handleAddClick}
                fullWidth={isMobile}
                size={isMobile ? "large" : "medium"}
                sx={{
                  borderRadius: 8,
                  py: isMobile ? 1.5 : 1.2,
                  boxShadow: '0 4px 10px rgba(0, 122, 255, 0.3)'
                }}
              >
                Add Expense
              </Button>
            </Grid>
          </Grid>
        </Box>
        
        {/* Filter Chips - Mobile */}
        {isMobile && (
          <Box sx={{ px: 2, mb: 2, overflow: 'auto' }}>
            <Box sx={{ display: 'flex', gap: 1, pb: 0.5 }}>
              <Chip
                label="All"
                color={filterCategory === '' ? 'primary' : 'default'}
                onClick={() => setFilterCategory('')}
                sx={{ borderRadius: 8 }}
              />
              {expenseCategories.map(category => (
                <Chip
                  key={category}
                  label={category}
                  icon={getCategoryIcon(category)}
                  color={filterCategory === category ? getCategoryColor(category) : 'default'}
                  variant={filterCategory === category ? "filled" : "outlined"}
                  onClick={() => setFilterCategory(filterCategory === category ? '' : category)}
                  sx={{ borderRadius: 8 }}
                />
              ))}
            </Box>
          </Box>
        )}
        
        {/* Mobile Filter Button */}
        {isMobile && (
          <Box sx={{ position: 'fixed', bottom: 85, right: 16, zIndex: 10 }}>
            <Fab
              color="primary"
              aria-label="filter"
              onClick={() => setFilterDrawerOpen(true)}
              sx={{ boxShadow: '0 4px 12px rgba(0, 122, 255, 0.5)' }}
            >
              <FilterAltIcon />
            </Fab>
          </Box>
        )}
        
        {/* Mobile Filter Drawer */}
        {isMobile && (
          <SwipeableDrawer
            anchor="bottom"
            open={filterDrawerOpen}
            onClose={() => setFilterDrawerOpen(false)}
            onOpen={() => setFilterDrawerOpen(true)}
            disableSwipeToOpen={false}
            PaperProps={{
              sx: {
                borderTopLeftRadius: 20,
                borderTopRightRadius: 20,
                pb: 2
              }
            }}
          >
            <Box sx={{ width: '100%', height: 4, bgcolor: 'rgba(0,0,0,0.1)', mx: 'auto', mt: 1, borderRadius: 2 }} />
            <Box sx={{ p: 2, borderBottom: '1px solid rgba(0, 0, 0, 0.05)' }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                <Typography variant="h6" sx={{ fontWeight: 600 }}>Filter Expenses</Typography>
                <IconButton onClick={() => setFilterDrawerOpen(false)}>
                  <CloseIcon />
                </IconButton>
              </Box>
              
              <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                Category
              </Typography>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 3 }}>
                <Chip
                  label="All"
                  color={filterCategory === '' ? 'primary' : 'default'}
                  onClick={() => setFilterCategory('')}
                  sx={{ fontWeight: 500, borderRadius: 8 }}
                />
                {expenseCategories.map(category => (
                  <Chip
                    key={category}
                    label={category}
                    icon={getCategoryIcon(category)}
                    color={filterCategory === category ? getCategoryColor(category) : 'default'}
                    onClick={() => setFilterCategory(category)}
                    sx={{ fontWeight: 500, borderRadius: 8 }}
                  />
                ))}
              </Box>
              
              <Box sx={{ display: 'flex', gap: 2 }}>
                <Button 
                  variant="outlined" 
                  color="primary" 
                  fullWidth
                  onClick={() => {
                    setFilterCategory('');
                    setFilterDrawerOpen(false);
                  }}
                  sx={{ borderRadius: 8 }}
                >
                  Reset
                </Button>
                <Button 
                  variant="contained" 
                  color="primary" 
                  fullWidth
                  onClick={() => setFilterDrawerOpen(false)}
                  sx={{ borderRadius: 8 }}
                >
                  Apply
                </Button>
              </Box>
            </Box>
          </SwipeableDrawer>
        )}
        
        {/* Expenses List - Mobile View */}
        {isMobile && filteredExpenses.length > 0 && (
          <Box sx={{ px: 2, mb: 2 }}>
            <List sx={{ p: 0 }}>
              {paginatedExpenses.map((expense) => (
                <Card
                  key={expense._id}
                  sx={{
                    mb: 2,
                    borderRadius: 4,
                    overflow: 'hidden',
                    boxShadow: '0 2px 10px rgba(0,0,0,0.04)',
                    transition: 'transform 0.2s, box-shadow 0.2s',
                    '&:active': {
                      transform: 'scale(0.98)',
                      boxShadow: '0 1px 5px rgba(0,0,0,0.05)',
                    }
                  }}
                  onClick={() => handleViewClick(expense)}
                >
                  <CardContent sx={{ p: 2 }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', mb: 1.5 }}>
                      <Avatar
                        sx={{
                          bgcolor: `${getCategoryColor(expense.category)}.main`,
                          width: 40,
                          height: 40,
                          mr: 2
                        }}
                      >
                        {getCategoryIcon(expense.category)}
                      </Avatar>
                      <Box sx={{ flex: 1 }}>
                        <Typography variant="subtitle1" sx={{ fontWeight: 600, lineHeight: 1.2 }}>
                          {expense.description}
                        </Typography>
                        <Box sx={{ display: 'flex', alignItems: 'center', mt: 0.5 }}>
                          <Chip
                            label={expense.category}
                            size="small"
                            color={getCategoryColor(expense.category)}
                            sx={{ 
                              height: 20, 
                              '& .MuiChip-label': { px: 1, fontSize: '0.7rem', fontWeight: 600 } 
                            }}
                          />
                          <Typography variant="caption" color="text.secondary" sx={{ ml: 1 }}>
                            {formatDate(expense.date)}
                          </Typography>
                        </Box>
                      </Box>
                      <Typography 
                        variant="subtitle1" 
                        sx={{ 
                          fontWeight: 700, 
                          color: 'error.main',
                          ml: 1 
                        }}
                      >
                        {formatCurrency(expense.amount)}
                      </Typography>
                    </Box>
                    
                    {expense.notes && (
                      <Typography 
                        variant="body2" 
                        color="text.secondary"
                        sx={{ 
                          fontSize: '0.8rem',
                          pl: 7,
                          pr: 2,
                          overflow: 'hidden',
                          textOverflow: 'ellipsis',
                          whiteSpace: 'nowrap'
                        }}
                      >
                        {expense.notes}
                      </Typography>
                    )}
                    
                    {expense.isAsset && (
                      <Box sx={{ display: 'flex', alignItems: 'center', mt: 1, pl: 7 }}>
                        <Chip
                          label="Asset"
                          size="small"
                          color="info"
                          variant="outlined"
                          sx={{ 
                            height: 20, 
                            '& .MuiChip-label': { px: 1, fontSize: '0.7rem', fontWeight: 500 } 
                          }}
                        />
                      </Box>
                    )}
                  </CardContent>
                </Card>
              ))}
            </List>
          </Box>
        )}
        
        {/* Empty State */}
        {filteredExpenses.length === 0 && (
          <Box
            sx={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              p: 4,
              my: 4,
              textAlign: 'center'
            }}
          >
            <Avatar
              sx={{
                width: 80,
                height: 80,
                mb: 2,
                bgcolor: 'primary.light',
                color: 'primary.main'
              }}
            >
              <CategoryIcon sx={{ fontSize: 40 }} />
            </Avatar>
            <Typography variant="h6" gutterBottom>
              No expenses found
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 2, maxWidth: 300 }}>
              {searchTerm || filterCategory 
                ? "Try adjusting your filters to see more results" 
                : "You haven't added any expenses yet. Start by adding your first expense."}
            </Typography>
            <Button
              variant="contained"
              color="primary"
              startIcon={<AddIcon />}
              onClick={handleAddClick}
              sx={{ borderRadius: 8, px: 3 }}
            >
              Add Expense
            </Button>
          </Box>
        )}
        
        {/* Expenses Table - Desktop View */}
        {!isMobile && filteredExpenses.length > 0 && (
          <TableContainer 
            component={Paper} 
            sx={{ 
              borderRadius: 4,
              boxShadow: '0 2px 10px rgba(0,0,0,0.05)',
              overflow: 'hidden',
              mb: 3,
              mx: 0
            }}
          >
            <Table>
              <TableHead sx={{ bgcolor: 'rgba(0,0,0,0.02)' }}>
                <TableRow>
                  <TableCell width="10%">Category</TableCell>
                  <TableCell width="20%">Description</TableCell>
                  <TableCell width="20%">Date</TableCell>
                  <TableCell width="15%">Amount</TableCell>
                  <TableCell width="20%">Notes</TableCell>
                  <TableCell width="15%" align="right">Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {paginatedExpenses.map((expense) => (
                  <TableRow 
                    key={expense._id}
                    sx={{ 
                      '&:hover': { bgcolor: 'rgba(0,0,0,0.01)' },
                      transition: 'background-color 0.2s'
                    }}
                  >
                    <TableCell>
                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <Avatar
                          sx={{
                            bgcolor: `${getCategoryColor(expense.category)}.main`,
                            width: 28,
                            height: 28,
                            mr: 1.5
                          }}
                        >
                          {getCategoryIcon(expense.category)}
                        </Avatar>
                        <Box sx={{ display: 'flex', flexDirection: 'column' }}>
                          <Typography variant="body2" sx={{ fontWeight: 500 }}>
                            {expense.category}
                          </Typography>
                          {expense.isAsset && (
                            <Chip
                              label="Asset"
                              size="small"
                              color="info"
                              variant="outlined"
                              sx={{ 
                                height: 16, 
                                mt: 0.5,
                                '& .MuiChip-label': { 
                                  px: 0.5, 
                                  fontSize: '0.6rem', 
                                  fontWeight: 500 
                                } 
                              }}
                            />
                          )}
                        </Box>
                      </Box>
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2" sx={{ fontWeight: 500 }}>
                        {expense.description}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2">{formatDate(expense.date)}</Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2" sx={{ fontWeight: 600, color: 'error.main' }}>
                        {formatCurrency(expense.amount)}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Typography 
                        variant="body2" 
                        sx={{ 
                          color: 'text.secondary',
                          overflow: 'hidden',
                          textOverflow: 'ellipsis',
                          whiteSpace: 'nowrap',
                          maxWidth: 150
                        }}
                      >
                        {expense.notes || '-'}
                      </Typography>
                    </TableCell>
                    <TableCell align="right">
                      <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
                        <Tooltip title="View">
                          <IconButton 
                            size="small" 
                            onClick={() => handleViewClick(expense)}
                            sx={{ color: 'info.main' }}
                          >
                            <VisibilityIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Edit">
                          <IconButton 
                            size="small" 
                            onClick={() => handleEditClick(expense)}
                            sx={{ color: 'primary.main', mx: 0.5 }}
                          >
                            <EditIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Delete">
                          <IconButton 
                            size="small" 
                            onClick={() => handleDeleteClick(expense)}
                            sx={{ color: 'error.main' }}
                          >
                            <DeleteIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      </Box>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        )}
        
        {/* Pagination */}
        {filteredExpenses.length > 0 && (
          <TablePagination
            component="div"
            count={filteredExpenses.length}
            page={page}
            onPageChange={handleChangePage}
            rowsPerPage={rowsPerPage}
            onRowsPerPageChange={handleChangeRowsPerPage}
            rowsPerPageOptions={isMobile ? [5, 10] : [10, 25, 50]}
            sx={{ 
              borderTop: '1px solid rgba(0,0,0,0.05)',
              '.MuiTablePagination-toolbar': {
                paddingLeft: isMobile ? 1 : 2
              },
              '.MuiTablePagination-selectLabel, .MuiTablePagination-displayedRows': {
                fontSize: '0.875rem'
              }
            }}
          />
        )}
        
        {/* Expense Add/Edit Dialog */}
        <Dialog
          open={openDialog}
          onClose={handleDialogClose}
          fullScreen={isMobile}
          TransitionComponent={Transition}
          PaperProps={{
            sx: {
              borderRadius: isMobile ? 0 : 4,
              overflow: 'hidden',
              backgroundImage: theme.palette.mode === 'dark' 
                ? `linear-gradient(to bottom, ${theme.palette.background.paper}, ${theme.palette.background.paper})`
                : 'linear-gradient(to bottom, rgba(255,255,255,0.95), rgba(255,255,255,1))',
              boxShadow: '0 0 20px rgba(0,0,0,0.1)',
              width: isMobile ? '100%' : '550px',
              maxHeight: isMobile ? '100%' : '85vh'
            }
          }}
        >
          <Box
            sx={{
              px: 3,
              pt: 2,
              pb: 1,
              bgcolor: theme.palette.mode === 'dark' 
                ? `linear-gradient(135deg, ${theme.palette.error.dark}, ${theme.palette.primary.dark})`
                : `linear-gradient(135deg, ${theme.palette.error.main}, ${theme.palette.primary.main})`,
              color: 'white',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between'
            }}
          >
            <DialogTitle sx={{ p: 0, fontSize: '1.2rem', fontWeight: 600 }}>
              {dialogMode === 'add' ? 'Add New Expense' : 'Edit Expense'}
            </DialogTitle>
            <IconButton
              edge="end"
              color="inherit"
              onClick={handleDialogClose}
              aria-label="close"
            >
              <CloseIcon />
            </IconButton>
          </Box>
          <DialogContent sx={{ px: 3, pt: 3, pb: 1, overflowY: 'auto' }}>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <TextField
                  name="description"
                  label="Description"
                  value={formData.description}
                  onChange={handleInputChange}
                  fullWidth
                  variant="outlined"
                  required
                  autoFocus
                  InputProps={{
                    sx: {
                      borderRadius: 2,
                      backgroundColor: 'rgba(0,0,0,0.02)'
                    }
                  }}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  name="amount"
                  label="Amount (MYR)"
                  value={formData.amount}
                  onChange={handleInputChange}
                  fullWidth
                  variant="outlined"
                  required
                  type="number"
                  InputProps={{
                    startAdornment: <InputAdornment position="start">RM</InputAdornment>,
                    sx: {
                      borderRadius: 2,
                      backgroundColor: 'rgba(0,0,0,0.02)'
                    }
                  }}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <FormControl fullWidth variant="outlined" required>
                  <InputLabel>Category</InputLabel>
                  <Select
                    name="category"
                    label="Category"
                    value={formData.category}
                    onChange={handleInputChange}
                    IconComponent={props => <CategoryIcon {...props} color="action" />}
                    sx={{
                      borderRadius: 2,
                      backgroundColor: 'rgba(0,0,0,0.02)'
                    }}
                  >
                    {expenseCategories.map(category => (
                      <MenuItem key={category} value={category}>
                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                          <Box sx={{ mr: 1.5, color: `${getCategoryColor(category)}.main`, display: 'flex' }}>
                            {getCategoryIcon(category)}
                          </Box>
                          {category}
                        </Box>
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12}>
                <DatePicker
                  label="Date"
                  value={formData.date}
                  onChange={handleDateChange}
                  slotProps={{
                    textField: {
                      fullWidth: true,
                      variant: 'outlined',
                      sx: {
                        '& .MuiInputBase-root': {
                          borderRadius: 2,
                          backgroundColor: 'rgba(0,0,0,0.02)'
                        }
                      }
                    }
                  }}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  name="notes"
                  label="Notes"
                  value={formData.notes}
                  onChange={handleInputChange}
                  fullWidth
                  variant="outlined"
                  multiline
                  rows={3}
                  InputProps={{
                    sx: {
                      borderRadius: 2,
                      backgroundColor: 'rgba(0,0,0,0.02)'
                    }
                  }}
                />
              </Grid>
              {canBeAsset(formData.category) && (
                <Grid item xs={12}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        name="isAsset"
                        checked={formData.isAsset}
                        onChange={handleCheckboxChange}
                        color="primary"
                      />
                    }
                    label={
                      <Typography variant="body2">
                        Track as asset (appears in Products/Assets)
                      </Typography>
                    }
                  />
                </Grid>
              )}
            </Grid>
          </DialogContent>
          <DialogActions sx={{ px: 3, py: 2, justifyContent: 'flex-end' }}>
            <Button 
              onClick={handleDialogClose}
              sx={{ 
                borderRadius: 8,
                px: 3,
                color: 'text.secondary',
                '&:hover': {
                  backgroundColor: 'rgba(0,0,0,0.05)'
                }
              }}
            >
              Cancel
            </Button>
            <Button 
              onClick={handleSubmit}
              variant="contained"
              color="primary"
              startIcon={<SaveIcon />}
              sx={{ 
                borderRadius: 8,
                px: 3,
                boxShadow: '0 4px 10px rgba(0, 122, 255, 0.3)'
              }}
            >
              {dialogMode === 'add' ? 'Add Expense' : 'Save Changes'}
            </Button>
          </DialogActions>
        </Dialog>
        
        {/* View Expense Dialog */}
        <Dialog
          open={viewDialog}
          onClose={handleDialogClose}
          fullScreen={isMobile}
          TransitionComponent={Transition}
          PaperProps={{
            sx: {
              borderRadius: isMobile ? 0 : 4,
              overflow: 'hidden',
              width: isMobile ? '100%' : '500px',
              backgroundImage: theme.palette.mode === 'dark' 
                ? `linear-gradient(to bottom, ${theme.palette.background.paper}, ${theme.palette.background.paper})`
                : 'linear-gradient(to bottom, rgba(255,255,255,0.95), rgba(255,255,255,1))',
              boxShadow: '0 0 20px rgba(0,0,0,0.1)'
            }
          }}
        >
          {selectedExpense && (
            <>
              <Box
                sx={{
                  px: 3,
                  pt: 2,
                  pb: 1,
                  bgcolor: theme.palette.mode === 'dark' 
                    ? `linear-gradient(135deg, ${theme.palette.error.dark}, ${theme.palette.primary.dark})`
                    : `linear-gradient(135deg, ${theme.palette.error.main}, ${theme.palette.primary.main})`,
                  color: 'white',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between'
                }}
              >
                <DialogTitle sx={{ p: 0, fontSize: '1.2rem', fontWeight: 600 }}>
                  Expense Details
                </DialogTitle>
                <IconButton
                  edge="end"
                  color="inherit"
                  onClick={handleDialogClose}
                  aria-label="close"
                >
                  <CloseIcon />
                </IconButton>
              </Box>
              <DialogContent sx={{ px: 3, pt: 3, pb: 0 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
                  <Avatar
                    sx={{
                      bgcolor: `${getCategoryColor(selectedExpense.category)}.main`,
                      width: 56,
                      height: 56,
                      mr: 2
                    }}
                  >
                    {getCategoryIcon(selectedExpense.category)}
                  </Avatar>
                  <Box>
                    <Typography variant="h6" sx={{ fontWeight: 600, lineHeight: 1.2 }}>
                      {selectedExpense.description}
                    </Typography>
                    <Chip
                      label={selectedExpense.category}
                      color={getCategoryColor(selectedExpense.category)}
                      size="small"
                      sx={{ mt: 0.5 }}
                    />
                  </Box>
                </Box>
                
                <Paper
                  elevation={0}
                  sx={{
                    p: 2,
                    mb: 3,
                    borderRadius: 3,
                    backgroundColor: 'rgba(0,0,0,0.03)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between'
                  }}
                >
                  <Typography variant="body2" color="text.secondary">
                    Amount
                  </Typography>
                  <Typography variant="h5" color="error.main" sx={{ fontWeight: 700 }}>
                    {formatCurrency(selectedExpense.amount)}
                  </Typography>
                </Paper>
                
                <Grid container spacing={2} sx={{ mb: 2 }}>
                  <Grid item xs={6}>
                    <Paper
                      elevation={0}
                      sx={{
                        p: 2,
                        borderRadius: 3,
                        backgroundColor: 'rgba(0,0,0,0.03)',
                        height: '100%'
                      }}
                    >
                      <Typography variant="body2" color="text.secondary" gutterBottom>
                        Date
                      </Typography>
                      <Typography variant="body1" sx={{ fontWeight: 500 }}>
                        {formatDate(selectedExpense.date)}
                      </Typography>
                    </Paper>
                  </Grid>
                  <Grid item xs={6}>
                    <Paper
                      elevation={0}
                      sx={{
                        p: 2,
                        borderRadius: 3,
                        backgroundColor: 'rgba(0,0,0,0.03)',
                        height: '100%'
                      }}
                    >
                      <Typography variant="body2" color="text.secondary" gutterBottom>
                        Status
                      </Typography>
                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        {selectedExpense.isAsset ? (
                          <Chip label="Asset" color="info" size="small" />
                        ) : (
                          <Chip label="Expense" color="default" size="small" />
                        )}
                      </Box>
                    </Paper>
                  </Grid>
                </Grid>
                
                {selectedExpense.notes && (
                  <Box sx={{ mb: 3 }}>
                    <Typography variant="body2" color="text.secondary" gutterBottom>
                      Notes
                    </Typography>
                    <Typography variant="body1">
                      {selectedExpense.notes}
                    </Typography>
                  </Box>
                )}
              </DialogContent>
              <DialogActions sx={{ px: 3, py: 2, justifyContent: 'space-between' }}>
                <Button
                  color="error"
                  startIcon={<DeleteIcon />}
                  onClick={() => {
                    handleDeleteClick(selectedExpense);
                    handleDialogClose();
                  }}
                  sx={{ borderRadius: 8 }}
                >
                  Delete
                </Button>
                <Button
                  variant="contained"
                  color="primary"
                  startIcon={<EditIcon />}
                  onClick={() => {
                    handleEditClick(selectedExpense);
                    handleDialogClose();
                  }}
                  sx={{ borderRadius: 8 }}
                >
                  Edit
                </Button>
              </DialogActions>
            </>
          )}
        </Dialog>
        
        {/* Delete Confirmation Dialog */}
        <Dialog
          open={deleteConfirmDialog}
          onClose={() => {
            // Only allow closing if not currently loading
            if (!loading) handleDialogClose();
          }}
          TransitionComponent={Transition}
          PaperProps={{
            sx: {
              borderRadius: 4,
              overflow: 'hidden',
              maxWidth: '450px'
            }
          }}
        >
          {selectedExpense && (
            <>
              <DialogTitle sx={{ pt: 3, px: 3 }}>
                <Typography variant="h6" sx={{ fontWeight: 600 }}>
                  Delete Expense
                </Typography>
              </DialogTitle>
              <DialogContent sx={{ px: 3, pt: 1 }}>
                {error && (
                  <Alert 
                    severity="error" 
                    sx={{ mb: 2, borderRadius: 2 }}
                  >
                    {error}
                  </Alert>
                )}
                
                <Typography variant="body1" sx={{ mb: 2 }}>
                  Are you sure you want to delete this expense?
                </Typography>
                
                <Paper
                  elevation={0}
                  sx={{
                    p: 2,
                    borderRadius: 3,
                    backgroundColor: 'rgba(0,0,0,0.03)',
                    display: 'flex',
                    alignItems: 'center'
                  }}
                >
                  <Avatar
                    sx={{
                      bgcolor: `${getCategoryColor(selectedExpense.category)}.main`,
                      width: 40,
                      height: 40,
                      mr: 2
                    }}
                  >
                    {getCategoryIcon(selectedExpense.category)}
                  </Avatar>
                  <Box sx={{ flex: 1 }}>
                    <Typography variant="subtitle2" sx={{ fontWeight: 500, lineHeight: 1.2 }}>
                      {selectedExpense.description}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      {formatCurrency(selectedExpense.amount)} • {formatDate(selectedExpense.date)}
                    </Typography>
                  </Box>
                </Paper>
              </DialogContent>
              <DialogActions sx={{ px: 3, py: 2 }}>
                <Button
                  onClick={handleDialogClose}
                  disabled={loading}
                  sx={{ 
                    borderRadius: 8, 
                    px: 3,
                    color: 'text.secondary'
                  }}
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleDeleteConfirm}
                  variant="contained"
                  color="error"
                  disabled={loading}
                  startIcon={loading ? <CircularProgress size={16} color="inherit" /> : null}
                  sx={{ 
                    borderRadius: 8,
                    px: 3
                  }}
                >
                  {loading ? 'Deleting...' : 'Delete'}
                </Button>
              </DialogActions>
            </>
          )}
        </Dialog>
        
        {/* Add Expense FAB for Mobile */}
        {isMobile && (
          <Box sx={{ position: 'fixed', bottom: 16, right: 16, zIndex: 10 }}>
            <Fab
              color="primary"
              aria-label="add expense"
              onClick={handleAddClick}
              sx={{ 
                boxShadow: '0 4px 12px rgba(0, 122, 255, 0.5)',
                '&:hover': {
                  bgcolor: 'primary.dark'
                }
              }}
            >
              <AddIcon />
            </Fab>
          </Box>
        )}
      </Container>
    </LocalizationProvider>
  );
} 