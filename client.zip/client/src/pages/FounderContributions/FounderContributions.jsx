import React, { useEffect, useContext, useState } from 'react';
import {
  Container,
  Typography,
  Paper,
  Box,
  CircularProgress,
  Grid,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  IconButton,
  Divider,
  Alert,
  InputAdornment,
  Tooltip,
  Card,
  CardContent,
  useTheme,
  useMediaQuery,
  Avatar,
  Slide,
  Stack,
  LinearProgress,
  Chip,
  List,
  ListItem,
  ListItemText,
  ListItemAvatar,
  ListItemSecondaryAction
} from '@mui/material';
import {
  Edit as EditIcon,
  Person as PersonIcon,
  PieChart as PieChartIcon,
  Close as CloseIcon,
  Add as AddIcon,
  Refresh as RefreshIcon,
  Group as GroupIcon,
  AccountCircle as AccountCircleIcon,
  ArrowUpward as ArrowUpwardIcon,
  Check as CheckIcon
} from '@mui/icons-material';
import { Pie } from 'react-chartjs-2';
import { FinancialContext } from '../../context/FinancialContext';
import axios from 'axios';

// Transition component for dialogs
const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

// Founder avatar colors
const founderColors = [
  '#007AFF', // Blue
  '#FF2D55', // Pink
  '#FF9500', // Orange
  '#34C759', // Green
  '#5856D6', // Purple
  '#AF52DE', // Purple/Pink
  '#FF3B30', // Red
  '#5AC8FA', // Light Blue
  '#FFCC00', // Yellow
];

export default function FounderContributions() {
  const { founderContributions, loading, error, loadFounderContributions } = useContext(FinancialContext);
  
  // Theme and responsive breakpoints
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const isTablet = useMediaQuery(theme.breakpoints.down('md'));
  
  // Dialog state
  const [openDialog, setOpenDialog] = useState(false);
  const [selectedFounder, setSelectedFounder] = useState(null);
  const [newAmount, setNewAmount] = useState('');
  const [updateLoading, setUpdateLoading] = useState(false);
  const [updateError, setUpdateError] = useState(null);
  const [updateSuccess, setUpdateSuccess] = useState(false);
  
  // Load founder contributions on component mount
  useEffect(() => {
    loadFounderContributions();
  }, [loadFounderContributions]);
  
  // Format currency to Malaysian Ringgit
  const formatCurrency = (amount) => {
    if (amount === undefined || amount === null) return '-';
    return new Intl.NumberFormat('ms-MY', {
      style: 'currency',
      currency: 'MYR'
    }).format(amount);
  };
  
  // Calculate total contributions
  const totalContributions = founderContributions.reduce(
    (total, founder) => total + founder.fundContribution, 
    0
  );
  
  // Get avatar color for a founder based on their name
  const getFounderColor = (name, index) => {
    if (index < founderColors.length) {
      return founderColors[index];
    }
    // Generate a color based on the name if we run out of predefined colors
    const hashCode = name.split('').reduce((hash, char) => {
      return char.charCodeAt(0) + ((hash << 5) - hash);
    }, 0);
    return `hsl(${hashCode % 360}, 70%, 60%)`;
  };
  
  // Get founder initials for avatar
  const getFounderInitials = (name) => {
    if (!name) return '?';
    return name
      .split(' ')
      .map(part => part[0])
      .join('')
      .toUpperCase()
      .substring(0, 2);
  };
  
  // Prepare chart data
  const chartData = {
    labels: founderContributions.map(founder => founder.name),
    datasets: [
      {
        data: founderContributions.map(founder => founder.fundContribution),
        backgroundColor: founderContributions.map((founder, index) => 
          `${getFounderColor(founder.name, index)}CC`
        ),
        borderColor: founderContributions.map((founder, index) => 
          getFounderColor(founder.name, index)
        ),
        borderWidth: 1,
      },
    ],
  };
  
  // Handle dialog open for editing
  const handleEditClick = (founder) => {
    setSelectedFounder(founder);
    setNewAmount(founder.fundContribution.toString());
    setUpdateError(null);
    setUpdateSuccess(false);
    setOpenDialog(true);
  };
  
  // Handle dialog close
  const handleDialogClose = () => {
    setOpenDialog(false);
  };
  
  // Handle contribution update
  const handleUpdate = async () => {
    if (!newAmount || isNaN(parseFloat(newAmount))) {
      setUpdateError('Please enter a valid amount');
      return;
    }
    
    try {
      setUpdateLoading(true);
      setUpdateError(null);
      
      // Make API call to update founder contribution
      await axios.put(`/api/v1/auth/update-contribution/${selectedFounder._id}`, {
        fundContribution: parseFloat(newAmount)
      });
      
      setUpdateSuccess(true);
      setUpdateLoading(false);
      
      // Reload founder contributions data
      setTimeout(() => {
        loadFounderContributions();
        handleDialogClose();
      }, 1500);
      
    } catch (err) {
      setUpdateError(err.response?.data?.error || 'Failed to update contribution');
      setUpdateLoading(false);
    }
  };
  
  if (loading) {
    return (
      <Box sx={{ 
        display: 'flex', 
        flexDirection: 'column',
        alignItems: 'center', 
        justifyContent: 'center', 
        height: '80vh',
        p: 3
      }}>
        <CircularProgress size={isMobile ? 40 : 60} thickness={4} sx={{ mb: 2 }} />
        <Typography variant="h6" color="text.secondary" align="center">
          Loading founder data...
        </Typography>
      </Box>
    );
  }
  
  if (error) {
    return (
      <Box sx={{ p: 3 }}>
        <Paper 
          elevation={2} 
          sx={{ 
            p: 3, 
            borderRadius: 4,
            bgcolor: 'error.light',
            color: 'error.contrastText'
          }}
        >
          <Typography variant="h6" gutterBottom>
            Error Loading Data
          </Typography>
          <Typography variant="body1">
            {error}
          </Typography>
          <Button 
            variant="contained" 
            sx={{ mt: 2 }}
            onClick={loadFounderContributions}
          >
            Try Again
          </Button>
        </Paper>
      </Box>
    );
  }
  
  return (
    <Box sx={{ pb: isMobile ? 7 : 3 }}>
      {/* Header */}
      <Box 
        sx={{ 
          pt: isMobile ? 2 : 3, 
          pb: 2,
          px: isMobile ? 2 : 3,
          background: theme.palette.mode === 'dark' 
            ? `linear-gradient(to right, ${theme.palette.primary.dark}, ${theme.palette.secondary.dark})` 
            : `linear-gradient(to right, ${theme.palette.primary.light}, ${theme.palette.secondary.light})`,
          borderRadius: isMobile ? '0 0 24px 24px' : '0 0 16px 16px',
          mb: 2,
          color: 'white'
        }}
      >
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
          <Typography 
            variant={isMobile ? "h5" : "h4"} 
            sx={{ fontWeight: 600 }}
          >
            Founder Contributions
          </Typography>
          
          <IconButton
            color="inherit"
            onClick={loadFounderContributions}
            sx={{ 
              bgcolor: 'rgba(255,255,255,0.2)',
              '&:hover': {
                bgcolor: 'rgba(255,255,255,0.3)'
              }
            }}
          >
            <RefreshIcon />
          </IconButton>
        </Box>
        
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          <Avatar sx={{ bgcolor: 'white', color: theme.palette.primary.main, mr: 1.5 }}>
            <GroupIcon />
          </Avatar>
          <Box>
            <Typography variant="body2" sx={{ opacity: 0.9 }}>
              Total Contributions
            </Typography>
            <Typography variant="h5" sx={{ fontWeight: 'bold' }}>
              {formatCurrency(totalContributions)}
            </Typography>
          </Box>
        </Box>
      </Box>
      
      {/* Content area */}
      <Box sx={{ px: isMobile ? 2 : 3 }}>
        <Grid container spacing={3}>
          {/* Summary card - Mobile only */}
          {isMobile && (
            <Grid item xs={12}>
              <Card sx={{ borderRadius: 4, boxShadow: '0 2px 10px rgba(0,0,0,0.08)' }}>
                <CardContent>
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 0.5 }}>
                    Number of Founders
                  </Typography>
                  <Typography variant="h5" sx={{ fontWeight: 'bold', mb: 1 }}>
                    {founderContributions.length}
                  </Typography>
                  
                  {founderContributions.length > 0 && (
                    <Stack direction="row" spacing={1} sx={{ mt: 2, overflow: 'auto', pb: 1 }}>
                      {founderContributions.map((founder, index) => (
                        <Chip
                          key={founder._id}
                          avatar={
                            <Avatar sx={{ bgcolor: getFounderColor(founder.name, index) }}>
                              {getFounderInitials(founder.name)}
                            </Avatar>
                          }
                          label={`${((founder.fundContribution / totalContributions) * 100).toFixed(0)}%`}
                          variant="outlined"
                          sx={{ borderRadius: 8 }}
                        />
                      ))}
                    </Stack>
                  )}
                </CardContent>
              </Card>
            </Grid>
          )}
          
          {/* Pie Chart */}
          <Grid item xs={12} md={totalContributions === 0 ? 12 : 6}>
            <Paper elevation={2} sx={{ p: 3, borderRadius: 4, height: '100%', boxShadow: '0 2px 10px rgba(0,0,0,0.08)' }}>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <Avatar sx={{ bgcolor: theme.palette.primary.light, mr: 1, width: 32, height: 32 }}>
                  <PieChartIcon fontSize="small" />
                </Avatar>
                <Typography variant="h6">
                  Contribution Distribution
                </Typography>
              </Box>
              <Divider sx={{ mb: 2 }} />
              <Box sx={{ height: 250, display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                {founderContributions.length > 0 && totalContributions > 0 ? (
                  <Pie
                    data={chartData}
                    options={{
                      responsive: true,
                      maintainAspectRatio: false,
                      plugins: {
                        legend: {
                          position: isTablet ? 'bottom' : 'right',
                          labels: {
                            boxWidth: 12,
                            padding: 15,
                            font: {
                              size: 11
                            }
                          }
                        },
                        tooltip: {
                          callbacks: {
                            label: function(context) {
                              const value = context.raw;
                              const percentage = ((value / totalContributions) * 100).toFixed(1);
                              return `${context.label}: ${formatCurrency(value)} (${percentage}%)`;
                            }
                          }
                        }
                      }
                    }}
                  />
                ) : (
                  <Box sx={{ textAlign: 'center' }}>
                    <Typography variant="body1" color="text.secondary" gutterBottom>
                      No contribution data available
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Update founder contributions to see the distribution chart
                    </Typography>
                  </Box>
                )}
              </Box>
            </Paper>
          </Grid>
          
          {/* Contribution percentages - Desktop only */}
          {!isMobile && totalContributions > 0 && (
            <Grid item md={6}>
              <Paper elevation={2} sx={{ p: 3, borderRadius: 4, height: '100%', boxShadow: '0 2px 10px rgba(0,0,0,0.08)' }}>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <Avatar sx={{ bgcolor: theme.palette.primary.light, mr: 1, width: 32, height: 32 }}>
                    <PersonIcon fontSize="small" />
                  </Avatar>
                  <Typography variant="h6">
                    Equity Distribution
                  </Typography>
                </Box>
                <Divider sx={{ mb: 2 }} />
                <Box>
                  {founderContributions.map((founder, index) => {
                    const percentage = totalContributions > 0 
                      ? (founder.fundContribution / totalContributions) * 100
                      : 0;
                      
                    return (
                      <Box key={founder._id} sx={{ mb: 2 }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', mb: 0.5 }}>
                          <Avatar 
                            sx={{ 
                              width: 28, 
                              height: 28, 
                              mr: 1, 
                              fontSize: '0.8rem',
                              bgcolor: getFounderColor(founder.name, index)
                            }}
                          >
                            {getFounderInitials(founder.name)}
                          </Avatar>
                          <Typography variant="body2" sx={{ flex: 1 }}>
                            {founder.name}
                          </Typography>
                          <Typography variant="body2" sx={{ fontWeight: 'bold' }}>
                            {percentage.toFixed(1)}%
                          </Typography>
                        </Box>
                        <LinearProgress 
                          variant="determinate" 
                          value={percentage} 
                          sx={{ 
                            height: 8, 
                            borderRadius: 4,
                            bgcolor: theme.palette.mode === 'dark' ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.08)',
                            '& .MuiLinearProgress-bar': {
                              bgcolor: getFounderColor(founder.name, index)
                            }
                          }}
                        />
                      </Box>
                    );
                  })}
                </Box>
              </Paper>
            </Grid>
          )}
          
          {/* Contributions List/Table */}
          <Grid item xs={12}>
            <Paper elevation={2} sx={{ borderRadius: 4, overflow: 'hidden', boxShadow: '0 2px 10px rgba(0,0,0,0.08)' }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', p: 2, borderBottom: 1, borderColor: 'divider' }}>
                <Typography variant="h6">
                  Founder Details
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  {founderContributions.length} {founderContributions.length === 1 ? 'Founder' : 'Founders'}
                </Typography>
              </Box>
              
              {/* Mobile List View */}
              {isMobile ? (
                <List disablePadding>
                  {founderContributions.length > 0 ? (
                    founderContributions.map((founder, index) => (
                      <ListItem 
                        key={founder._id}
                        divider
                        button
                        onClick={() => handleEditClick(founder)}
                      >
                        <ListItemAvatar>
                          <Avatar sx={{ bgcolor: getFounderColor(founder.name, index) }}>
                            {getFounderInitials(founder.name)}
                          </Avatar>
                        </ListItemAvatar>
                        <ListItemText
                          primary={founder.name}
                          secondary={
                            <Box sx={{ display: 'flex', alignItems: 'center', mt: 0.5 }}>
                              <Chip 
                                label={`${((founder.fundContribution / totalContributions) * 100).toFixed(1)}%`}
                                size="small"
                                sx={{ 
                                  mr: 1, 
                                  borderRadius: 8,
                                  bgcolor: `${getFounderColor(founder.name, index)}22`,
                                  color: getFounderColor(founder.name, index)
                                }}
                              />
                              <Typography variant="body2" component="span" sx={{ fontWeight: 'medium' }}>
                                {formatCurrency(founder.fundContribution)}
                              </Typography>
                            </Box>
                          }
                        />
                        <ListItemSecondaryAction>
                          <IconButton edge="end" onClick={(e) => {
                            e.stopPropagation();
                            handleEditClick(founder);
                          }}>
                            <EditIcon />
                          </IconButton>
                        </ListItemSecondaryAction>
                      </ListItem>
                    ))
                  ) : (
                    <ListItem>
                      <ListItemText
                        primary="No founder contributions found"
                        secondary="Add founder contributions to see them here"
                        sx={{ textAlign: 'center', py: 3 }}
                      />
                    </ListItem>
                  )}
                </List>
              ) : (
                // Desktop Table View
                <TableContainer>
                  <Table>
                    <TableHead>
                      <TableRow>
                        <TableCell>Founder</TableCell>
                        <TableCell>Contribution Amount</TableCell>
                        <TableCell>Percentage</TableCell>
                        <TableCell align="right">Actions</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {founderContributions.length > 0 ? (
                        founderContributions.map((founder, index) => (
                          <TableRow 
                            key={founder._id} 
                            hover
                            sx={{ 
                              '&:hover': { 
                                bgcolor: theme.palette.action.hover,
                                cursor: 'pointer'
                              }
                            }}
                            onClick={() => handleEditClick(founder)}
                          >
                            <TableCell>
                              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                <Avatar 
                                  sx={{ 
                                    width: 32, 
                                    height: 32, 
                                    mr: 1.5,
                                    bgcolor: getFounderColor(founder.name, index)
                                  }}
                                >
                                  {getFounderInitials(founder.name)}
                                </Avatar>
                                {founder.name}
                              </Box>
                            </TableCell>
                            <TableCell>{formatCurrency(founder.fundContribution)}</TableCell>
                            <TableCell>
                              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                <Typography variant="body2" sx={{ mr: 1 }}>
                                  {totalContributions > 0 
                                    ? `${((founder.fundContribution / totalContributions) * 100).toFixed(1)}%`
                                    : '0%'}
                                </Typography>
                                <LinearProgress 
                                  variant="determinate" 
                                  value={totalContributions > 0 ? (founder.fundContribution / totalContributions) * 100 : 0} 
                                  sx={{ 
                                    width: 60, 
                                    height: 6, 
                                    borderRadius: 3,
                                    '& .MuiLinearProgress-bar': {
                                      bgcolor: getFounderColor(founder.name, index)
                                    }
                                  }}
                                />
                              </Box>
                            </TableCell>
                            <TableCell align="right">
                              <Tooltip title="Edit Contribution">
                                <IconButton 
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleEditClick(founder);
                                  }} 
                                  color="primary" 
                                  size="small"
                                >
                                  <EditIcon fontSize="small" />
                                </IconButton>
                              </Tooltip>
                            </TableCell>
                          </TableRow>
                        ))
                      ) : (
                        <TableRow>
                          <TableCell colSpan={4} align="center">
                            <Typography variant="body1" sx={{ py: 3 }}>
                              No founder contributions found
                            </Typography>
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </TableContainer>
              )}
            </Paper>
          </Grid>
        </Grid>
      </Box>
      
      {/* Edit Contribution Dialog */}
      <Dialog 
        open={openDialog} 
        onClose={updateLoading ? undefined : handleDialogClose}
        TransitionComponent={Transition}
        fullScreen={isMobile}
        PaperProps={{
          sx: {
            borderRadius: isMobile ? 0 : 4
          }
        }}
      >
        <DialogTitle sx={{ 
          bgcolor: theme.palette.primary.main, 
          color: theme.palette.primary.contrastText,
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}>
          Update Contribution Amount
          {isMobile && (
            <IconButton edge="end" color="inherit" onClick={handleDialogClose} disabled={updateLoading}>
              <CloseIcon />
            </IconButton>
          )}
        </DialogTitle>
        
        <DialogContent sx={{ pt: 3 }}>
          {updateError && (
            <Alert severity="error" sx={{ mb: 2, borderRadius: 2 }}>
              {updateError}
            </Alert>
          )}
          
          {updateSuccess && (
            <Alert 
              severity="success" 
              sx={{ mb: 2, borderRadius: 2 }}
              icon={<CheckIcon />}
            >
              Contribution updated successfully!
            </Alert>
          )}
          
          {selectedFounder && (
            <Box sx={{ pt: 1 }}>
              <Grid container spacing={2} alignItems="center" sx={{ mb: 3 }}>
                <Grid item>
                  <Avatar 
                    sx={{ 
                      width: 56, 
                      height: 56, 
                      bgcolor: getFounderColor(selectedFounder.name, founderContributions.findIndex(f => f._id === selectedFounder._id)) 
                    }}
                  >
                    {getFounderInitials(selectedFounder.name)}
                  </Avatar>
                </Grid>
                <Grid item xs>
                  <Typography variant="h6" sx={{ fontWeight: 'medium' }}>
                    {selectedFounder.name}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Current contribution: {formatCurrency(selectedFounder.fundContribution)}
                  </Typography>
                </Grid>
              </Grid>
              
              <TextField
                autoFocus
                margin="dense"
                label="New Contribution Amount"
                type="number"
                fullWidth
                value={newAmount}
                onChange={(e) => setNewAmount(e.target.value)}
                InputProps={{
                  startAdornment: <InputAdornment position="start">RM</InputAdornment>,
                  sx: { borderRadius: 4 }
                }}
                disabled={updateLoading}
                sx={{ mb: 2 }}
              />
              
              <Typography variant="body2" color="text.secondary">
                This will adjust the equity percentage based on the updated contribution.
              </Typography>
            </Box>
          )}
        </DialogContent>
        
        <DialogActions sx={{ px: 3, pb: 3 }}>
          <Button 
            onClick={handleDialogClose} 
            disabled={updateLoading}
            sx={{ borderRadius: 8 }}
          >
            Cancel
          </Button>
          <Button 
            onClick={handleUpdate} 
            variant="contained" 
            color="primary"
            disabled={updateLoading}
            startIcon={updateLoading ? <CircularProgress size={20} /> : <ArrowUpwardIcon />}
            sx={{ borderRadius: 8 }}
          >
            Update
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
} 