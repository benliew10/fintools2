import React, { useEffect, useContext, useState } from 'react';
import {
  Container,
  Typography,
  Box,
  Button,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  CircularProgress,
  Grid,
  Chip,
  Tooltip,
  TablePagination,
  InputAdornment,
  Divider,
  Alert,
  Card,
  CardContent,
  Avatar,
  Fab,
  Stack,
  LinearProgress,
  FormControlLabel,
  Switch
} from '@mui/material';
import {
  Add as AddIcon,
  Delete as DeleteIcon,
  Edit as EditIcon,
  Visibility as VisibilityIcon,
  Search as SearchIcon,
  MonetizationOn as SellIcon,
  Inventory as InventoryIcon,
  Phone as PhoneIcon,
  Cable as AccessoriesIcon,
  ShoppingBag as SoldIcon,
  ShoppingCart as ShoppingCartIcon,
  AttachMoney as MoneyIcon,
  Headphones as HeadphonesIcon,
  Devices as DevicesIcon,
  Close as CloseIcon,
  FilterAlt as FilterAltIcon,
  Check as CheckIcon,
  AccessTime as TimeIcon,
  ShoppingBag as ShoppingBagIcon,
  MoneyOff as MoneyOffIcon
} from '@mui/icons-material';
import { FinancialContext } from '../../context/FinancialContext';
import { AuthContext } from '../../context/AuthContext';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { LocalizationProvider, DatePicker } from '@mui/x-date-pickers';
import { format } from 'date-fns';
import { useTheme } from '@mui/material/styles';
import { useMediaQuery } from '@mui/material';

// Product categories
const categories = ['Phone', 'Accessories', 'Other'];

export default function Products() {
  const {
    products,
    loadProducts,
    productsLoading,
    productsLoaded,
    addProduct,
    updateProduct,
    deleteProduct,
    markProductAsSold,
    loading,
    error: contextError,
    loadFinancialSummary,
    loadRevenues
  } = useContext(FinancialContext);

  const { /* user */ } = useContext(AuthContext);

  // Dialog state
  const [openDialog, setOpenDialog] = useState(false);
  const [openSellDialog, setOpenSellDialog] = useState(false);
  const [dialogMode, setDialogMode] = useState('add'); // 'add' or 'edit'
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [viewDialog, setViewDialog] = useState(false);
  const [deleteConfirmDialog, setDeleteConfirmDialog] = useState(false);

  // Form state
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    category: 'Phone',
    purchasePrice: '',
    sellingPrice: '',
    quantity: 1,
    purchaseDate: new Date(),
    supplier: '',
    serialNumber: '',
    isAsset: true,
    assetValue: '',
    notes: ''
  });

  // Sell dialog form state
  const [sellFormData, setSelFormData] = useState({
    sellingPrice: '',
    soldDate: new Date(),
    notes: ''
  });

  // Table pagination
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  // Search and filter
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('all'); // 'all', 'inStock', 'sold'
  const [error, setError] = useState(null);

  // Add a state for deletion loading
  const [isDeleting, setIsDeleting] = useState(false);

  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

  // Function to refresh data after operations
  const refreshData = async () => {
    try {
      await loadProducts();
      await loadFinancialSummary();
    } catch (err) {
      console.error('Error refreshing data:', err);
    }
  };

  // Load products on component mount only if not already loaded
  useEffect(() => {
    const fetchData = async () => {
      // Only load products if they're not already loaded and not currently loading
      if (!productsLoaded && !productsLoading) {
        try {
          await loadProducts();
        } catch (err) {
          console.error("Failed to load products:", err);
        }
      }
    };
    
    fetchData();
  }, [loadProducts, productsLoaded, productsLoading]);

  // Format currency with Malaysian Ringgit
  const formatCurrency = (amount) => {
    if (!amount && amount !== 0) return '-';
    return new Intl.NumberFormat('en-MY', {
      style: 'currency',
      currency: 'MYR',
      minimumFractionDigits: 2
    }).format(amount);
  };

  // Format date
  const formatDate = (dateString) => {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return format(date, 'dd MMM yyyy');
  };

  // Get category icon
  const getCategoryIcon = (category) => {
    switch(category) {
      case 'Phone':
        return <PhoneIcon />;
      case 'Accessories':
        return <HeadphonesIcon />;
      default:
        return <DevicesIcon />;
    }
  };

  // Get category color
  const getCategoryColor = (category) => {
    const colorMap = {
      'Phone': '#007AFF',      // blue
      'Accessories': '#FF9500', // orange
      'Other': '#8E8E93'       // gray
    };
    
    return colorMap[category] || '#8E8E93';
  };
  
  // Calculate stats
  const totalProducts = products.length;
  const inStockProducts = products.filter(product => product.inStock).length;
  const soldProducts = products.filter(product => !product.inStock).length;
  
  const totalValue = products
    .filter(product => product.inStock)
    .reduce((sum, product) => sum + (product.assetValue || product.purchasePrice), 0);
    
  const totalPotentialProfit = products
    .filter(product => product.inStock && product.sellingPrice)
    .reduce((sum, product) => {
      const profit = product.sellingPrice - product.purchasePrice;
      return sum + (profit * product.quantity);
    }, 0);
    
  const productsByCategory = {};
  categories.forEach(category => {
    const categoryProducts = products.filter(product => product.category === category && product.inStock);
    const count = categoryProducts.length;
    const value = categoryProducts.reduce((sum, product) => sum + (product.assetValue || product.purchasePrice), 0);
    
    productsByCategory[category] = { count, value };
  });

  // Handle add product click
  const handleAddClick = () => {
    setDialogMode('add');
    setFormData({
      name: '',
      description: '',
      category: 'Phone',
      purchasePrice: '',
      sellingPrice: '',
      quantity: 1,
      purchaseDate: new Date(),
      supplier: '',
      serialNumber: '',
      isAsset: true,
      assetValue: '',
      notes: ''
    });
    setOpenDialog(true);
  };
  
  // Handle edit product click
  const handleEditClick = (product) => {
    setDialogMode('edit');
    setSelectedProduct(product);
    setFormData({
      name: product.name,
      description: product.description || '',
      category: product.category,
      purchasePrice: product.purchasePrice,
      sellingPrice: product.sellingPrice || '',
      quantity: product.quantity,
      purchaseDate: new Date(product.purchaseDate),
      supplier: product.supplier || '',
      serialNumber: product.serialNumber || '',
      isAsset: Boolean(product.assetValue),
      assetValue: product.assetValue || '',
      notes: product.notes || ''
    });
    setOpenDialog(true);
  };
  
  // Handle sell product click
  const handleSellClick = (product) => {
    setSelectedProduct(product);
    setSelFormData({
      sellingPrice: product.sellingPrice || product.purchasePrice,
      soldDate: new Date(),
      notes: product.notes || ''
    });
    setOpenSellDialog(true);
  };
  
  // Handle view product click
  const handleViewClick = (product) => {
    setSelectedProduct(product);
    setViewDialog(true);
  };
  
  // Handle delete product click
  const handleDeleteClick = (product) => {
    setSelectedProduct(product);
    setDeleteConfirmDialog(true);
  };
  
  // Handle dialog close
  const handleDialogClose = () => {
    setOpenDialog(false);
    setOpenSellDialog(false);
    setViewDialog(false);
    setDeleteConfirmDialog(false);
  };
  
  // Handle input change for form data
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };
  
  // Handle input change for sell form data
  const handleSellInputChange = (e) => {
    const { name, value } = e.target;
    setSelFormData({
      ...sellFormData,
      [name]: value
    });
  };
  
  // Handle form submit
  const handleSubmit = async () => {
    try {
      setError(null); // Clear any previous errors
      
      let result;
      if (dialogMode === 'add') {
        console.log('Adding new product:', formData);
        result = await addProduct(formData);
      } else {
        console.log(`Updating product ${selectedProduct._id}:`, formData);
        result = await updateProduct(selectedProduct._id, formData);
      }
      
      if (result) {
        console.log('Product saved successfully');
        handleDialogClose();
        await refreshData();
      } else {
        // Error already set in context
        console.error(`Save failed with error in context: ${contextError}`);
        if (contextError) {
          setError(contextError);
        } else {
          setError(`Failed to ${dialogMode === 'add' ? 'add' : 'update'} product: Unknown error`);
        }
      }
    } catch (err) {
      console.error("Error saving product:", err);
      setError(`Failed to ${dialogMode === 'add' ? 'add' : 'update'} product: ${err.message || 'Unknown error'}`);
    }
  };
  
  // Handle sell product form submit
  const handleSellProduct = async () => {
    try {
      setError(null); // Clear any previous errors
      
      console.log(`Marking product ${selectedProduct._id} as sold:`, sellFormData);
      
      // Ensure all required data is included
      const saleData = {
        sellingPrice: parseFloat(sellFormData.sellingPrice),
        soldDate: sellFormData.soldDate,
        notes: sellFormData.notes || '',
        quantity: selectedProduct.quantity // Selling all available quantity
      };
      
      console.log('About to call markProductAsSold with data:', saleData);
      
      const result = await markProductAsSold(selectedProduct._id, saleData);
      console.log('markProductAsSold result:', result);
      
      if (result) {
        console.log('Product marked as sold successfully');
        // Show a success message
        handleDialogClose();
        
        // Use the single refreshData function instead of multiple separate calls
        console.log('Refreshing data after product sale');
        await refreshData();
      } else {
        // Error already set in context
        console.error(`Operation failed with error in context: ${contextError}`);
        if (contextError) {
          setError(contextError);
        } else {
          setError("Failed to mark product as sold: Unknown error");
        }
      }
    } catch (err) {
      console.error("Error marking product as sold:", err);
      setError(`Failed to mark product as sold: ${err.message || 'Unknown error'}`);
    }
  };
  
  // Handle delete product confirm
  const handleDeleteConfirm = async () => {
    try {
      setIsDeleting(true);
      setError(null); // Clear any previous errors
      
      console.log(`Attempting to delete product with ID: ${selectedProduct._id}`);
      
      // Keep the dialog open during deletion attempt
      const result = await deleteProduct(selectedProduct._id);
      console.log(`Delete product result: ${result}`);
      
      if (result) {
        console.log('Product deleted successfully, closing dialog');
        handleDialogClose();
        // Could add a success toast notification here
      } else {
        // Error was set in the context
        console.error(`Delete product failed: ${contextError || 'No specific error provided'}`);
        
        // Keep dialog open to show error
        if (contextError) {
          setError(contextError);
        } else {
          setError("Failed to delete product. Please try again later.");
        }
      }
    } catch (err) {
      console.error("Error in handleDeleteConfirm:", err);
      setError(`Failed to delete product: ${err.message || 'An unexpected error occurred'}`);
    } finally {
      setIsDeleting(false);
    }
  };
  
  // Handle page change
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };
  
  // Handle rows per page change
  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  // Filter products
  const filteredProducts = products.filter(product => {
    const matchesSearch = (
      (product.name && product.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (product.description && product.description.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (product.supplier && product.supplier.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (product.serialNumber && product.serialNumber.toLowerCase().includes(searchTerm.toLowerCase()))
    );
    
    const matchesCategory = !categoryFilter || product.category === categoryFilter;
    const matchesStatus = !statusFilter || 
      (statusFilter === 'all' && true) || 
      (statusFilter === 'inStock' && product.inStock) || 
      (statusFilter === 'sold' && !product.inStock);
    
    return matchesSearch && matchesCategory && matchesStatus;
  });

  // Paginated products
  const paginatedProducts = filteredProducts.slice(
    page * rowsPerPage,
    page * rowsPerPage + rowsPerPage
  );

  // Enhanced error display with action
  if (error) {
    return (
      <Box sx={{ p: 3 }}>
        <Alert 
          severity="error" 
          action={
            <Button color="inherit" size="small" onClick={() => loadProducts()}>
              Retry
            </Button>
          }
        >
          {error}
        </Alert>
      </Box>
    );
  }

  // Show loading indicator when data is loading
  if (productsLoading) {
    return (
      <Box sx={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', height: '80vh' }}>
        <CircularProgress size={60} thickness={4} sx={{ mb: 2 }} />
        <Typography variant="h6" color="text.secondary">
          Loading Products Data...
        </Typography>
      </Box>
    );
  }

  return (
    <Box sx={{ p: isMobile ? 1 : 3 }}>
      {/* Header with Title and Add Button */}
      <Box sx={{ 
        display: 'flex', 
        justifyContent: 'space-between', 
        alignItems: 'center', 
        mb: 3,
        px: isMobile ? 1 : 0
      }}>
        <Typography 
          variant={isMobile ? 'h5' : 'h4'} 
          component="h1" 
          sx={{ 
            fontWeight: 700,
            fontSize: isMobile ? '1.5rem' : '2.125rem',
            background: 'linear-gradient(45deg, #FF9500, #FF2D55)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent'
          }}
        >
          Products
        </Typography>
        
        {!isMobile && (
          <Button
            variant="contained"
            color="primary"
            startIcon={<AddIcon />}
            onClick={handleAddClick}
            sx={{ 
              borderRadius: 3,
              px: 3,
              py: 1,
              boxShadow: '0 4px 10px rgba(0, 122, 255, 0.3)',
              fontWeight: 600
            }}
          >
            Add Product
          </Button>
        )}
      </Box>
      
      {/* Stats Cards */}
      <Grid container spacing={isMobile ? 2 : 3} sx={{ mb: 3 }}>
        <Grid item xs={12} md={6} lg={3}>
          <Card 
            elevation={0}
            className="ios-shadow"
            sx={{ 
              borderRadius: 4,
              height: '100%',
              overflow: 'hidden',
              background: 'linear-gradient(135deg, rgba(255,255,255,0.9) 0%, rgba(255,255,255,1) 100%)',
              backdropFilter: 'blur(20px)',
            }}
          >
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <Box
                  sx={{
                    width: 50,
                    height: 50,
                    borderRadius: '50%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    mr: 2,
                    background: 'linear-gradient(45deg, #007AFF, #007AFFCC)',
                    boxShadow: '0 4px 10px rgba(0, 122, 255, 0.2)'
                  }}
                >
                  <InventoryIcon sx={{ color: 'white', fontSize: 28 }} />
                </Box>
                <Box>
                  <Typography variant="body2" color="text.secondary">
                    Total Inventory Value
                  </Typography>
                  <Typography variant="h5" component="div" sx={{ fontWeight: 700 }}>
                    {formatCurrency(totalValue)}
                  </Typography>
                </Box>
              </Box>
              
              <Divider sx={{ my: 2 }} />
              
              <Grid container spacing={2}>
                <Grid item xs={6}>
                  <Typography variant="body2" color="text.secondary">
                    In Stock
                  </Typography>
                  <Typography variant="h6" sx={{ fontWeight: 600 }}>
                    {inStockProducts} items
                  </Typography>
                </Grid>
                <Grid item xs={6}>
                  <Typography variant="body2" color="text.secondary">
                    Sold
                  </Typography>
                  <Typography variant="h6" sx={{ fontWeight: 600 }}>
                    {soldProducts} items
                  </Typography>
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={12} md={6} lg={3}>
          <Card 
            elevation={0}
            className="ios-shadow"
            sx={{ 
              borderRadius: 4,
              height: '100%',
              overflow: 'hidden',
              background: 'linear-gradient(135deg, rgba(255,255,255,0.9) 0%, rgba(255,255,255,1) 100%)',
              backdropFilter: 'blur(20px)',
            }}
          >
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <Box
                  sx={{
                    width: 50,
                    height: 50,
                    borderRadius: '50%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    mr: 2,
                    background: 'linear-gradient(45deg, #34C759, #34C759CC)',
                    boxShadow: '0 4px 10px rgba(52, 199, 89, 0.2)'
                  }}
                >
                  <MoneyIcon sx={{ color: 'white', fontSize: 28 }} />
                </Box>
                <Box>
                  <Typography variant="body2" color="text.secondary">
                    Potential Profit
                  </Typography>
                  <Typography variant="h5" component="div" sx={{ fontWeight: 700 }}>
                    {formatCurrency(totalPotentialProfit)}
                  </Typography>
                </Box>
              </Box>
              
              <Divider sx={{ my: 2 }} />
              
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                    Profit Margin
                  </Typography>
                  <LinearProgress 
                    variant="determinate" 
                    value={totalValue > 0 ? (totalPotentialProfit / totalValue) * 100 : 0}
                    sx={{ 
                      height: 8,
                      borderRadius: 4,
                      backgroundColor: 'rgba(0,0,0,0.04)',
                      '& .MuiLinearProgress-bar': {
                        backgroundColor: '#34C759',
                      }
                    }} 
                  />
                  <Typography variant="body2" sx={{ mt: 1, fontWeight: 500 }}>
                    {totalValue > 0 ? `${((totalPotentialProfit / totalValue) * 100).toFixed(1)}%` : '0%'}
                  </Typography>
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={12} sm={6} lg={3}>
          <Card 
            elevation={0}
            className="ios-shadow"
            sx={{ 
              borderRadius: 4,
              height: '100%',
              overflow: 'hidden',
              background: 'linear-gradient(135deg, rgba(255,255,255,0.9) 0%, rgba(255,255,255,1) 100%)',
              backdropFilter: 'blur(20px)',
            }}
          >
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <Box
                  sx={{
                    width: 50,
                    height: 50,
                    borderRadius: '50%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    mr: 2,
                    background: 'linear-gradient(45deg, #FF9500, #FF9500CC)',
                    boxShadow: '0 4px 10px rgba(255, 149, 0, 0.2)'
                  }}
                >
                  <PhoneIcon sx={{ color: 'white', fontSize: 28 }} />
                </Box>
                <Box>
                  <Typography variant="body2" color="text.secondary">
                    Phones
                  </Typography>
                  <Typography variant="h5" component="div" sx={{ fontWeight: 700 }}>
                    {productsByCategory['Phone']?.count || 0}
                  </Typography>
                </Box>
              </Box>
              
              <Typography variant="body2" color="text.secondary" sx={{ mb: 0.5 }}>
                Total Value
              </Typography>
              <Typography variant="body1" sx={{ fontWeight: 600 }}>
                {formatCurrency(productsByCategory['Phone']?.value || 0)}
              </Typography>
              
              <Box sx={{ mt: 2, display: 'flex', justifyContent: 'flex-end' }}>
                <Chip 
                  label="View Phones" 
                  size="small" 
                  onClick={() => setCategoryFilter('Phone')}
                  sx={{ 
                    fontWeight: 500, 
                    borderRadius: 3,
                    bgcolor: 'rgba(255, 149, 0, 0.1)',
                    color: '#FF9500'
                  }} 
                />
              </Box>
            </CardContent>
          </Card>
        </Grid>
        
        <Grid item xs={12} sm={6} lg={3}>
          <Card 
            elevation={0}
            className="ios-shadow"
            sx={{ 
              borderRadius: 4,
              height: '100%',
              overflow: 'hidden',
              background: 'linear-gradient(135deg, rgba(255,255,255,0.9) 0%, rgba(255,255,255,1) 100%)',
              backdropFilter: 'blur(20px)',
            }}
          >
            <CardContent>
              <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                <Box
                  sx={{
                    width: 50,
                    height: 50,
                    borderRadius: '50%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    mr: 2,
                    background: 'linear-gradient(45deg, #5856D6, #5856D6CC)',
                    boxShadow: '0 4px 10px rgba(88, 86, 214, 0.2)'
                  }}
                >
                  <HeadphonesIcon sx={{ color: 'white', fontSize: 28 }} />
                </Box>
                <Box>
                  <Typography variant="body2" color="text.secondary">
                    Accessories
                  </Typography>
                  <Typography variant="h5" component="div" sx={{ fontWeight: 700 }}>
                    {productsByCategory['Accessories']?.count || 0}
                  </Typography>
                </Box>
              </Box>
              
              <Typography variant="body2" color="text.secondary" sx={{ mb: 0.5 }}>
                Total Value
              </Typography>
              <Typography variant="body1" sx={{ fontWeight: 600 }}>
                {formatCurrency(productsByCategory['Accessories']?.value || 0)}
              </Typography>
              
              <Box sx={{ mt: 2, display: 'flex', justifyContent: 'flex-end' }}>
                <Chip 
                  label="View Accessories" 
                  size="small" 
                  onClick={() => setCategoryFilter('Accessories')}
                  sx={{ 
                    fontWeight: 500, 
                    borderRadius: 3,
                    bgcolor: 'rgba(88, 86, 214, 0.1)',
                    color: '#5856D6'
                  }} 
                />
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
      
      {/* Search and Filter Section */}
      <Box sx={{ 
        mb: 3, 
        display: 'flex', 
        flexDirection: isMobile ? 'column' : 'row',
        gap: 2,
        alignItems: isMobile ? 'stretch' : 'center',
        px: isMobile ? 1 : 0
      }}>
        <TextField
          placeholder="Search products..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          variant="outlined"
          fullWidth={isMobile}
          sx={{ 
            flex: 1,
            '& .MuiOutlinedInput-root': {
              borderRadius: 3,
              backgroundColor: 'rgba(0,0,0,0.02)'
            }
          }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon sx={{ color: 'text.secondary' }} />
              </InputAdornment>
            ),
          }}
        />
        
        <Box sx={{ display: 'flex', gap: 2 }}>
          <FormControl sx={{ minWidth: 140 }}>
            <InputLabel id="category-filter-label">Category</InputLabel>
            <Select
              labelId="category-filter-label"
              id="category-filter"
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              label="Category"
              sx={{ 
                borderRadius: 3,
                backgroundColor: 'rgba(0,0,0,0.02)'
              }}
            >
              <MenuItem value="">All</MenuItem>
              {categories.map(category => (
                <MenuItem key={category} value={category}>{category}</MenuItem>
              ))}
            </Select>
          </FormControl>
          
          <FormControl sx={{ minWidth: 140 }}>
            <InputLabel id="status-filter-label">Status</InputLabel>
            <Select
              labelId="status-filter-label"
              id="status-filter"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              label="Status"
              sx={{ 
                borderRadius: 3,
                backgroundColor: 'rgba(0,0,0,0.02)'
              }}
            >
              <MenuItem value="all">All</MenuItem>
              <MenuItem value="inStock">In Stock</MenuItem>
              <MenuItem value="sold">Sold</MenuItem>
            </Select>
          </FormControl>
        </Box>
      </Box>
      
      {/* Product List */}
      {productsLoading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '200px' }}>
          <CircularProgress />
        </Box>
      ) : (
        <>
          {paginatedProducts.length > 0 ? (
            <Grid container spacing={isMobile ? 2 : 3}>
              {paginatedProducts.map((product) => (
                <Grid item xs={12} sm={6} md={4} lg={3} key={product._id}>
                  <Card 
                    elevation={0}
                    className="ios-shadow"
                    sx={{ 
                      borderRadius: 4,
                      overflow: 'hidden',
                      position: 'relative',
                      height: '100%',
                      '&:hover': {
                        '& .product-actions': {
                          opacity: 1
                        }
                      }
                    }}
                  >
                    <Box 
                      sx={{ 
                        height: 8, 
                        width: '100%', 
                        backgroundColor: product.inStock ? getCategoryColor(product.category) : '#8E8E93' 
                      }} 
                    />
                    <CardContent>
                      {!product.inStock && (
                        <Chip 
                          label="Sold" 
                          size="small"
                          color="default"
                          sx={{ 
                            position: 'absolute',
                            top: 12,
                            right: 12,
                            fontWeight: 500,
                            backgroundColor: 'rgba(142, 142, 147, 0.2)'
                          }}
                        />
                      )}
                      
                      <Box sx={{ display: 'flex', alignItems: 'flex-start', mb: 2 }}>
                        <Avatar
                          sx={{ 
                            width: 40, 
                            height: 40,
                            bgcolor: `${getCategoryColor(product.category)}20`,
                            color: product.inStock ? getCategoryColor(product.category) : '#8E8E93',
                            mr: 1.5
                          }}
                        >
                          {getCategoryIcon(product.category)}
                        </Avatar>
                        <Box sx={{ flex: 1 }}>
                          <Typography variant="h6" component="div" sx={{ 
                            fontWeight: 600, 
                            color: product.inStock ? 'text.primary' : 'text.secondary'
                          }}>
                            {product.name}
                          </Typography>
                          <Typography variant="body2" color="text.secondary">
                            {product.category} • ID: {product.serialNumber || '-'}
                          </Typography>
                        </Box>
                      </Box>
                      
                      <Grid container spacing={1} sx={{ mb: 1 }}>
                        <Grid item xs={6}>
                          <Typography variant="caption" color="text.secondary" display="block">
                            Purchase Price
                          </Typography>
                          <Typography variant="body1" sx={{ fontWeight: 500 }}>
                            {formatCurrency(product.purchasePrice)}
                          </Typography>
                        </Grid>
                        <Grid item xs={6}>
                          <Typography variant="caption" color="text.secondary" display="block">
                            {product.inStock ? 'Selling Price' : 'Sold For'}
                          </Typography>
                          <Typography variant="body1" sx={{ 
                            fontWeight: 600,
                            color: product.inStock && product.sellingPrice ? 'secondary.main' : 'text.primary'
                          }}>
                            {formatCurrency(product.inStock ? product.sellingPrice : product.soldPrice)}
                          </Typography>
                        </Grid>
                      </Grid>
                      
                      <Divider sx={{ my: 1.5 }} />
                      
                      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                          <TimeIcon 
                            fontSize="small" 
                            sx={{ 
                              mr: 0.5, 
                              color: 'text.secondary',
                              fontSize: '0.875rem',
                              opacity: 0.7
                            }} 
                          />
                          <Typography variant="body2" color="text.secondary">
                            {formatDate(product.inStock ? product.purchaseDate : product.soldDate)}
                          </Typography>
                        </Box>
                        {product.quantity > 1 && (
                          <Typography variant="body2" sx={{ fontWeight: 500 }}>
                            Qty: {product.quantity}
                          </Typography>
                        )}
                      </Box>
                      
                      <Box 
                        className="product-actions"
                        sx={{ 
                          mt: 2, 
                          display: 'flex', 
                          justifyContent: 'flex-end',
                          opacity: { xs: 1, sm: 0 },
                          transition: 'opacity 0.2s',
                          gap: 1
                        }}
                      >
                        {product.inStock ? (
                          <>
                            <Tooltip title="Mark as Sold">
                              <IconButton 
                                size="small" 
                                onClick={() => handleSellClick(product)}
                                sx={{ 
                                  backgroundColor: 'rgba(52, 199, 89, 0.1)',
                                  color: '#34C759',
                                  '&:hover': {
                                    backgroundColor: 'rgba(52, 199, 89, 0.2)',
                                  }
                                }}
                              >
                                <ShoppingCartIcon fontSize="small" />
                              </IconButton>
                            </Tooltip>
                            <Tooltip title="Edit">
                              <IconButton 
                                size="small" 
                                onClick={() => handleEditClick(product)}
                                sx={{ 
                                  backgroundColor: 'rgba(0, 122, 255, 0.1)',
                                  color: '#007AFF',
                                  '&:hover': {
                                    backgroundColor: 'rgba(0, 122, 255, 0.2)',
                                  }
                                }}
                              >
                                <EditIcon fontSize="small" />
                              </IconButton>
                            </Tooltip>
                          </>
                        ) : (
                          <Tooltip title="View Details">
                            <IconButton 
                              size="small" 
                              onClick={() => handleViewClick(product)}
                              sx={{ 
                                backgroundColor: 'rgba(142, 142, 147, 0.1)',
                                color: '#8E8E93',
                                '&:hover': {
                                  backgroundColor: 'rgba(142, 142, 147, 0.2)',
                                }
                              }}
                            >
                              <ShoppingBagIcon fontSize="small" />
                            </IconButton>
                          </Tooltip>
                        )}
                        <Tooltip title="Delete">
                          <IconButton 
                            size="small" 
                            onClick={() => handleDeleteClick(product)}
                            sx={{ 
                              backgroundColor: 'rgba(255, 59, 48, 0.1)',
                              color: '#FF3B30',
                              '&:hover': {
                                backgroundColor: 'rgba(255, 59, 48, 0.2)',
                              }
                            }}
                          >
                            <DeleteIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      </Box>
                    </CardContent>
                  </Card>
                </Grid>
              ))}
            </Grid>
          ) : (
            <Box 
              sx={{ 
                p: 3, 
                textAlign: 'center', 
                borderRadius: 4,
                backgroundColor: 'rgba(0,0,0,0.02)',
                mt: 4
              }}
            >
              <MoneyOffIcon sx={{ fontSize: 48, color: 'text.secondary', opacity: 0.5, mb: 2 }} />
              <Typography variant="h6" color="text.secondary">
                No products found
              </Typography>
              <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                {searchTerm || categoryFilter || statusFilter !== 'all' ? 
                  "Try adjusting your search or filters" : 
                  "Add your first product to get started"}
              </Typography>
              
              {(searchTerm || categoryFilter || statusFilter !== 'all') && (
                <Button
                  variant="outlined"
                  color="primary"
                  onClick={() => {
                    setSearchTerm('');
                    setCategoryFilter('');
                    setStatusFilter('all');
                  }}
                  sx={{ mt: 2, borderRadius: 3 }}
                >
                  Clear Filters
                </Button>
              )}
            </Box>
          )}
        </>
      )}
      
      {/* Pagination */}
      {paginatedProducts.length > 0 && (
        <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4, mb: 2 }}>
          <Button
            disabled={page === 0}
            onClick={() => setPage(page - 1)}
            sx={{ borderRadius: 3, mr: 1 }}
          >
            Previous
          </Button>
          <Typography variant="body1" sx={{ mx: 2, display: 'flex', alignItems: 'center' }}>
            Page {page + 1} of {Math.ceil(filteredProducts.length / rowsPerPage)}
          </Typography>
          <Button
            disabled={page >= Math.ceil(filteredProducts.length / rowsPerPage) - 1}
            onClick={() => setPage(page + 1)}
            sx={{ borderRadius: 3, ml: 1 }}
          >
            Next
          </Button>
        </Box>
      )}
      
      {/* Mobile Fab for Adding Product */}
      {isMobile && (
        <Fab
          color="primary"
          aria-label="add"
          onClick={handleAddClick}
          sx={{
            position: 'fixed',
            bottom: 80,
            right: 16,
            boxShadow: '0 4px 14px rgba(0, 122, 255, 0.5)',
          }}
        >
          <AddIcon />
        </Fab>
      )}

      {/* Add/Edit Product Dialog */}
      <Dialog 
        open={openDialog} 
        onClose={() => {
          // Only allow closing if not currently loading
          if (!loading) {
            handleDialogClose();
            setError(null);
          }
        }}
        maxWidth="md" 
        fullWidth
        fullScreen={isMobile}
        PaperProps={{
          sx: {
            borderRadius: isMobile ? 0 : 4,
            overflow: 'hidden'
          }
        }}
      >
        <DialogTitle sx={{ 
          backgroundColor: 'rgba(0,0,0,0.02)', 
          borderBottom: '1px solid rgba(0,0,0,0.05)',
          py: 2,
          px: 3
        }}>
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <Typography variant="h6" sx={{ fontWeight: 600 }}>
              {dialogMode === 'add' ? 'Add New Product' : 'Edit Product'}
            </Typography>
            <IconButton 
              edge="end" 
              onClick={() => {
                if (!loading) {
                  handleDialogClose();
                  setError(null);
                }
              }}
              disabled={loading}
              sx={{ 
                bgcolor: 'rgba(0,0,0,0.05)',
                '&:hover': {
                  bgcolor: 'rgba(0,0,0,0.1)',
                }
              }}
            >
              <CloseIcon />
            </IconButton>
          </Box>
        </DialogTitle>
        <DialogContent sx={{ pt: 2 }}>
          {error && (
            <Alert 
              severity="error" 
              sx={{ mb: 2, borderRadius: 2 }}
            >
              {error}
            </Alert>
          )}
          
          <Box component="form" noValidate sx={{ mt: 1 }}>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  fullWidth
                  label="Product Name"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  sx={{ 
                    '& .MuiOutlinedInput-root': {
                      borderRadius: 3,
                    }
                  }}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <FormControl fullWidth required>
                  <InputLabel>Category</InputLabel>
                  <Select
                    name="category"
                    value={formData.category}
                    onChange={handleInputChange}
                    label="Category"
                    sx={{ 
                      '& .MuiOutlinedInput-root': {
                        borderRadius: 3,
                      }
                    }}
                  >
                    {categories.map(category => (
                      <MenuItem key={category} value={category}>
                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                          <Box 
                            sx={{ 
                              display: 'flex', 
                              mr: 1, 
                              color: getCategoryColor(category)
                            }}
                          >
                            {getCategoryIcon(category)}
                          </Box>
                          {category}
                        </Box>
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  fullWidth
                  label="Purchase Price"
                  name="purchasePrice"
                  type="number"
                  value={formData.purchasePrice}
                  onChange={handleInputChange}
                  InputProps={{
                    startAdornment: <InputAdornment position="start">RM</InputAdornment>,
                  }}
                  sx={{ 
                    '& .MuiOutlinedInput-root': {
                      borderRadius: 3,
                    }
                  }}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Expected Selling Price"
                  name="sellingPrice"
                  type="number"
                  value={formData.sellingPrice}
                  onChange={handleInputChange}
                  InputProps={{
                    startAdornment: <InputAdornment position="start">RM</InputAdornment>,
                  }}
                  sx={{ 
                    '& .MuiOutlinedInput-root': {
                      borderRadius: 3,
                    }
                  }}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  required
                  fullWidth
                  label="Quantity"
                  name="quantity"
                  type="number"
                  value={formData.quantity}
                  onChange={handleInputChange}
                  InputProps={{
                    inputProps: { min: 1 }
                  }}
                  sx={{ 
                    '& .MuiOutlinedInput-root': {
                      borderRadius: 3,
                    }
                  }}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <LocalizationProvider dateAdapter={AdapterDateFns}>
                  <DatePicker
                    label="Purchase Date"
                    value={formData.purchaseDate}
                    onChange={(date) => setFormData({ ...formData, purchaseDate: date })}
                    renderInput={(params) => 
                      <TextField 
                        {...params} 
                        fullWidth 
                        required 
                        sx={{ 
                          '& .MuiOutlinedInput-root': {
                            borderRadius: 3,
                          }
                        }}
                      />
                    }
                  />
                </LocalizationProvider>
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Supplier/Vendor"
                  name="supplier"
                  value={formData.supplier}
                  onChange={handleInputChange}
                  sx={{ 
                    '& .MuiOutlinedInput-root': {
                      borderRadius: 3,
                    }
                  }}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Serial Number"
                  name="serialNumber"
                  value={formData.serialNumber}
                  onChange={handleInputChange}
                  sx={{ 
                    '& .MuiOutlinedInput-root': {
                      borderRadius: 3,
                    }
                  }}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <FormControlLabel
                  control={
                    <Switch
                      checked={formData.isAsset}
                      onChange={(e) => setFormData({ ...formData, isAsset: e.target.checked })}
                      name="isAsset"
                      color="primary"
                    />
                  }
                  label="Track as Asset"
                />
              </Grid>
              {formData.isAsset && (
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth
                    label="Asset Value"
                    name="assetValue"
                    type="number"
                    value={formData.assetValue}
                    onChange={handleInputChange}
                    InputProps={{
                      startAdornment: <InputAdornment position="start">RM</InputAdornment>,
                    }}
                    sx={{ 
                      '& .MuiOutlinedInput-root': {
                        borderRadius: 3,
                      }
                    }}
                  />
                </Grid>
              )}
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Description"
                  name="description"
                  multiline
                  rows={2}
                  value={formData.description}
                  onChange={handleInputChange}
                  sx={{ 
                    '& .MuiOutlinedInput-root': {
                      borderRadius: 3,
                    }
                  }}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Notes"
                  name="notes"
                  multiline
                  rows={2}
                  value={formData.notes}
                  onChange={handleInputChange}
                  sx={{ 
                    '& .MuiOutlinedInput-root': {
                      borderRadius: 3,
                    }
                  }}
                />
              </Grid>
            </Grid>
          </Box>
        </DialogContent>
        <DialogActions sx={{ 
          px: 3, 
          py: 2,
          backgroundColor: 'rgba(0,0,0,0.02)', 
          borderTop: '1px solid rgba(0,0,0,0.05)',
        }}>
          <Button 
            onClick={handleDialogClose}
            disabled={loading}
            sx={{ 
              fontWeight: 500, 
              borderRadius: 3,
              px: 3
            }}
          >
            Cancel
          </Button>
          <Button 
            onClick={handleSubmit} 
            variant="contained" 
            color="primary"
            disabled={loading}
            startIcon={loading ? <CircularProgress size={16} color="inherit" /> : null}
            sx={{ 
              fontWeight: 600, 
              borderRadius: 3,
              px: 3,
              boxShadow: '0 4px 10px rgba(0, 122, 255, 0.3)',
            }}
          >
            {loading ? 'Saving...' : dialogMode === 'add' ? 'Add Product' : 'Update Product'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Sell Product Dialog */}
      <Dialog 
        open={openSellDialog} 
        onClose={() => {
          // Only allow closing if not currently loading
          if (!loading) {
            handleDialogClose();
            setError(null);
          }
        }}
        maxWidth="sm" 
        fullWidth
        fullScreen={isMobile}
        PaperProps={{
          sx: {
            borderRadius: isMobile ? 0 : 4,
            overflow: 'hidden'
          }
        }}
      >
        <DialogTitle sx={{ 
          backgroundColor: 'rgba(0,0,0,0.02)', 
          borderBottom: '1px solid rgba(0,0,0,0.05)',
          py: 2,
          px: 3
        }}>
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <Typography variant="h6" sx={{ fontWeight: 600 }}>
              Mark Product as Sold
            </Typography>
            <IconButton 
              edge="end" 
              onClick={() => {
                if (!loading) {
                  handleDialogClose();
                  setError(null);
                }
              }}
              disabled={loading}
              sx={{ 
                bgcolor: 'rgba(0,0,0,0.05)',
                '&:hover': {
                  bgcolor: 'rgba(0,0,0,0.1)',
                }
              }}
            >
              <CloseIcon />
            </IconButton>
          </Box>
        </DialogTitle>
        <DialogContent sx={{ pt: 2 }}>
          {error && (
            <Alert 
              severity="error" 
              sx={{ mb: 2, borderRadius: 2 }}
            >
              {error}
            </Alert>
          )}
          
          {selectedProduct && (
            <Box sx={{ mt: 1 }}>
              <Card
                elevation={0}
                sx={{ 
                  mb: 3, 
                  borderRadius: 3,
                  bgcolor: 'rgba(0, 122, 255, 0.05)',
                  border: '1px solid rgba(0, 122, 255, 0.1)',
                }}
              >
                <CardContent sx={{ px: 2, py: 1.5 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <Avatar
                      sx={{ 
                        width: 36, 
                        height: 36,
                        bgcolor: `${getCategoryColor(selectedProduct.category)}20`,
                        color: getCategoryColor(selectedProduct.category),
                        mr: 1.5
                      }}
                    >
                      {getCategoryIcon(selectedProduct.category)}
                    </Avatar>
                    <Box>
                      <Typography variant="body1" sx={{ fontWeight: 600 }}>
                        {selectedProduct.name}
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        Purchase Price: {formatCurrency(selectedProduct.purchasePrice)}
                      </Typography>
                    </Box>
                  </Box>
                </CardContent>
              </Card>
              
              <Typography variant="subtitle1" sx={{ fontWeight: 600, mb: 2, color: 'primary.main' }}>
                Sale Information
              </Typography>
              
              <Grid container spacing={2}>
                <Grid item xs={12} sm={6}>
                  <TextField
                    required
                    fullWidth
                    label="Selling Price"
                    name="sellingPrice"
                    type="number"
                    value={sellFormData.sellingPrice}
                    onChange={handleSellInputChange}
                    InputProps={{
                      startAdornment: <InputAdornment position="start">RM</InputAdornment>,
                    }}
                    sx={{ 
                      '& .MuiOutlinedInput-root': {
                        borderRadius: 3,
                      },
                      '& .MuiInputLabel-root': {
                        color: 'success.main',
                        fontWeight: 500
                      },
                      '& .MuiOutlinedInput-notchedOutline': {
                        borderColor: theme.palette.success.main,
                      },
                      '&:hover .MuiOutlinedInput-notchedOutline': {
                        borderColor: theme.palette.success.dark,
                      }
                    }}
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <LocalizationProvider dateAdapter={AdapterDateFns}>
                    <DatePicker
                      label="Sale Date"
                      value={sellFormData.soldDate}
                      onChange={(date) => setSelFormData({ ...sellFormData, soldDate: date })}
                      renderInput={(params) => 
                        <TextField 
                          {...params} 
                          fullWidth 
                          sx={{ 
                            '& .MuiOutlinedInput-root': {
                              borderRadius: 3,
                            }
                          }}
                        />
                      }
                    />
                  </LocalizationProvider>
                </Grid>
                
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    label="Notes"
                    name="notes"
                    multiline
                    rows={2}
                    value={sellFormData.notes}
                    onChange={handleSellInputChange}
                    placeholder="Add any details about this sale (optional)"
                    sx={{ 
                      '& .MuiOutlinedInput-root': {
                        borderRadius: 3,
                      }
                    }}
                  />
                </Grid>
                
                {sellFormData.sellingPrice && (
                  <Grid item xs={12}>
                    <Card
                      elevation={0}
                      sx={{ 
                        mt: 1, 
                        borderRadius: 3,
                        bgcolor: 'rgba(52, 199, 89, 0.05)',
                        border: '1px solid rgba(52, 199, 89, 0.1)',
                      }}
                    >
                      <CardContent>
                        <Typography variant="subtitle1" sx={{ fontWeight: 600, color: '#34C759', mb: 1 }}>
                          Sale Summary
                        </Typography>
                        
                        <Grid container spacing={2}>
                          <Grid item xs={6}>
                            <Typography variant="body2" color="text.secondary">
                              Purchase Price
                            </Typography>
                            <Typography variant="body1">
                              {formatCurrency(selectedProduct.purchasePrice)}
                            </Typography>
                          </Grid>
                          <Grid item xs={6}>
                            <Typography variant="body2" color="text.secondary">
                              Selling Price
                            </Typography>
                            <Typography variant="body1">
                              {formatCurrency(parseFloat(sellFormData.sellingPrice) || 0)}
                            </Typography>
                          </Grid>
                        </Grid>
                        
                        <Divider sx={{ my: 1.5 }} />
                        
                        <Grid container spacing={2}>
                          <Grid item xs={6}>
                            <Typography variant="body2" color="text.secondary">
                              Profit
                            </Typography>
                            <Typography variant="body1" sx={{ 
                              fontWeight: 600,
                              color: (parseFloat(sellFormData.sellingPrice) || 0) >= selectedProduct.purchasePrice ? '#34C759' : '#FF3B30'
                            }}>
                              {formatCurrency((parseFloat(sellFormData.sellingPrice) || 0) - selectedProduct.purchasePrice)}
                            </Typography>
                          </Grid>
                          <Grid item xs={6}>
                            <Typography variant="body2" color="text.secondary">
                              Profit Margin
                            </Typography>
                            <Typography variant="body1" sx={{ 
                              fontWeight: 600,
                              color: (parseFloat(sellFormData.sellingPrice) || 0) >= selectedProduct.purchasePrice ? '#34C759' : '#FF3B30'
                            }}>
                              {selectedProduct.purchasePrice > 0 ? 
                                `${(((parseFloat(sellFormData.sellingPrice) || 0) - selectedProduct.purchasePrice) / selectedProduct.purchasePrice * 100).toFixed(1)}%` : 
                                '0%'
                              }
                            </Typography>
                          </Grid>
                        </Grid>
                        
                        <Divider sx={{ my: 1.5 }} />
                        
                        <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                          Revenue Entry
                        </Typography>
                        <Box sx={{ 
                          p: 1.5, 
                          bgcolor: 'background.paper', 
                          borderRadius: 2,
                          border: '1px dashed rgba(52, 199, 89, 0.3)'
                        }}>
                          <Typography variant="body2" sx={{ fontWeight: 500 }}>
                            Sale of {selectedProduct.name}
                          </Typography>
                          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 0.5 }}>
                            • Category: Sales
                          </Typography>
                          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 0.5 }}>
                            • Amount: {formatCurrency(parseFloat(sellFormData.sellingPrice) || 0)}
                          </Typography>
                          <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>
                            • Date: {format(new Date(sellFormData.soldDate), 'dd MMM yyyy')}
                          </Typography>
                        </Box>
                      </CardContent>
                    </Card>
                  </Grid>
                )}
              </Grid>
            </Box>
          )}
        </DialogContent>
        <DialogActions sx={{ 
          px: 3, 
          py: 2,
          backgroundColor: 'rgba(0,0,0,0.02)', 
          borderTop: '1px solid rgba(0,0,0,0.05)',
        }}>
          <Button 
            onClick={handleDialogClose}
            disabled={loading}
            sx={{ 
              fontWeight: 500, 
              borderRadius: 3,
              px: 3
            }}
          >
            Cancel
          </Button>
          <Button 
            onClick={handleSellProduct} 
            variant="contained" 
            color="success"
            disabled={loading || !sellFormData.sellingPrice}
            startIcon={loading ? <CircularProgress size={16} color="inherit" /> : null}
            sx={{ 
              fontWeight: 600, 
              borderRadius: 3,
              px: 3,
              bgcolor: '#34C759',
              '&:hover': {
                bgcolor: '#2EB351',
              },
              boxShadow: '0 4px 10px rgba(52, 199, 89, 0.3)',
            }}
          >
            {loading ? 'Processing...' : 'Complete Sale'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* View Product Dialog */}
      <Dialog 
        open={viewDialog} 
        onClose={handleDialogClose} 
        maxWidth="md" 
        fullWidth
        fullScreen={isMobile}
        PaperProps={{
          sx: {
            borderRadius: isMobile ? 0 : 4,
            overflow: 'hidden'
          }
        }}
      >
        <DialogTitle sx={{ 
          backgroundColor: 'rgba(0,0,0,0.02)', 
          borderBottom: '1px solid rgba(0,0,0,0.05)',
          py: 2,
          px: 3
        }}>
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <Typography variant="h6" sx={{ fontWeight: 600 }}>
              Product Details
            </Typography>
            <IconButton 
              edge="end" 
              onClick={handleDialogClose}
              sx={{ 
                bgcolor: 'rgba(0,0,0,0.05)',
                '&:hover': {
                  bgcolor: 'rgba(0,0,0,0.1)',
                }
              }}
            >
              <CloseIcon />
            </IconButton>
          </Box>
        </DialogTitle>
        <DialogContent sx={{ p: isMobile ? 2 : 3 }}>
          {selectedProduct && (
            <Box sx={{ mt: 1 }}>
              <Grid container spacing={3}>
                <Grid item xs={12}>
                  <Card 
                    elevation={0}
                    className="ios-shadow"
                    sx={{ 
                      borderRadius: 4,
                      overflow: 'hidden',
                      position: 'relative',
                    }}
                  >
                    <Box 
                      sx={{ 
                        height: 8, 
                        width: '100%', 
                        backgroundColor: selectedProduct.inStock ? getCategoryColor(selectedProduct.category) : '#8E8E93' 
                      }} 
                    />
                    <CardContent>
                      <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
                        <Avatar
                          sx={{ 
                            width: 56, 
                            height: 56,
                            bgcolor: `${getCategoryColor(selectedProduct.category)}20`,
                            color: selectedProduct.inStock ? getCategoryColor(selectedProduct.category) : '#8E8E93',
                            mr: 2
                          }}
                        >
                          {getCategoryIcon(selectedProduct.category)}
                        </Avatar>
                        <Box>
                          <Typography variant="h5" component="div" sx={{ fontWeight: 700 }}>
                            {selectedProduct.name}
                          </Typography>
                          <Box sx={{ display: 'flex', alignItems: 'center', mt: 0.5 }}>
                            <Chip 
                              label={selectedProduct.category}
                              size="small"
                              sx={{
                                mr: 1,
                                bgcolor: `${getCategoryColor(selectedProduct.category)}20`,
                                color: getCategoryColor(selectedProduct.category),
                                fontWeight: 500,
                                borderRadius: 3,
                              }}
                            />
                            <Chip 
                              label={selectedProduct.inStock ? 'In Stock' : 'Sold'}
                              size="small"
                              sx={{
                                bgcolor: selectedProduct.inStock ? 'rgba(52, 199, 89, 0.1)' : 'rgba(142, 142, 147, 0.1)',
                                color: selectedProduct.inStock ? '#34C759' : '#8E8E93',
                                fontWeight: 500,
                                borderRadius: 3,
                              }}
                            />
                          </Box>
                        </Box>
                      </Box>
                      
                      {selectedProduct.description && (
                        <Box sx={{ mb: 3 }}>
                          <Typography variant="body2" color="text.secondary" gutterBottom>
                            Description
                          </Typography>
                          <Typography variant="body1">
                            {selectedProduct.description}
                          </Typography>
                        </Box>
                      )}
                      
                      <Divider sx={{ my: 2 }} />
                      
                      <Typography variant="subtitle1" sx={{ fontWeight: 600, mb: 2 }}>
                        Financial Details
                      </Typography>
                      
                      <Grid container spacing={2}>
                        <Grid item xs={12} sm={6} md={3}>
                          <Typography variant="body2" color="text.secondary">
                            Purchase Price
                          </Typography>
                          <Typography variant="body1" sx={{ fontWeight: 500 }}>
                            {formatCurrency(selectedProduct.purchasePrice)}
                          </Typography>
                        </Grid>
                        <Grid item xs={12} sm={6} md={3}>
                          <Typography variant="body2" color="text.secondary">
                            {selectedProduct.inStock ? 'Selling Price' : 'Sold For'}
                          </Typography>
                          <Typography variant="body1" sx={{ fontWeight: 500 }}>
                            {formatCurrency(selectedProduct.inStock ? selectedProduct.sellingPrice : selectedProduct.soldPrice)}
                          </Typography>
                        </Grid>
                        <Grid item xs={12} sm={6} md={3}>
                          <Typography variant="body2" color="text.secondary">
                            {selectedProduct.inStock ? 'Current Value' : 'Final Value'}
                          </Typography>
                          <Typography variant="body1" sx={{ fontWeight: 500 }}>
                            {formatCurrency(selectedProduct.assetValue || selectedProduct.purchasePrice)}
                          </Typography>
                        </Grid>
                        <Grid item xs={12} sm={6} md={3}>
                          <Typography variant="body2" color="text.secondary">
                            Quantity
                          </Typography>
                          <Typography variant="body1" sx={{ fontWeight: 500 }}>
                            {selectedProduct.quantity}
                          </Typography>
                        </Grid>
                      </Grid>
                      
                      <Divider sx={{ my: 2 }} />
                      
                      <Typography variant="subtitle1" sx={{ fontWeight: 600, mb: 2 }}>
                        Additional Details
                      </Typography>
                      
                      <Grid container spacing={2}>
                        <Grid item xs={12} sm={6} md={4}>
                          <Typography variant="body2" color="text.secondary">
                            Purchase Date
                          </Typography>
                          <Typography variant="body1" sx={{ fontWeight: 500 }}>
                            {formatDate(selectedProduct.purchaseDate)}
                          </Typography>
                        </Grid>
                        
                        {!selectedProduct.inStock && (
                          <Grid item xs={12} sm={6} md={4}>
                            <Typography variant="body2" color="text.secondary">
                              Sold Date
                            </Typography>
                            <Typography variant="body1" sx={{ fontWeight: 500 }}>
                              {formatDate(selectedProduct.soldDate)}
                            </Typography>
                          </Grid>
                        )}
                        
                        <Grid item xs={12} sm={6} md={4}>
                          <Typography variant="body2" color="text.secondary">
                            Supplier
                          </Typography>
                          <Typography variant="body1" sx={{ fontWeight: 500 }}>
                            {selectedProduct.supplier || '-'}
                          </Typography>
                        </Grid>
                        
                        <Grid item xs={12} sm={6} md={4}>
                          <Typography variant="body2" color="text.secondary">
                            Serial Number
                          </Typography>
                          <Typography variant="body1" sx={{ fontWeight: 500 }}>
                            {selectedProduct.serialNumber || '-'}
                          </Typography>
                        </Grid>
                      </Grid>
                      
                      {selectedProduct.notes && (
                        <>
                          <Divider sx={{ my: 2 }} />
                          <Typography variant="subtitle1" sx={{ fontWeight: 600, mb: 1 }}>
                            Notes
                          </Typography>
                          <Typography variant="body1">
                            {selectedProduct.notes}
                          </Typography>
                        </>
                      )}
                      
                      {selectedProduct.inStock && (
                        <Box sx={{ mt: 3, display: 'flex', justifyContent: 'flex-end' }}>
                          <Button
                            variant="outlined"
                            color="primary"
                            startIcon={<ShoppingCartIcon />}
                            onClick={() => {
                              handleDialogClose();
                              handleSellClick(selectedProduct);
                            }}
                            sx={{ 
                              borderRadius: 3,
                              mr: 1,
                              borderColor: '#34C759',
                              color: '#34C759',
                              '&:hover': {
                                borderColor: '#2EB351',
                                backgroundColor: 'rgba(52, 199, 89, 0.1)',
                              }
                            }}
                          >
                            Mark as Sold
                          </Button>
                          <Button
                            variant="outlined"
                            color="primary"
                            startIcon={<EditIcon />}
                            onClick={() => {
                              handleDialogClose();
                              handleEditClick(selectedProduct);
                            }}
                            sx={{ 
                              borderRadius: 3,
                            }}
                          >
                            Edit Product
                          </Button>
                        </Box>
                      )}
                    </CardContent>
                  </Card>
                </Grid>
              </Grid>
            </Box>
          )}
        </DialogContent>
        <DialogActions sx={{ 
          px: 3, 
          py: 2,
          backgroundColor: 'rgba(0,0,0,0.02)', 
          borderTop: '1px solid rgba(0,0,0,0.05)',
        }}>
          <Button 
            onClick={handleDialogClose}
            sx={{ 
              fontWeight: 500, 
              borderRadius: 3,
              px: 3
            }}
          >
            Close
          </Button>
        </DialogActions>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog
        open={deleteConfirmDialog}
        onClose={() => {
          // Only allow closing if not currently loading
          if (!loading && !isDeleting) {
            handleDialogClose();
            setError(null);
          }
        }}
        PaperProps={{
          sx: {
            borderRadius: 4,
            overflow: 'hidden',
            maxWidth: '400px'
          }
        }}
      >
        <DialogTitle sx={{ pt: 3, px: 3 }}>
          <Typography variant="h6" sx={{ fontWeight: 600 }}>
            Delete Product
          </Typography>
        </DialogTitle>
        <DialogContent sx={{ px: 3, pt: 1 }}>
          {error && (
            <Alert 
              severity="error" 
              sx={{ 
                mb: 2, 
                borderRadius: 2,
                '& .MuiAlert-message': {
                  fontWeight: 500
                }
              }}
              action={
                <Button 
                  color="inherit" 
                  size="small"
                  onClick={() => setError(null)}
                >
                  Dismiss
                </Button>
              }
            >
              {error}
            </Alert>
          )}
          
          <Typography variant="body1" sx={{ mb: 2 }}>
            Are you sure you want to delete this product? This action cannot be undone.
          </Typography>
          
          {selectedProduct && (
            <Card
              elevation={0}
              sx={{ 
                mt: 2, 
                borderRadius: 3,
                bgcolor: 'rgba(255, 59, 48, 0.05)',
                border: '1px solid rgba(255, 59, 48, 0.1)',
              }}
            >
              <CardContent sx={{ px: 2, py: 1.5 }}>
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  <Avatar
                    sx={{ 
                      width: 36, 
                      height: 36,
                      bgcolor: `${getCategoryColor(selectedProduct.category)}20`,
                      color: getCategoryColor(selectedProduct.category),
                      mr: 1.5
                    }}
                  >
                    {getCategoryIcon(selectedProduct.category)}
                  </Avatar>
                  <Box>
                    <Typography variant="body1" sx={{ fontWeight: 600 }}>
                      {selectedProduct.name}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {formatCurrency(selectedProduct.assetValue || selectedProduct.purchasePrice)}
                    </Typography>
                  </Box>
                </Box>
              </CardContent>
            </Card>
          )}
        </DialogContent>
        <DialogActions sx={{ 
          px: 3, 
          py: 2,
          backgroundColor: 'rgba(0,0,0,0.02)', 
          borderTop: '1px solid rgba(0,0,0,0.05)'
        }}>
          <Button 
            onClick={handleDialogClose}
            disabled={loading || isDeleting}
            sx={{ 
              fontWeight: 500, 
              borderRadius: 3,
              px: 3
            }}
          >
            Cancel
          </Button>
          <Button 
            onClick={handleDeleteConfirm} 
            color="error" 
            variant="contained"
            disabled={loading || isDeleting}
            startIcon={loading || isDeleting ? <CircularProgress size={16} color="inherit" /> : null}
            sx={{ 
              fontWeight: 600, 
              borderRadius: 3,
              px: 3,
              bgcolor: '#FF3B30',
              '&:hover': {
                bgcolor: '#E6352C',
              },
              boxShadow: '0 4px 10px rgba(255, 59, 48, 0.3)',
            }}
          >
            {loading || isDeleting ? 'Deleting...' : 'Delete'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
} 