import React, { useState, useContext, useEffect } from 'react';
import { 
  Container, 
  Typography, 
  Paper, 
  Box, 
  CircularProgress,
  Avatar,
  Grid,
  TextField,
  Button,
  Divider,
  IconButton,
  Tabs,
  Tab,
  Card,
  CardContent,
  useTheme,
  useMediaQuery,
  Alert,
  Slide
} from '@mui/material';
import { 
  Edit as EditIcon, 
  Save as SaveIcon,
  Person as PersonIcon,
  Security as SecurityIcon,
  Settings as SettingsIcon,
  Notifications as NotificationsIcon,
  ArrowForward as ArrowForwardIcon,
  Check as CheckIcon
} from '@mui/icons-material';
import { AuthContext } from '../../context/AuthContext';

export default function Profile() {
  const { user, loadUser } = useContext(AuthContext);
  const [tabValue, setTabValue] = useState(0);
  const [editMode, setEditMode] = useState(false);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  
  const clearErrors = () => {
    setError(null);
  };
  
  useEffect(() => {
    if (user) {
      setFormData(prevState => ({
        ...prevState,
        name: user.name || '',
        email: user.email || ''
      }));
    }
  }, [user]);
  
  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };
  
  const handleEditToggle = () => {
    setEditMode(!editMode);
    // Reset form data if cancelling edit
    if (editMode && user) {
      setFormData(prevState => ({
        ...prevState,
        name: user.name || '',
        email: user.email || ''
      }));
    }
  };
  
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setSuccess(false);
    
    // Here you would implement the actual profile update
    // For now, we'll simulate a successful update
    setTimeout(() => {
      setLoading(false);
      setSuccess(true);
      setEditMode(false);
    }, 1000);
  };
  
  const getUserInitials = () => {
    if (!user || !user.name) return '?';
    return user.name.split(' ')
      .map(name => name[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };
  
  const getProfileBackgroundGradient = () => {
    return {
      background: `linear-gradient(135deg, ${theme.palette.primary.light}, ${theme.palette.primary.main})`,
    };
  };

  return (
    <Container maxWidth="md" sx={{ py: 3 }}>
      {/* Page header */}
      <Box sx={{ mb: 3, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Typography variant="h4" sx={{ 
          fontWeight: 600, 
          background: 'linear-gradient(90deg, #000000, #555555)',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent'
        }}>
          Profile
        </Typography>
      </Box>
      
      {/* Success Alert */}
      {success && (
        <Slide direction="down" in={success}>
          <Alert 
            severity="success" 
            sx={{ mb: 3, borderRadius: 2 }}
            icon={<CheckIcon />}
            onClose={() => setSuccess(false)}
          >
            Profile updated successfully!
          </Alert>
        </Slide>
      )}
      
      {/* Error Alert */}
      {error && (
        <Slide direction="down" in={!!error}>
          <Alert 
            severity="error" 
            sx={{ mb: 3, borderRadius: 2 }}
            onClose={clearErrors}
          >
            {error}
          </Alert>
        </Slide>
      )}
      
      <Grid container spacing={3}>
        {/* Profile Card */}
        <Grid item xs={12} md={4}>
          <Card elevation={1} sx={{ borderRadius: 4, overflow: 'hidden' }}>
            <Box sx={{ 
              p: 3, 
              ...getProfileBackgroundGradient(), 
              color: 'white',
              textAlign: 'center'
            }}>
              <Avatar 
                sx={{ 
                  width: 100, 
                  height: 100, 
                  mx: 'auto', 
                  bgcolor: 'white',
                  color: theme.palette.primary.main,
                  fontSize: 36,
                  fontWeight: 'bold'
                }}
              >
                {getUserInitials()}
              </Avatar>
              <Typography variant="h5" sx={{ mt: 2, fontWeight: 'medium' }}>
                {user?.name || 'User'}
              </Typography>
              <Typography variant="body2" sx={{ opacity: 0.8 }}>
                {user?.role === 'admin' ? 'Administrator' : 'Founder'}
              </Typography>
            </Box>
            <CardContent>
              <Box sx={{ mt: 1 }}>
                <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                  Email
                </Typography>
                <Typography variant="body1" sx={{ fontWeight: 'medium' }}>
                  {user?.email || 'email@example.com'}
                </Typography>
              </Box>
              <Box sx={{ mt: 3 }}>
                <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                  Role
                </Typography>
                <Typography variant="body1" sx={{ fontWeight: 'medium' }}>
                  {user?.role === 'admin' ? 'Administrator' : 'Founder'}
                </Typography>
              </Box>
              <Box sx={{ mt: 3 }}>
                <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                  Account Created
                </Typography>
                <Typography variant="body1" sx={{ fontWeight: 'medium' }}>
                  {user?.createdAt 
                    ? new Date(user.createdAt).toLocaleDateString('en-US', { 
                        year: 'numeric', 
                        month: 'long', 
                        day: 'numeric' 
                      })
                    : 'N/A'}
                </Typography>
              </Box>
            </CardContent>
          </Card>
        </Grid>
        
        {/* Profile Settings */}
        <Grid item xs={12} md={8}>
          <Paper elevation={1} sx={{ borderRadius: 4, overflow: 'hidden' }}>
            <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
              <Tabs 
                value={tabValue} 
                onChange={handleTabChange} 
                variant={isMobile ? "fullWidth" : "standard"}
                sx={{
                  '& .MuiTab-root': {
                    py: 2,
                    textTransform: 'none',
                    fontSize: '0.95rem'
                  }
                }}
              >
                <Tab icon={<PersonIcon />} label="Personal Info" iconPosition="start" />
                <Tab icon={<SecurityIcon />} label="Security" iconPosition="start" />
                <Tab icon={<SettingsIcon />} label="Preferences" iconPosition="start" />
              </Tabs>
            </Box>
            
            {/* Personal Info Tab */}
            {tabValue === 0 && (
              <Box component="form" onSubmit={handleSubmit} sx={{ p: 3 }}>
                <Box sx={{ mb: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Typography variant="h6" sx={{ fontWeight: 'medium' }}>
                    Personal Information
                  </Typography>
                  <IconButton 
                    color={editMode ? "secondary" : "primary"}
                    onClick={handleEditToggle}
                    disabled={loading}
                  >
                    {editMode ? <SaveIcon /> : <EditIcon />}
                  </IconButton>
                </Box>
                <Grid container spacing={2}>
                  <Grid item xs={12}>
                    <TextField
                      fullWidth
                      label="Full Name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      disabled={!editMode || loading}
                      InputProps={{
                        sx: { borderRadius: 2 }
                      }}
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      fullWidth
                      label="Email Address"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleChange}
                      disabled={!editMode || loading}
                      InputProps={{
                        sx: { borderRadius: 2 }
                      }}
                    />
                  </Grid>
                  {editMode && (
                    <Grid item xs={12} sx={{ mt: 2 }}>
                      <Button
                        type="submit"
                        variant="contained"
                        color="primary"
                        fullWidth
                        disabled={loading}
                        startIcon={loading ? <CircularProgress size={20} /> : <SaveIcon />}
                        sx={{ borderRadius: 8, py: 1.5 }}
                      >
                        {loading ? 'Saving...' : 'Save Changes'}
                      </Button>
                    </Grid>
                  )}
                </Grid>
              </Box>
            )}
            
            {/* Security Tab */}
            {tabValue === 1 && (
              <Box component="form" sx={{ p: 3 }}>
                <Typography variant="h6" sx={{ mb: 2, fontWeight: 'medium' }}>
                  Security Settings
                </Typography>
                <Grid container spacing={2}>
                  <Grid item xs={12}>
                    <TextField
                      fullWidth
                      label="Current Password"
                      name="currentPassword"
                      type="password"
                      value={formData.currentPassword}
                      onChange={handleChange}
                      InputProps={{
                        sx: { borderRadius: 2 }
                      }}
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      fullWidth
                      label="New Password"
                      name="newPassword"
                      type="password"
                      value={formData.newPassword}
                      onChange={handleChange}
                      InputProps={{
                        sx: { borderRadius: 2 }
                      }}
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      fullWidth
                      label="Confirm New Password"
                      name="confirmPassword"
                      type="password"
                      value={formData.confirmPassword}
                      onChange={handleChange}
                      InputProps={{
                        sx: { borderRadius: 2 }
                      }}
                    />
                  </Grid>
                  <Grid item xs={12} sx={{ mt: 2 }}>
                    <Button
                      variant="contained"
                      color="primary"
                      fullWidth
                      sx={{ borderRadius: 8, py: 1.5 }}
                    >
                      Update Password
                    </Button>
                  </Grid>
                </Grid>
              </Box>
            )}
            
            {/* Preferences Tab */}
            {tabValue === 2 && (
              <Box sx={{ p: 3 }}>
                <Typography variant="h6" sx={{ mb: 2, fontWeight: 'medium' }}>
                  Preferences
                </Typography>
                <Box sx={{ mb: 3 }}>
                  <Box sx={{ 
                    p: 2, 
                    borderRadius: 2, 
                    bgcolor: 'background.default',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    mb: 2
                  }}>
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <NotificationsIcon sx={{ mr: 2, color: 'text.secondary' }} />
                      <Typography variant="body1">Email Notifications</Typography>
                    </Box>
                    <Button 
                      variant="text" 
                      endIcon={<ArrowForwardIcon />}
                      sx={{ fontWeight: 'normal' }}
                    >
                      Configure
                    </Button>
                  </Box>
                </Box>
                <Divider sx={{ my: 2 }} />
                <Box sx={{ mt: 3 }}>
                  <Typography variant="body2" color="text.secondary">
                    This section is under development. More preference options will be available soon.
                  </Typography>
                </Box>
              </Box>
            )}
          </Paper>
        </Grid>
      </Grid>
    </Container>
  );
} 