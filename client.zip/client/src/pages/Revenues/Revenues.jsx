import React, { useState, useEffect, useContext } from 'react';
import { 
  Box, 
  Typography, 
  TextField, 
  Dialog, 
  DialogTitle, 
  DialogContent, 
  DialogActions, 
  Button, 
  Paper, 
  IconButton, 
  Grid, 
  MenuItem, 
  Select, 
  FormControl, 
  InputLabel, 
  Tooltip, 
  CircularProgress,
  useMediaQuery,
  InputAdornment,
  Card,
  CardContent,
  Divider,
  Chip,
  Fab,
  Slide,
  Container,
  Alert,
  Avatar,
  Stack
} from '@mui/material';
import { 
  Add as AddIcon, 
  Delete as DeleteIcon, 
  Edit as EditIcon, 
  Search as SearchIcon,
  ArrowUpward as ArrowUpwardIcon,
  ArrowDownward as ArrowDownwardIcon,
  Close as CloseIcon,
  CalendarMonth as CalendarIcon, 
  Refresh as RefreshIcon,
  Save as SaveIcon,
  FilterAlt as FilterAltIcon,
  AttachMoney as AttachMoneyIcon,
  Paid as PaidIcon,
  Storefront as StorefrontIcon,
  Apartment as ApartmentIcon,
  AccountBalance as AccountBalanceIcon,
  LocalAtm as LocalAtmIcon,
  SyncAlt as SyncAltIcon,
  Visibility as VisibilityIcon
} from '@mui/icons-material';
import { useTheme } from '@mui/material/styles';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { LocalizationProvider, DatePicker } from '@mui/x-date-pickers';
import { format } from 'date-fns';
import { FinancialContext } from '../../context/FinancialContext';

// Transition component for dialogs
const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

const categories = [
  'Sales',
  'Service',
  'Investment',
  'Interest',
  'Refund',
  'Other'
];

const Revenues = () => {
  const { 
    revenues, 
    loadRevenues, 
    revenuesLoading, 
    revenuesLoaded,
    refreshData,
    addRevenue,
    deleteRevenue,
    updateRevenue,
    loading,
    error: contextError
  } = useContext(FinancialContext);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [open, setOpen] = useState(false);
  const [revenuesToCreate, setRevenuesToCreate] = useState({
    description: '',
    amount: '',
    category: '',
    date: new Date(),
    client: '',
    notes: ''
  });
  const [currentRevenue, setCurrentRevenue] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [sortDirection, setSortDirection] = useState('desc');
  const [viewDialog, setViewDialog] = useState(false);
  const [selectedRevenue, setSelectedRevenue] = useState(null);
  const [deleteConfirmDialog, setDeleteConfirmDialog] = useState(false);
  const [filterDrawerOpen, setFilterDrawerOpen] = useState(false);
  
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  
  useEffect(() => {
    // Create a local loading tracker
    let isComponentMounted = true;
    let isDataFetching = false;
    
    const fetchData = async () => {
      // Prevent duplicate fetches
      if (isDataFetching) {
        console.log('Already fetching revenues data, skipping request');
        return;
      }
      
      // Only fetch if data isn't already loaded or loading
      if (revenuesLoaded && !revenuesLoading) {
        console.log('Revenues data already loaded, skipping request');
        return;
      }
      
      try {
        isDataFetching = true;
        console.log('Revenues component - fetching revenues data');
        
        // Don't force refresh, use cached data if available
        await loadRevenues(false);
        
        if (isComponentMounted) {
          console.log('Revenues data successfully loaded');
        }
      } catch (err) {
        console.error("Failed to load revenues:", err);
        if (isComponentMounted) {
          setError("Failed to load revenues. Please try the refresh button.");
        }
      } finally {
        isDataFetching = false;
      }
    };
    
    fetchData();
    
    // Cleanup function to prevent state updates after unmount
    return () => {
      isComponentMounted = false;
    };
  }, [loadRevenues, revenuesLoaded, revenuesLoading]);
  
  // Filter and sort revenues
  const filteredRevenues = revenues
    .filter(revenue => {
      const matchesSearch = 
        revenue.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        revenue.source.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesCategory = categoryFilter ? revenue.category === categoryFilter : true;
      
      return matchesSearch && matchesCategory;
    })
    .sort((a, b) => {
      const dateA = new Date(a.date);
      const dateB = new Date(b.date);
      return sortDirection === 'desc' ? dateB - dateA : dateA - dateB;
    });
    
  // Calculate total revenue from filtered items
  const totalFilteredRevenue = filteredRevenues.reduce((sum, revenue) => sum + revenue.amount, 0);
  
  // Calculate revenue by category
  const revenueByCategory = categories.map(category => {
    const amount = filteredRevenues
      .filter(rev => rev.category === category)
      .reduce((sum, rev) => sum + rev.amount, 0);
    
    return { category, amount };
  }).sort((a, b) => b.amount - a.amount);
  
  // Get category icon
  const getCategoryIcon = (category) => {
    switch(category) {
      case 'Sales': return <StorefrontIcon />;
      case 'Service': return <PaidIcon />;
      case 'Investment': return <ApartmentIcon />;
      case 'Interest': return <AccountBalanceIcon />;
      case 'Refund': return <SyncAltIcon />;
      default: return <LocalAtmIcon />;
    }
  };
  
  // Get category color for visual representation
  const getCategoryColor = (category) => {
    switch(category) {
      case 'Sales': return 'success';
      case 'Service': return 'primary';
      case 'Investment': return 'secondary';
      case 'Interest': return 'warning';
      case 'Refund': return 'error';
      default: return 'default';
    }
  };
  
  // Format date function
  const formatDate = (dateString) => {
    try {
      return format(new Date(dateString), 'dd MMM yyyy');
    } catch (error) {
      return 'Invalid date';
    }
  };
  
  // Format currency function
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-MY', {
      style: 'currency',
      currency: 'MYR',
      minimumFractionDigits: 2
    }).format(amount || 0);
  };
  
  const resetForm = () => {
    setRevenuesToCreate({
      description: '',
      amount: '',
      category: '',
      date: new Date(),
      client: '',
      notes: ''
    });
    setIsEditing(false);
    setCurrentRevenue(null);
  };
  
  const handleOpenDialog = () => {
    resetForm();
    setOpen(true);
  };
  
  const handleCloseDialog = () => {
    setOpen(false);
    resetForm();
  };
  
  const handleChange = (e) => {
    setRevenuesToCreate({ ...revenuesToCreate, [e.target.name]: e.target.value });
  };
  
  const handleDateChange = (newDate) => {
    setRevenuesToCreate({ ...revenuesToCreate, date: newDate });
  };
  
  const handleSubmit = async () => {
    // Validate form inputs
    if (!revenuesToCreate.amount || !revenuesToCreate.description || !revenuesToCreate.date) {
      alert("Please fill in all required fields");
      return;
    }
    
    try {
      if (isEditing) {
        await updateRevenue(currentRevenue._id, {
          ...revenuesToCreate,
          amount: parseFloat(revenuesToCreate.amount)
        });
      } else {
        await addRevenue({
          ...revenuesToCreate,
          amount: parseFloat(revenuesToCreate.amount)
        });
      }
      
      handleCloseDialog();
    } catch (error) {
      console.error("Error saving revenue:", error);
      alert("Error saving revenue. Please try again.");
    }
  };
  
  const handleEdit = (revenue) => {
    setRevenuesToCreate({
      date: new Date(revenue.date),
      amount: revenue.amount.toString(),
      description: revenue.description,
      category: revenue.category,
      source: revenue.source
    });
    setIsEditing(true);
    setCurrentRevenue(revenue);
    setOpen(true);
  };
  
  const handleDeleteClick = (revenue) => {
    setSelectedRevenue(revenue);
    setDeleteConfirmDialog(true);
  };
  
  // Handle revenue delete confirmation
  const handleDeleteConfirm = async () => {
    try {
      setIsLoading(true);
      setError(null); // Clear any previous errors
      
      console.log(`Attempting to delete revenue with ID: ${selectedRevenue._id}`);
      
      // Keep the dialog open during deletion attempt
      const result = await deleteRevenue(selectedRevenue._id);
      console.log(`Delete revenue result: ${result}`);
      
      if (result) {
        console.log('Revenue deleted successfully, closing dialog');
        setDeleteConfirmDialog(false);
        // No need to force a refresh as the deleteRevenue function should have updated the state
      } else {
        // Error was set in the context
        console.error(`Delete revenue failed: ${contextError || 'No specific error provided'}`);
        
        // Keep dialog open to show error
        if (contextError) {
          setError(contextError);
        } else {
          setError("Failed to delete revenue. Please try again later.");
        }
      }
    } catch (err) {
      console.error("Error in handleDeleteConfirm:", err);
      setError(`Failed to delete revenue: ${err.message || 'An unexpected error occurred'}`);
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleSortToggle = () => {
    setSortDirection(sortDirection === 'desc' ? 'asc' : 'desc');
  };
  
  // This function is used in several places in the UI
  const handleClearFilters = () => {
    setSearchTerm('');
    setCategoryFilter('');
  };
  
  // Handle revenue view
  const handleViewClick = (revenue) => {
    setSelectedRevenue(revenue);
    setViewDialog(true);
  };
  
  // Show loading indicator when data is loading
  if (revenuesLoading) {
    return (
      <Box sx={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', height: '80vh' }}>
        <CircularProgress size={60} thickness={4} sx={{ mb: 2 }} />
        <Typography variant="h6" color="text.secondary">
          Loading Revenues Data...
        </Typography>
      </Box>
    );
  }
  
  // Enhanced error message with iOS-style design
  if (error) {
    return (
      <Container sx={{ py: 4 }}>
        <Alert 
          severity="error" 
          variant="filled"
          action={
            <Button 
              color="inherit" 
              size="small" 
              onClick={() => loadRevenues()}
              startIcon={<RefreshIcon />}
            >
              Retry
            </Button>
          }
          sx={{ 
            borderRadius: 4,
            boxShadow: '0 4px 12px rgba(211, 47, 47, 0.2)'
          }}
        >
          {error}
        </Alert>
      </Container>
    );
  }
  
  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <Container disableGutters={isMobile} sx={{ pb: isMobile ? 7 : 3 }}>
        {/* Header Section with Gradient Background */}
        <Box sx={{ 
          pt: isMobile ? 2 : 3, 
          pb: 2,
          px: isMobile ? 2 : 3,
          background: theme.palette.mode === 'dark' 
            ? `linear-gradient(135deg, ${theme.palette.success.dark}, ${theme.palette.primary.dark})` 
            : `linear-gradient(135deg, ${theme.palette.success.main}, ${theme.palette.primary.main})`,
          borderRadius: isMobile ? '0 0 24px 24px' : '0 0 16px 16px',
          mb: 3,
          color: 'white',
          boxShadow: '0 4px 20px rgba(0,0,0,0.1)'
        }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: isMobile ? 1 : 2 }}>
            <Typography 
              variant={isMobile ? "h5" : "h4"} 
              sx={{ 
                fontWeight: 600,
              }}
            >
              Revenues
            </Typography>
            {!isMobile && (
              <Button
                variant="contained"
                startIcon={<AddIcon />}
                onClick={() => handleOpenDialog()}
                sx={{ 
                  borderRadius: 8,
                  px: 3,
                  py: 1,
                  bgcolor: 'white',
                  color: theme.palette.success.main,
                  '&:hover': {
                    bgcolor: 'rgba(255,255,255,0.9)',
                  },
                  boxShadow: '0 4px 8px rgba(0,0,0,0.1)'
                }}
              >
                Add Revenue
              </Button>
            )}
          </Box>
          
          {/* Summary for Desktop */}
          {!isMobile && (
            <Grid container spacing={2} sx={{ mt: 1 }}>
              <Grid item xs={12} md={4}>
                <Paper 
                  elevation={2}
                  sx={{ 
                    p: 2, 
                    borderRadius: 4,
                    bgcolor: 'rgba(255,255,255,0.9)',
                    display: 'flex',
                    alignItems: 'center',
                    backdropFilter: 'blur(10px)',
                    boxShadow: '0 4px 8px rgba(0,0,0,0.1)'
                  }}
                >
                  <Avatar sx={{ bgcolor: theme.palette.success.main, mr: 2 }}>
                    <AttachMoneyIcon />
                  </Avatar>
                  <Box>
                    <Typography variant="body2" color="text.secondary">Total Revenue</Typography>
                    <Typography variant="h6" color="success.main" sx={{ fontWeight: 'bold' }}>
                      {formatCurrency(totalFilteredRevenue)}
                    </Typography>
                  </Box>
                </Paper>
              </Grid>
              
              <Grid item xs={12} md={4}>
                <Paper 
                  elevation={2}
                  sx={{ 
                    p: 2, 
                    borderRadius: 4,
                    bgcolor: 'rgba(255,255,255,0.9)',
                    display: 'flex',
                    alignItems: 'center',
                    backdropFilter: 'blur(10px)',
                    boxShadow: '0 4px 8px rgba(0,0,0,0.1)'
                  }}
                >
                  <Avatar sx={{ bgcolor: theme.palette.primary.main, mr: 2 }}>
                    <CalendarIcon />
                  </Avatar>
                  <Box>
                    <Typography variant="body2" color="text.secondary">This Month</Typography>
                    <Typography variant="h6" sx={{ fontWeight: 'bold' }}>
                      {formatCurrency(revenues
                        .filter(e => new Date(e.date).getMonth() === new Date().getMonth())
                        .reduce((sum, e) => sum + e.amount, 0)
                      )}
                    </Typography>
                  </Box>
                </Paper>
              </Grid>
              
              <Grid item xs={12} md={4}>
                <Paper 
                  elevation={2}
                  sx={{ 
                    p: 2, 
                    borderRadius: 4,
                    bgcolor: 'rgba(255,255,255,0.9)',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'flex-start',
                    backdropFilter: 'blur(10px)',
                    boxShadow: '0 4px 8px rgba(0,0,0,0.1)'
                  }}
                >
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>Top Category</Typography>
                  {revenueByCategory.length > 0 && revenueByCategory[0].amount > 0 ? (
                    <Box sx={{ display: 'flex', alignItems: 'center', width: '100%' }}>
                      <Chip 
                        icon={getCategoryIcon(revenueByCategory[0].category)} 
                        label={revenueByCategory[0].category}
                        color={getCategoryColor(revenueByCategory[0].category)} 
                        sx={{ mr: 1 }}
                      />
                      <Typography variant="body1" sx={{ fontWeight: 'bold', ml: 'auto' }}>
                        {formatCurrency(revenueByCategory[0].amount)}
                      </Typography>
                    </Box>
                  ) : (
                    <Typography variant="body1">No revenues yet</Typography>
                  )}
                </Paper>
              </Grid>
            </Grid>
          )}
        </Box>

        {/* Summary for Mobile */}
        {isMobile && (
          <Box sx={{ px: 2, mb: 3 }}>
            <Card 
              elevation={2}
              sx={{ 
                borderRadius: 4,
                overflow: 'hidden',
                boxShadow: '0 2px 10px rgba(0,0,0,0.08)'
              }}
            >
              <CardContent sx={{ p: 2 }}>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Typography variant="body2" color="text.secondary">Total Revenue</Typography>
                  <Chip
                    label={`${revenues.length} items`}
                    size="small"
                    sx={{ 
                      height: 24, 
                      '& .MuiChip-label': { px: 1, py: 0 },
                      fontWeight: 500,
                      bgcolor: 'rgba(0,0,0,0.05)' 
                    }}
                  />
                </Box>
                <Typography variant="h4" sx={{ fontWeight: 700, color: 'success.main', my: 1 }}>
                  {formatCurrency(totalFilteredRevenue)}
                </Typography>
                
                <Divider sx={{ my: 1.5 }} />
                
                {revenueByCategory.filter(cat => cat.amount > 0).length > 0 ? (
                  <Stack spacing={1}>
                    {revenueByCategory
                      .filter(cat => cat.amount > 0)
                      .slice(0, 2)
                      .map(({category, amount}) => (
                        <Box key={category} sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                          <Box sx={{ display: 'flex', alignItems: 'center' }}>
                            <Box 
                              sx={{ 
                                borderRadius: '8px', 
                                p: 0.5, 
                                mr: 1,
                                bgcolor: `${getCategoryColor(category)}.light`,
                                color: `${getCategoryColor(category)}.main`,
                                display: 'flex'
                              }}
                            >
                              {getCategoryIcon(category)}
                            </Box>
                            <Typography variant="body2">{category}</Typography>
                          </Box>
                          <Typography variant="body2" sx={{ fontWeight: 600 }}>
                            {formatCurrency(amount)}
                          </Typography>
                        </Box>
                      ))}
                  </Stack>
                ) : (
                  <Typography variant="body2" color="text.secondary" sx={{ textAlign: 'center', py: 1 }}>
                    No revenues recorded yet
                  </Typography>
                )}
              </CardContent>
            </Card>
          </Box>
        )}

        {/* Search and Filter Section */}
        <Box sx={{ 
          mb: 3, 
          px: isMobile ? 2 : 0
        }}>
          <Grid container spacing={2} alignItems="center">
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                fullWidth
                placeholder="Search revenues"
                variant="outlined"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchIcon />
                    </InputAdornment>
                  ),
                  sx: {
                    borderRadius: 8,
                    backgroundColor: 'white',
                    '& fieldset': {
                      borderColor: 'rgba(0, 0, 0, 0.08)',
                    },
                    boxShadow: '0 2px 8px rgba(0, 0, 0, 0.05)'
                  }
                }}
              />
            </Grid>
            
            {!isMobile && (
              <Grid item xs={12} sm={6} md={4}>
                <FormControl fullWidth variant="outlined">
                  <InputLabel>Filter by Category</InputLabel>
                  <Select
                    value={categoryFilter}
                    onChange={(e) => setCategoryFilter(e.target.value)}
                    label="Filter by Category"
                    sx={{
                      borderRadius: 8,
                      backgroundColor: 'white',
                      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.05)'
                    }}
                    startAdornment={
                      categoryFilter ? (
                        <InputAdornment position="start" sx={{ ml: 1 }}>
                          {getCategoryIcon(categoryFilter)}
                        </InputAdornment>
                      ) : null
                    }
                  >
                    <MenuItem value="">All Categories</MenuItem>
                    {categories.map(category => (
                      <MenuItem key={category} value={category}>
                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                          <Box sx={{ mr: 1.5, color: `${getCategoryColor(category)}.main`, display: 'flex' }}>
                            {getCategoryIcon(category)}
                          </Box>
                          {category}
                        </Box>
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
            )}
            
            <Grid item xs={12} sm={12} md={4} sx={{ display: 'flex', justifyContent: { xs: 'space-between', md: 'flex-end' }, gap: 1 }}>
              {!isMobile && (
                <Button
                  variant="outlined"
                  color="primary"
                  onClick={handleSortToggle}
                  startIcon={sortDirection === 'desc' ? <ArrowDownwardIcon /> : <ArrowUpwardIcon />}
                  sx={{ 
                    borderRadius: 8,
                    py: 1.2,
                    px: 2,
                    borderWidth: 1,
                    mr: 1
                  }}
                >
                  {sortDirection === 'desc' ? 'Newest' : 'Oldest'}
                </Button>
              )}
              
              <Button 
                variant="contained" 
                color="primary" 
                startIcon={<AddIcon />}
                onClick={handleOpenDialog}
                fullWidth={isMobile}
                size={isMobile ? "large" : "medium"}
                sx={{
                  borderRadius: 8,
                  py: isMobile ? 1.5 : 1.2,
                  boxShadow: '0 4px 10px rgba(0, 122, 255, 0.3)'
                }}
              >
                Add Revenue
              </Button>
            </Grid>
          </Grid>
        </Box>
        
        {/* Filter Chips - Mobile */}
        {isMobile && (
          <Box sx={{ px: 2, mb: 2, overflow: 'auto' }}>
            <Box sx={{ display: 'flex', gap: 1, pb: 0.5 }}>
              <Chip
                label="All"
                color={categoryFilter === '' ? 'primary' : 'default'}
                onClick={() => setCategoryFilter('')}
                sx={{ borderRadius: 8 }}
              />
              {categories.map(category => (
                <Chip
                  key={category}
                  label={category}
                  icon={getCategoryIcon(category)}
                  color={categoryFilter === category ? getCategoryColor(category) : 'default'}
                  variant={categoryFilter === category ? "filled" : "outlined"}
                  onClick={() => setCategoryFilter(categoryFilter === category ? '' : category)}
                  sx={{ borderRadius: 8 }}
                />
              ))}
            </Box>
            
            <Box sx={{ display: 'flex', alignItems: 'center', mt: 2 }}>
              <Button
                variant="outlined"
                color="primary"
                onClick={handleSortToggle}
                startIcon={sortDirection === 'desc' ? <ArrowDownwardIcon /> : <ArrowUpwardIcon />}
                size="small"
                sx={{ borderRadius: 8, mr: 'auto' }}
              >
                {sortDirection === 'desc' ? 'Newest First' : 'Oldest First'}
              </Button>
            </Box>
          </Box>
        )}
        
        {/* Mobile Filter Button */}
        {isMobile && (
          <Box sx={{ position: 'fixed', bottom: 85, right: 16, zIndex: 10 }}>
            <Fab
              color="primary"
              aria-label="filter"
              onClick={() => setFilterDrawerOpen(true)}
              sx={{ boxShadow: '0 4px 12px rgba(0, 122, 255, 0.5)' }}
            >
              <FilterAltIcon />
            </Fab>
          </Box>
        )}
        
        {/* Revenues List - Desktop View */}
        {!isMobile && filteredRevenues.length > 0 && (
          <Box sx={{ mb: 3 }}>
            <Grid container spacing={3}>
              {filteredRevenues.map((revenue) => (
                <Grid item xs={12} sm={6} md={4} key={revenue._id}>
                  <Card
                    elevation={1}
                    sx={{ 
                      borderRadius: 4,
                      overflow: 'hidden',
                      transition: 'transform 0.2s, box-shadow 0.2s',
                      '&:hover': {
                        boxShadow: '0 8px 16px rgba(0,0,0,0.1)',
                        transform: 'translateY(-2px)'
                      }
                    }}
                  >
                    <Box 
                      sx={{ 
                        height: 6, 
                        width: '100%', 
                        bgcolor: `${getCategoryColor(revenue.category)}.main` 
                      }} 
                    />
                    <CardContent sx={{ p: 3 }}>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                          <Avatar
                            sx={{
                              bgcolor: `${getCategoryColor(revenue.category)}.main`,
                              width: 36,
                              height: 36,
                              mr: 1.5
                            }}
                          >
                            {getCategoryIcon(revenue.category)}
                          </Avatar>
                          <Box>
                            <Chip
                              label={revenue.category}
                              size="small"
                              color={getCategoryColor(revenue.category)}
                              sx={{ 
                                height: 20, 
                                '& .MuiChip-label': { px: 1, fontSize: '0.7rem', fontWeight: 600 } 
                              }}
                            />
                            <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.5 }}>
                              {formatDate(revenue.date)}
                            </Typography>
                          </Box>
                        </Box>
                        <Typography 
                          variant="h6" 
                          sx={{ 
                            fontWeight: 700, 
                            color: 'success.main',
                            ml: 1 
                          }}
                        >
                          {formatCurrency(revenue.amount)}
                        </Typography>
                      </Box>
                      
                      <Box sx={{ mb: 2 }}>
                        <Typography variant="subtitle1" sx={{ fontWeight: 600, mb: 0.5 }}>
                          {revenue.description}
                        </Typography>
                        {revenue.source && (
                          <Typography variant="body2" color="text.secondary">
                            Source: {revenue.source}
                          </Typography>
                        )}
                      </Box>
                      
                      <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 2 }}>
                        <Tooltip title="View">
                          <IconButton 
                            size="small" 
                            onClick={(e) => {
                              e.stopPropagation();
                              handleViewClick(revenue);
                            }}
                            sx={{ 
                              backgroundColor: 'rgba(0,0,0,0.04)',
                              '&:hover': { backgroundColor: 'rgba(0,0,0,0.08)' },
                              mr: 1
                            }}
                          >
                            <VisibilityIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Edit">
                          <IconButton 
                            size="small" 
                            onClick={(e) => {
                              e.stopPropagation();
                              handleEdit(revenue);
                            }}
                            sx={{ 
                              backgroundColor: 'rgba(0,0,0,0.04)',
                              '&:hover': { backgroundColor: 'rgba(0,0,0,0.08)' },
                              mr: 1
                            }}
                          >
                            <EditIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                        <Tooltip title="Delete">
                          <IconButton 
                            size="small" 
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeleteClick(revenue);
                            }}
                            sx={{ 
                              color: 'error.main',
                              backgroundColor: 'rgba(211,47,47,0.04)',
                              '&:hover': { backgroundColor: 'rgba(211,47,47,0.08)' }
                            }}
                          >
                            <DeleteIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      </Box>
                    </CardContent>
                  </Card>
                </Grid>
              ))}
            </Grid>
          </Box>
        )}
        
        {/* Empty State */}
        {filteredRevenues.length === 0 && (
          <Box
            sx={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              p: 4,
              my: 4,
              textAlign: 'center'
            }}
          >
            <Avatar
              sx={{
                width: 80,
                height: 80,
                mb: 2,
                bgcolor: 'primary.light',
                color: 'primary.main'
              }}
            >
              <AttachMoneyIcon sx={{ fontSize: 40 }} />
            </Avatar>
            <Typography variant="h6" gutterBottom>
              No revenues found
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: 2, maxWidth: 300 }}>
              {searchTerm || categoryFilter 
                ? "Try adjusting your search or filters" 
                : "You haven't added any revenues yet. Start by adding your first revenue."}
            </Typography>
            
            <Button
              variant="contained"
              color="primary"
              startIcon={<AddIcon />}
              onClick={handleOpenDialog}
              sx={{ borderRadius: 8, px: 3 }}
            >
              Add Revenue
            </Button>
          </Box>
        )}
        
        {/* Revenue Add/Edit Dialog */}
        <Dialog
          open={open}
          onClose={handleCloseDialog}
          fullScreen={isMobile}
          TransitionComponent={Transition}
          PaperProps={{
            sx: {
              borderRadius: isMobile ? 0 : 4,
              overflow: 'hidden',
              backgroundImage: theme.palette.mode === 'dark' 
                ? `linear-gradient(to bottom, ${theme.palette.background.paper}, ${theme.palette.background.paper})`
                : 'linear-gradient(to bottom, rgba(255,255,255,0.95), rgba(255,255,255,1))',
              boxShadow: '0 0 20px rgba(0,0,0,0.1)',
              width: isMobile ? '100%' : '550px',
              maxHeight: isMobile ? '100%' : '85vh'
            }
          }}
        >
          <Box
            sx={{
              px: 3,
              pt: 2,
              pb: 1,
              bgcolor: theme.palette.mode === 'dark' 
                ? `linear-gradient(135deg, ${theme.palette.success.dark}, ${theme.palette.primary.dark})`
                : `linear-gradient(135deg, ${theme.palette.success.main}, ${theme.palette.primary.main})`,
              color: 'white',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between'
            }}
          >
            <DialogTitle sx={{ p: 0, fontSize: '1.2rem', fontWeight: 600 }}>
              {isEditing ? 'Edit Revenue' : 'Add New Revenue'}
            </DialogTitle>
            <IconButton
              edge="end"
              color="inherit"
              onClick={handleCloseDialog}
              aria-label="close"
            >
              <CloseIcon />
            </IconButton>
          </Box>
          <DialogContent sx={{ px: 3, pt: 3, pb: 1, overflowY: 'auto' }}>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <TextField
                  name="description"
                  label="Description"
                  value={revenuesToCreate.description}
                  onChange={handleChange}
                  fullWidth
                  variant="outlined"
                  required
                  autoFocus
                  InputProps={{
                    sx: {
                      borderRadius: 2,
                      backgroundColor: 'rgba(0,0,0,0.02)'
                    }
                  }}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  name="amount"
                  label="Amount (MYR)"
                  value={revenuesToCreate.amount}
                  onChange={handleChange}
                  fullWidth
                  variant="outlined"
                  required
                  type="number"
                  InputProps={{
                    startAdornment: <InputAdornment position="start">RM</InputAdornment>,
                    sx: {
                      borderRadius: 2,
                      backgroundColor: 'rgba(0,0,0,0.02)'
                    }
                  }}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <FormControl fullWidth variant="outlined" required>
                  <InputLabel>Category</InputLabel>
                  <Select
                    name="category"
                    label="Category"
                    value={revenuesToCreate.category}
                    onChange={handleChange}
                    sx={{
                      borderRadius: 2,
                      backgroundColor: 'rgba(0,0,0,0.02)'
                    }}
                  >
                    {categories.map(category => (
                      <MenuItem key={category} value={category}>
                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                          <Box sx={{ mr: 1.5, color: `${getCategoryColor(category)}.main`, display: 'flex' }}>
                            {getCategoryIcon(category)}
                          </Box>
                          {category}
                        </Box>
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12}>
                <DatePicker
                  label="Date"
                  value={revenuesToCreate.date}
                  onChange={handleDateChange}
                  slotProps={{
                    textField: {
                      fullWidth: true,
                      variant: 'outlined',
                      sx: {
                        '& .MuiInputBase-root': {
                          borderRadius: 2,
                          backgroundColor: 'rgba(0,0,0,0.02)'
                        }
                      }
                    }
                  }}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  name="source"
                  label="Source (Optional)"
                  value={revenuesToCreate.source}
                  onChange={handleChange}
                  fullWidth
                  variant="outlined"
                  InputProps={{
                    sx: {
                      borderRadius: 2,
                      backgroundColor: 'rgba(0,0,0,0.02)'
                    }
                  }}
                />
              </Grid>
            </Grid>
          </DialogContent>
          <DialogActions sx={{ px: 3, py: 2, justifyContent: 'flex-end' }}>
            <Button 
              onClick={handleCloseDialog}
              sx={{ 
                borderRadius: 8,
                px: 3,
                color: 'text.secondary',
                '&:hover': {
                  backgroundColor: 'rgba(0,0,0,0.05)'
                }
              }}
            >
              Cancel
            </Button>
            <Button 
              onClick={handleSubmit}
              variant="contained"
              color="primary"
              startIcon={<SaveIcon />}
              sx={{ 
                borderRadius: 8,
                px: 3,
                boxShadow: '0 4px 10px rgba(0, 122, 255, 0.3)'
              }}
            >
              {isEditing ? 'Save Changes' : 'Add Revenue'}
            </Button>
          </DialogActions>
        </Dialog>
        
        {/* View Revenue Dialog */}
        <Dialog
          open={viewDialog}
          onClose={() => setViewDialog(false)}
          fullScreen={isMobile}
          TransitionComponent={Transition}
          PaperProps={{
            sx: {
              borderRadius: isMobile ? 0 : 4,
              overflow: 'hidden',
              width: isMobile ? '100%' : '500px',
              backgroundImage: theme.palette.mode === 'dark' 
                ? `linear-gradient(to bottom, ${theme.palette.background.paper}, ${theme.palette.background.paper})`
                : 'linear-gradient(to bottom, rgba(255,255,255,0.95), rgba(255,255,255,1))',
              boxShadow: '0 0 20px rgba(0,0,0,0.1)'
            }
          }}
        >
          {selectedRevenue && (
            <>
              <Box
                sx={{
                  px: 3,
                  pt: 2,
                  pb: 1,
                  bgcolor: theme.palette.mode === 'dark' 
                    ? `linear-gradient(135deg, ${theme.palette.success.dark}, ${theme.palette.primary.dark})`
                    : `linear-gradient(135deg, ${theme.palette.success.main}, ${theme.palette.primary.main})`,
                  color: 'white',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between'
                }}
              >
                <DialogTitle sx={{ p: 0, fontSize: '1.2rem', fontWeight: 600 }}>
                  Revenue Details
                </DialogTitle>
                <IconButton
                  edge="end"
                  color="inherit"
                  onClick={() => setViewDialog(false)}
                  aria-label="close"
                >
                  <CloseIcon />
                </IconButton>
              </Box>
              <DialogContent sx={{ px: 3, pt: 3, pb: 0 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
                  <Avatar
                    sx={{
                      bgcolor: `${getCategoryColor(selectedRevenue.category)}.main`,
                      width: 56,
                      height: 56,
                      mr: 2
                    }}
                  >
                    {getCategoryIcon(selectedRevenue.category)}
                  </Avatar>
                  <Box>
                    <Typography variant="h6" sx={{ fontWeight: 600, lineHeight: 1.2 }}>
                      {selectedRevenue.description}
                    </Typography>
                    <Chip
                      label={selectedRevenue.category}
                      color={getCategoryColor(selectedRevenue.category)}
                      size="small"
                      sx={{ mt: 0.5 }}
                    />
                  </Box>
                </Box>
                
                <Paper
                  elevation={0}
                  sx={{
                    p: 2,
                    mb: 3,
                    borderRadius: 3,
                    backgroundColor: 'rgba(0,0,0,0.03)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between'
                  }}
                >
                  <Typography variant="body2" color="text.secondary">
                    Amount
                  </Typography>
                  <Typography variant="h5" color="success.main" sx={{ fontWeight: 700 }}>
                    {formatCurrency(selectedRevenue.amount)}
                  </Typography>
                </Paper>
                
                <Grid container spacing={2} sx={{ mb: 2 }}>
                  <Grid item xs={12}>
                    <Paper
                      elevation={0}
                      sx={{
                        p: 2,
                        borderRadius: 3,
                        backgroundColor: 'rgba(0,0,0,0.03)',
                        height: '100%'
                      }}
                    >
                      <Typography variant="body2" color="text.secondary" gutterBottom>
                        Date
                      </Typography>
                      <Typography variant="body1" sx={{ fontWeight: 500 }}>
                        {formatDate(selectedRevenue.date)}
                      </Typography>
                    </Paper>
                  </Grid>
                </Grid>
                
                {selectedRevenue.source && (
                  <Box sx={{ mb: 3 }}>
                    <Typography variant="body2" color="text.secondary" gutterBottom>
                      Source
                    </Typography>
                    <Typography variant="body1">
                      {selectedRevenue.source}
                    </Typography>
                  </Box>
                )}
              </DialogContent>
              <DialogActions sx={{ px: 3, py: 2, justifyContent: 'space-between' }}>
                <Button
                  color="error"
                  startIcon={<DeleteIcon />}
                  onClick={() => {
                    handleDeleteClick(selectedRevenue);
                    setViewDialog(false);
                  }}
                  sx={{ borderRadius: 8 }}
                >
                  Delete
                </Button>
                <Button
                  variant="contained"
                  color="primary"
                  startIcon={<EditIcon />}
                  onClick={() => {
                    handleEdit(selectedRevenue);
                    setViewDialog(false);
                  }}
                  sx={{ borderRadius: 8 }}
                >
                  Edit
                </Button>
              </DialogActions>
            </>
          )}
        </Dialog>
        
        {/* Delete Confirmation Dialog */}
        <Dialog
          open={deleteConfirmDialog}
          onClose={() => {
            // Only allow closing if not currently loading
            if (!loading && !isLoading) {
              setDeleteConfirmDialog(false);
              setError(null);
            }
          }}
          TransitionComponent={Transition}
          PaperProps={{
            sx: {
              borderRadius: 4,
              overflow: 'hidden',
              maxWidth: '400px'
            }
          }}
        >
          {selectedRevenue && (
            <>
              <DialogTitle sx={{ pt: 3, px: 3 }}>
                <Typography variant="h6" sx={{ fontWeight: 600 }}>
                  Delete Revenue
                </Typography>
              </DialogTitle>
              <DialogContent sx={{ px: 3, pt: 1 }}>
                {error && (
                  <Alert 
                    severity="error" 
                    sx={{ mb: 2, borderRadius: 2 }}
                    action={
                      <Button 
                        color="inherit" 
                        size="small"
                        onClick={() => setError(null)}
                      >
                        Dismiss
                      </Button>
                    }
                  >
                    {error}
                  </Alert>
                )}
                
                <Typography variant="body1" sx={{ mb: 2 }}>
                  Are you sure you want to delete this revenue?
                </Typography>
                
                <Paper
                  elevation={0}
                  sx={{
                    p: 2,
                    borderRadius: 3,
                    backgroundColor: 'rgba(0,0,0,0.03)',
                    display: 'flex',
                    alignItems: 'center'
                  }}
                >
                  <Avatar
                    sx={{
                      bgcolor: `${getCategoryColor(selectedRevenue.category)}.main`,
                      width: 40,
                      height: 40,
                      mr: 2
                    }}
                  >
                    {getCategoryIcon(selectedRevenue.category)}
                  </Avatar>
                  <Box sx={{ flex: 1 }}>
                    <Typography variant="subtitle2" sx={{ fontWeight: 500, lineHeight: 1.2 }}>
                      {selectedRevenue.description}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      {formatCurrency(selectedRevenue.amount)} • {formatDate(selectedRevenue.date)}
                    </Typography>
                  </Box>
                </Paper>
              </DialogContent>
              <DialogActions sx={{ px: 3, py: 2 }}>
                <Button
                  onClick={() => {
                    setDeleteConfirmDialog(false);
                    setError(null);
                  }}
                  disabled={loading || isLoading}
                  sx={{ 
                    borderRadius: 8, 
                    px: 3,
                    color: 'text.secondary'
                  }}
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleDeleteConfirm}
                  variant="contained"
                  color="error"
                  disabled={loading || isLoading}
                  startIcon={loading || isLoading ? <CircularProgress size={16} color="inherit" /> : null}
                  sx={{ 
                    borderRadius: 8,
                    px: 3
                  }}
                >
                  {loading || isLoading ? 'Deleting...' : 'Delete'}
                </Button>
              </DialogActions>
            </>
          )}
        </Dialog>
        
        {/* Add Revenue FAB for Mobile */}
        {isMobile && (
          <Box sx={{ position: 'fixed', bottom: 16, right: 16, zIndex: 10 }}>
            <Fab
              color="primary"
              aria-label="add revenue"
              onClick={handleOpenDialog}
              sx={{ 
                boxShadow: '0 4px 12px rgba(0, 122, 255, 0.5)',
                '&:hover': {
                  bgcolor: 'primary.dark'
                }
              }}
            >
              <AddIcon />
            </Fab>
          </Box>
        )}
      </Container>
    </LocalizationProvider>
  );
};

export default Revenues; 