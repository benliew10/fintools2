import React, { useEffect, useState } from 'react';
import {
  Container,
  Typography,
  Box,
  Button,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Grid,
  CircularProgress,
  TablePagination,
  InputAdornment,
  Alert,
  Chip,
  FormControlLabel,
  Checkbox,
  useTheme,
  useMediaQuery,
  Card,
  CardContent,
  Divider,
  Slide,
  Avatar,
  Fab,
  Drawer,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Collapse,
  Tabs,
  Tab,
  Stack,
  LinearProgress,
  Badge,
  Tooltip,
  SwipeableDrawer
} from '@mui/material';
import { LocalizationProvider, DatePicker } from '@mui/x-date-pickers';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Visibility as VisibilityIcon,
  Check as CheckIcon,
  Close as CloseIcon,
  MonetizationOn as MoneyIcon,
  Payment as PaymentIcon,
  SwapHoriz as TransferIcon,
  ArrowUpward as IncomeIcon,
  ArrowDownward as ExpenseIcon,
  FilterList as FilterIcon,
  Search as SearchIcon,
  AccountBalance as AccountBalanceIcon,
  SortByAlpha as SortIcon,
  CalendarToday as CalendarIcon,
  MoreVert as MoreIcon,
  AccountBalanceWallet as WalletIcon,
  TrendingUp as TrendingUpIcon,
  FilterAlt as FilterAltIcon,
  Save as SaveIcon,
  Refresh as RefreshIcon
} from '@mui/icons-material';
import axios from 'axios';
import { format, subDays, startOfMonth, endOfMonth, isWithinInterval } from 'date-fns';
// Import restored when needed for user authentication
// import { AuthContext } from '../../context/AuthContext';

// Transition component for dialogs
const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

export default function Transactions() {
  // Removed unused context
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  
  // Transaction form state
  const [openDialog, setOpenDialog] = useState(false);
  const [dialogMode, setDialogMode] = useState('add'); // 'add', 'edit', 'view'
  const [currentTransaction, setCurrentTransaction] = useState(null);
  const [formData, setFormData] = useState({
    type: 'expense',
    amount: '',
    description: '',
    category: '',
    date: new Date(),
    account: 'main',
    notes: '',
    isAsset: false,
    assetDepreciationRate: 0
  });
  
  // Delete confirmation
  const [openDeleteDialog, setOpenDeleteDialog] = useState(false);
  const [transactionToDelete, setTransactionToDelete] = useState(null);

  // Search and filter states
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [filterAccount, setFilterAccount] = useState('all');
  const [filterCategory, setFilterCategory] = useState('all');
  const [filterDateRange, setFilterDateRange] = useState('all'); // 'all', 'thisMonth', 'lastMonth', 'custom'
  const [filterStartDate, setFilterStartDate] = useState(subDays(new Date(), 30));
  const [filterEndDate, setFilterEndDate] = useState(new Date());
  
  // Mobile filter drawer
  const [filterDrawerOpen, setFilterDrawerOpen] = useState(false);
  
  // Tab state for mobile view
  const [tabValue, setTabValue] = useState(0);
  
  // Sort state
  const [sortBy, setSortBy] = useState('date');
  const [sortDirection, setSortDirection] = useState('desc');

  // Theme and responsive design
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const isTablet = useMediaQuery(theme.breakpoints.between('sm', 'md'));

  // Load transactions on component mount
  useEffect(() => {
    loadTransactions();
  }, []);

  // Fetch transactions from API
  const loadTransactions = async () => {
    try {
      setLoading(true);
      const res = await axios.get('/api/v1/transactions');
      setTransactions(res.data);
      setError('');
    } catch (err) {
      setError('Failed to load transactions. Please try again.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };
  
  // Handle dialog opening for adding a new transaction
  const handleAddClick = () => {
    setDialogMode('add');
    setCurrentTransaction(null);
    setFormData({
      type: 'expense',
      amount: '',
      description: '',
      category: '',
      date: new Date(),
      account: 'main',
      notes: '',
      isAsset: false,
      assetDepreciationRate: 0
    });
    setOpenDialog(true);
  };
  
  // Handle dialog opening for editing an existing transaction
  const handleEditClick = (transaction) => {
    setDialogMode('edit');
    setCurrentTransaction(transaction);
    setFormData({
      type: transaction.type || 'expense',
      amount: transaction.amount || '',
      description: transaction.description || '',
      category: transaction.category || '',
      date: transaction.date ? new Date(transaction.date) : new Date(),
      account: transaction.account || 'main',
      notes: transaction.notes || '',
      isAsset: transaction.isAsset || false,
      assetDepreciationRate: transaction.assetDepreciationRate || 0
    });
    setOpenDialog(true);
  };
  
  // Handle dialog opening for viewing transaction details
  const handleViewClick = (transaction) => {
    setDialogMode('view');
    setCurrentTransaction(transaction);
    setFormData({
      type: transaction.type || 'expense',
      amount: transaction.amount || '',
      description: transaction.description || '',
      category: transaction.category || '',
      date: transaction.date ? new Date(transaction.date) : new Date(),
      account: transaction.account || 'main',
      notes: transaction.notes || '',
      isAsset: transaction.isAsset || false,
      assetDepreciationRate: transaction.assetDepreciationRate || 0
    });
    setOpenDialog(true);
  };
  
  // Handle dialog close
  const handleDialogClose = () => {
    setOpenDialog(false);
  };
  
  // Handle form input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prevState => ({
      ...prevState,
      [name]: value
    }));
  };
  
  // Handle date change
  const handleDateChange = (newDate) => {
    setFormData(prevState => ({
      ...prevState,
      date: newDate
    }));
  };
  
  // Handle form submission
  const handleSubmit = async () => {
    try {
      if (dialogMode === 'add') {
        // Simulated API call to add a transaction
        const res = await axios.post('/api/v1/transactions', formData);
        setTransactions(prevTransactions => [...prevTransactions, res.data]);
      } else if (dialogMode === 'edit') {
        // Simulated API call to update a transaction
        const res = await axios.put(`/api/v1/transactions/${currentTransaction._id}`, formData);
        setTransactions(prevTransactions => 
          prevTransactions.map(t => t._id === currentTransaction._id ? res.data : t)
        );
      }
      
      setOpenDialog(false);
    } catch (err) {
      console.error('Error saving transaction:', err);
      // Handle error (e.g., show error message)
    }
  };
  
  // Handle delete click
  const handleDeleteClick = (transaction) => {
    setTransactionToDelete(transaction);
    setOpenDeleteDialog(true);
  };
  
  // Handle delete dialog close
  const handleDeleteDialogClose = () => {
    setOpenDeleteDialog(false);
    setTransactionToDelete(null);
  };
  
  // Handle delete confirmation
  const handleDeleteConfirm = async () => {
    try {
      // Simulated API call to delete a transaction
      await axios.delete(`/api/v1/transactions/${transactionToDelete._id}`);
      setTransactions(prevTransactions => 
        prevTransactions.filter(t => t._id !== transactionToDelete._id)
      );
      setOpenDeleteDialog(false);
      setTransactionToDelete(null);
    } catch (err) {
      console.error('Error deleting transaction:', err);
      // Handle error (e.g., show error message)
    }
  };
  
  // Handle pagination
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };
  
  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  // Format date for display
  const formatDate = (dateString) => {
    try {
      return format(new Date(dateString), 'dd MMM yyyy');
    } catch (error) {
      return 'Invalid date';
    }
  };

  // Format amount with Malaysian Ringgit (MYR)
  const formatCurrency = (amount) => {
    if (amount === undefined || amount === null) return '-';
    return new Intl.NumberFormat('ms-MY', {
      style: 'currency',
      currency: 'MYR',
      minimumFractionDigits: 2
    }).format(amount);
  };

  // Get an icon for the transaction type
  const getTypeIcon = (type) => {
    switch (type) {
      case 'income':
        return <IncomeIcon sx={{ color: theme.palette.success.main }} />;
      case 'expense':
        return <ExpenseIcon sx={{ color: theme.palette.error.main }} />;
      case 'transfer':
        return <TransferIcon sx={{ color: theme.palette.info.main }} />;
      case 'investment':
        return <AccountBalanceIcon sx={{ color: theme.palette.warning.main }} />;
      default:
        return <MoneyIcon />;
    }
  };

  // Get a color for the transaction type chip
  const getTypeColor = (type) => {
    switch (type) {
      case 'income':
        return 'success';
      case 'expense':
        return 'error';
      case 'transfer':
        return 'info';
      case 'investment':
        return 'warning';
      default:
        return 'default';
    }
  };

  // Get a color for the account chip
  const getAccountColor = (account) => {
    switch (account) {
      case 'main':
        return 'primary';
      case 'savings':
        return 'success';
      case 'investment':
        return 'warning';
      case 'petty-cash':
        return 'secondary';
      default:
        return 'default';
    }
  };

  // Get account icon
  const getAccountIcon = (account) => {
    switch (account) {
      case 'savings':
        return <AccountBalanceIcon />;
      case 'investment':
        return <AccountBalanceIcon />;
      case 'petty-cash':
        return <PaymentIcon />;
      default:
        return <WalletIcon />;
    }
  };

  // Calculate summary statistics
  const calculateSummary = () => {
    const thisMonth = {
      start: startOfMonth(new Date()),
      end: endOfMonth(new Date())
    };

    const summary = {
      totalIncome: 0,
      totalExpense: 0,
      totalTransfer: 0,
      totalInvestment: 0,
      thisMonthIncome: 0,
      thisMonthExpense: 0,
      accountBalances: {
        main: 0,
        savings: 0,
        investment: 0,
        'petty-cash': 0
      }
    };

    transactions.forEach(transaction => {
      const amount = parseFloat(transaction.amount);
      const date = new Date(transaction.date);
      const isThisMonth = isWithinInterval(date, { 
        start: thisMonth.start, 
        end: thisMonth.end 
      });

      // Calculate total by type
      if (transaction.type === 'income') {
        summary.totalIncome += amount;
        if (isThisMonth) summary.thisMonthIncome += amount;
        summary.accountBalances[transaction.account] += amount;
      } else if (transaction.type === 'expense') {
        summary.totalExpense += amount;
        if (isThisMonth) summary.thisMonthExpense += amount;
        summary.accountBalances[transaction.account] -= amount;
      } else if (transaction.type === 'transfer') {
        summary.totalTransfer += amount;
        // For transfers, we would need to know source and destination accounts
        // This is simplified
      } else if (transaction.type === 'investment') {
        summary.totalInvestment += amount;
        // Investment can be more complex, but we're simplifying
      }
    });

    return summary;
  };

  // Filter transactions based on search and filters
  const filterTransactions = () => {
    return transactions.filter(transaction => {
      // Search term filter
      const matchesSearch = searchTerm === '' || (
        (transaction.description && transaction.description.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (transaction.notes && transaction.notes.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (transaction.category && transaction.category.toLowerCase().includes(searchTerm.toLowerCase()))
      );

      // Type filter
      const matchesType = filterType === 'all' || transaction.type === filterType;

      // Account filter
      const matchesAccount = filterAccount === 'all' || transaction.account === filterAccount;

      // Category filter
      const matchesCategory = filterCategory === 'all' || transaction.category === filterCategory;

      // Date range filter
      let matchesDateRange = true;
      if (filterDateRange !== 'all') {
        const transactionDate = new Date(transaction.date);
        
        if (filterDateRange === 'thisMonth') {
          const thisMonthStart = startOfMonth(new Date());
          const thisMonthEnd = endOfMonth(new Date());
          matchesDateRange = isWithinInterval(transactionDate, { 
            start: thisMonthStart, 
            end: thisMonthEnd 
          });
        } else if (filterDateRange === 'lastMonth') {
          const lastMonth = new Date();
          lastMonth.setMonth(lastMonth.getMonth() - 1);
          const lastMonthStart = startOfMonth(lastMonth);
          const lastMonthEnd = endOfMonth(lastMonth);
          matchesDateRange = isWithinInterval(transactionDate, { 
            start: lastMonthStart, 
            end: lastMonthEnd 
          });
        } else if (filterDateRange === 'custom') {
          matchesDateRange = isWithinInterval(transactionDate, { 
            start: filterStartDate, 
            end: filterEndDate 
          });
        }
      }

      return matchesSearch && matchesType && matchesAccount && matchesCategory && matchesDateRange;
    });
  };

  // Sort transactions
  const sortTransactions = (filteredTransactions) => {
    return [...filteredTransactions].sort((a, b) => {
      if (sortBy === 'date') {
        const dateA = new Date(a.date);
        const dateB = new Date(b.date);
        return sortDirection === 'asc' ? dateA - dateB : dateB - dateA;
      } else if (sortBy === 'amount') {
        return sortDirection === 'asc' ? a.amount - b.amount : b.amount - a.amount;
      } else if (sortBy === 'description') {
        const descA = a.description.toLowerCase();
        const descB = b.description.toLowerCase();
        return sortDirection === 'asc' 
          ? descA.localeCompare(descB) 
          : descB.localeCompare(descA);
      }
      return 0;
    });
  };

  // Get the appropriate category options based on transaction type
  const getCategoryOptions = () => {
    if (formData.type === 'expense') {
      return [
        'Phone',
        'Rental',
        'Salary',
        'Accessories',
        'Marketing',
        'Transport',
        'Courier',
        'Bonus',
        'Advertisement',
        'Other'
      ];
    } else if (formData.type === 'income') {
      return ['Sales', 'Services', 'Investments', 'Grants', 'Royalties', 'Interest', 'Other'];
    } else if (formData.type === 'transfer') {
      return ['Internal Transfer', 'External Transfer', 'Other'];
    } else {
      return ['Equity', 'Debt', 'Convertible', 'Other'];
    }
  };

  // Check if a category can be considered an asset
  const canBeAsset = (category) => {
    // Categories that can be considered assets if not sold/used up
    return ['Phone', 'Accessories', 'Marketing', 'Transport', 'Other'].includes(category);
  };

  // Add this function to handle asset checkbox toggle
  const handleAssetToggle = (e) => {
    setFormData({
      ...formData,
      isAsset: e.target.checked
    });
  };

  // Enhance UI with loader
  if (loading) {
    return (
      <Box sx={{ 
        display: 'flex', 
        flexDirection: 'column',
        alignItems: 'center', 
        justifyContent: 'center', 
        height: '80vh',
        p: 3
      }}>
        <CircularProgress 
          size={isMobile ? 40 : 60} 
          thickness={4} 
          sx={{ 
            mb: 2,
            color: theme.palette.primary.main
          }} 
        />
        <Typography variant="h6" color="text.secondary" align="center">
          Loading transactions...
        </Typography>
        <Typography variant="body2" color="text.secondary" align="center" sx={{ mt: 1, maxWidth: 300 }}>
          Preparing your financial data for display
        </Typography>
      </Box>
    );
  }

  // Enhanced error UI
  if (error) {
    return (
      <Box sx={{ p: 3 }}>
        <Paper 
          elevation={2} 
          sx={{ 
            p: 3, 
            borderRadius: 4,
            bgcolor: 'error.light',
            color: 'error.contrastText'
          }}
        >
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
            <Avatar sx={{ bgcolor: 'error.main', mr: 2 }}>
              <CloseIcon />
            </Avatar>
            <Typography variant="h6">
              Error Loading Data
            </Typography>
          </Box>
          <Typography variant="body1" sx={{ mb: 3 }}>
            {error}
          </Typography>
          <Button 
            variant="contained" 
            sx={{ 
              borderRadius: 8,
              bgcolor: 'white',
              color: 'error.main',
              '&:hover': {
                bgcolor: 'rgba(255,255,255,0.9)',
              }
            }}
            onClick={loadTransactions}
            startIcon={<RefreshIcon />}
          >
            Try Again
          </Button>
        </Paper>
      </Box>
    );
  }

  // Get filtered and sorted transactions
  const filteredTransactions = filterTransactions();
  const sortedTransactions = sortTransactions(filteredTransactions);
  const paginatedTransactions = sortedTransactions.slice(
    page * rowsPerPage,
    page * rowsPerPage + rowsPerPage
  );

  // Calculate summary statistics
  const summary = calculateSummary();

  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <Box sx={{ pb: isMobile ? 7 : 3 }}>
        {/* Header */}
        <Box 
          sx={{ 
            pt: isMobile ? 2 : 3, 
            pb: 2,
            px: isMobile ? 2 : 3,
            background: theme.palette.mode === 'dark' 
              ? `linear-gradient(135deg, ${theme.palette.primary.dark}, ${theme.palette.secondary.dark})` 
              : `linear-gradient(135deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
            borderRadius: isMobile ? '0 0 24px 24px' : '0 0 16px 16px',
            mb: 2,
            boxShadow: '0 4px 20px rgba(0,0,0,0.1)'
          }}
        >
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: isMobile ? 1 : 2 }}>
            <Typography 
              variant={isMobile ? "h5" : "h4"} 
              sx={{ 
                fontWeight: 600,
                color: '#ffffff'
              }}
            >
              Transactions
            </Typography>
            {!isMobile && (
              <Button
                variant="contained"
                startIcon={<AddIcon />}
                onClick={handleAddClick}
                sx={{ 
                  borderRadius: 8,
                  px: 3,
                  py: 1,
                  bgcolor: 'white',
                  color: theme.palette.primary.main,
                  '&:hover': {
                    bgcolor: 'rgba(255,255,255,0.9)',
                  },
                  boxShadow: '0 4px 8px rgba(0,0,0,0.1)'
                }}
              >
                Add Transaction
              </Button>
            )}
          </Box>

          {/* Summary Cards - For desktop and tablet */}
          {!isMobile && (
            <Grid container spacing={2} sx={{ mt: 1 }}>
              <Grid item xs={12} md={3}>
                <Paper 
                  elevation={2}
                  sx={{ 
                    p: 2, 
                    borderRadius: 4,
                    bgcolor: 'rgba(255,255,255,0.9)',
                    display: 'flex',
                    alignItems: 'center',
                    backdropFilter: 'blur(10px)',
                    boxShadow: '0 4px 8px rgba(0,0,0,0.1)'
                  }}
                >
                  <Avatar sx={{ bgcolor: theme.palette.success.main, mr: 2 }}>
                    <IncomeIcon />
                  </Avatar>
                  <Box>
                    <Typography variant="body2" color="text.secondary">Total Income</Typography>
                    <Typography variant="h6" color="success.main" sx={{ fontWeight: 'bold' }}>
                      {formatCurrency(summary.totalIncome)}
                    </Typography>
                  </Box>
                </Paper>
              </Grid>
              <Grid item xs={12} md={3}>
                <Paper 
                  elevation={2}
                  sx={{ 
                    p: 2, 
                    borderRadius: 4,
                    bgcolor: 'rgba(255,255,255,0.9)',
                    display: 'flex',
                    alignItems: 'center',
                    backdropFilter: 'blur(10px)',
                    boxShadow: '0 4px 8px rgba(0,0,0,0.1)'
                  }}
                >
                  <Avatar sx={{ bgcolor: theme.palette.error.main, mr: 2 }}>
                    <ExpenseIcon />
                  </Avatar>
                  <Box>
                    <Typography variant="body2" color="text.secondary">Total Expenses</Typography>
                    <Typography variant="h6" color="error.main" sx={{ fontWeight: 'bold' }}>
                      {formatCurrency(summary.totalExpense)}
                    </Typography>
                  </Box>
                </Paper>
              </Grid>
              <Grid item xs={12} md={3}>
                <Paper 
                  elevation={2}
                  sx={{ 
                    p: 2, 
                    borderRadius: 4,
                    bgcolor: 'rgba(255,255,255,0.9)',
                    display: 'flex',
                    alignItems: 'center',
                    cursor: 'pointer',
                    backdropFilter: 'blur(10px)',
                    boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
                    transition: 'transform 0.2s',
                    '&:hover': {
                      transform: 'translateY(-2px)'
                    }
                  }}
                  onClick={() => setFilterDateRange(filterDateRange === 'thisMonth' ? 'all' : 'thisMonth')}
                >
                  <Avatar sx={{ bgcolor: theme.palette.primary.main, mr: 2 }}>
                    <CalendarIcon />
                  </Avatar>
                  <Box>
                    <Typography variant="body2" color="text.secondary">This Month</Typography>
                    <Typography variant="h6" sx={{ fontWeight: 'bold' }}>
                      {formatCurrency(summary.thisMonthIncome - summary.thisMonthExpense)}
                    </Typography>
                  </Box>
                </Paper>
              </Grid>
            </Grid>
          )}
        </Box>

        {/* Mobile summary */}
        {isMobile && (
          <Box sx={{ px: 2, mb: 2 }}>
            <Paper 
              elevation={2}
              sx={{ 
                p: 2, 
                borderRadius: 4,
                overflow: 'hidden',
                boxShadow: '0 2px 10px rgba(0,0,0,0.08)'
              }}
            >
              <Grid container spacing={2}>
                <Grid item xs={6}>
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <Avatar 
                      sx={{ 
                        bgcolor: theme.palette.success.main, 
                        width: 24, 
                        height: 24,
                        mr: 1
                      }}
                    >
                      <IncomeIcon sx={{ fontSize: 14 }} />
                    </Avatar>
                    <Typography variant="body2" color="text.secondary">Income</Typography>
                  </Box>
                  <Typography variant="h6" color="success.main" sx={{ fontWeight: 'bold', mt: 0.5 }}>
                    {formatCurrency(summary.totalIncome)}
                  </Typography>
                </Grid>
                <Grid item xs={6}>
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <Avatar 
                      sx={{ 
                        bgcolor: theme.palette.error.main, 
                        width: 24, 
                        height: 24,
                        mr: 1
                      }}
                    >
                      <ExpenseIcon sx={{ fontSize: 14 }} />
                    </Avatar>
                    <Typography variant="body2" color="text.secondary">Expenses</Typography>
                  </Box>
                  <Typography variant="h6" color="error.main" sx={{ fontWeight: 'bold', mt: 0.5 }}>
                    {formatCurrency(summary.totalExpense)}
                  </Typography>
                </Grid>
                <Grid item xs={12}>
                  <Divider sx={{ my: 1 }} />
                  <Typography variant="body2" color="text.secondary">Balance</Typography>
                  <Typography variant="h6" sx={{ fontWeight: 'bold' }}>
                    {formatCurrency(summary.totalIncome - summary.totalExpense)}
                  </Typography>
                </Grid>
              </Grid>
            </Paper>
          </Box>
        )}

        {/* Search and filter tools */}
        <Box sx={{ px: isMobile ? 2 : 3, mb: 2 }}>
          <Paper sx={{ p: 2, borderRadius: 4, boxShadow: '0 2px 10px rgba(0,0,0,0.08)' }}>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
              <TextField
                placeholder="Search transactions..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                variant="outlined"
                fullWidth
                size={isMobile ? "small" : "medium"}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchIcon />
                    </InputAdornment>
                  ),
                  sx: { borderRadius: 8 }
                }}
              />
              {!isMobile && (
                <Button
                  startIcon={<FilterAltIcon />}
                  variant="outlined"
                  sx={{ 
                    ml: 2, 
                    borderRadius: 8, 
                    whiteSpace: 'nowrap',
                    borderColor: filterType !== 'all' || filterAccount !== 'all' || filterDateRange !== 'all' 
                      ? theme.palette.primary.main 
                      : undefined,
                    bgcolor: filterType !== 'all' || filterAccount !== 'all' || filterDateRange !== 'all'
                      ? 'rgba(25, 118, 210, 0.08)'
                      : undefined
                  }}
                  onClick={() => setFilterDrawerOpen(true)}
                >
                  {filterType !== 'all' || filterAccount !== 'all' || filterDateRange !== 'all' 
                    ? 'Filters Applied' 
                    : 'Filters'}
                </Button>
              )}
              {!isMobile && (
                <Button
                  startIcon={<SortIcon />}
                  variant="outlined"
                  sx={{ ml: 2, borderRadius: 8, whiteSpace: 'nowrap' }}
                  onClick={() => {
                    if (sortBy === 'date') {
                      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
                    } else {
                      setSortBy('date');
                      setSortDirection('desc');
                    }
                  }}
                >
                  {sortBy === 'date' && sortDirection === 'desc' ? 'Newest' : 'Oldest'}
                </Button>
              )}
            </Box>

            {/* Quick filter chips */}
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
              <Chip 
                label="All"
                color={filterType === 'all' ? 'primary' : 'default'}
                onClick={() => setFilterType('all')}
                sx={{ borderRadius: 8 }}
              />
              <Chip 
                label="Income"
                color={filterType === 'income' ? 'success' : 'default'}
                onClick={() => setFilterType('income')}
                icon={<IncomeIcon />}
                sx={{ borderRadius: 8 }}
              />
              <Chip 
                label="Expense"
                color={filterType === 'expense' ? 'error' : 'default'}
                onClick={() => setFilterType('expense')}
                icon={<ExpenseIcon />}
                sx={{ borderRadius: 8 }}
              />
              <Chip 
                label="Transfer"
                color={filterType === 'transfer' ? 'info' : 'default'}
                onClick={() => setFilterType('transfer')}
                icon={<TransferIcon />}
                sx={{ borderRadius: 8 }}
              />
              <Chip 
                label="Investment"
                color={filterType === 'investment' ? 'warning' : 'default'}
                onClick={() => setFilterType('investment')}
                icon={<AccountBalanceIcon />}
                sx={{ borderRadius: 8 }}
              />
            </Box>
          </Paper>
        </Box>

        {/* Mobile tabs */}
        {isMobile && (
          <Box sx={{ px: 2, mb: 2 }}>
            <Tabs 
              value={tabValue} 
              onChange={(e, newValue) => {
                setTabValue(newValue);
                if (newValue === 0) setFilterType('all');
                if (newValue === 1) setFilterType('income');
                if (newValue === 2) setFilterType('expense');
              }}
              variant="fullWidth"
              sx={{
                '& .MuiTabs-indicator': {
                  backgroundColor: theme.palette.primary.main,
                  height: 3,
                  borderRadius: 1.5
                }
              }}
            >
              <Tab 
                label="All" 
                sx={{ 
                  textTransform: 'none',
                  fontWeight: tabValue === 0 ? 'bold' : 'normal'
                }} 
              />
              <Tab 
                label="Income" 
                sx={{ 
                  textTransform: 'none',
                  fontWeight: tabValue === 1 ? 'bold' : 'normal',
                  color: tabValue === 1 ? theme.palette.success.main : 'inherit'
                }} 
              />
              <Tab 
                label="Expenses" 
                sx={{ 
                  textTransform: 'none',
                  fontWeight: tabValue === 2 ? 'bold' : 'normal',
                  color: tabValue === 2 ? theme.palette.error.main : 'inherit'
                }} 
              />
            </Tabs>
          </Box>
        )}

        {/* Empty state */}
        {paginatedTransactions.length === 0 && (
          <Box sx={{ 
            p: 3, 
            display: 'flex', 
            flexDirection: 'column', 
            alignItems: 'center', 
            justifyContent: 'center',
            minHeight: '200px'
          }}>
            <Avatar sx={{ 
              bgcolor: 'rgba(25, 118, 210, 0.08)', 
              width: 60, 
              height: 60,
              mb: 2 
            }}>
              <MoneyIcon sx={{ color: theme.palette.primary.main, fontSize: 32 }} />
            </Avatar>
            <Typography variant="h6" color="text.secondary" align="center" gutterBottom>
              No transactions found
            </Typography>
            <Typography variant="body2" color="text.secondary" align="center" sx={{ mb: 3, maxWidth: 300 }}>
              {searchTerm || filterType !== 'all' || filterAccount !== 'all' || filterCategory !== 'all' || filterDateRange !== 'all' ? 
                'Try adjusting your filters to see more results' : 
                'Get started by adding your first transaction'}
            </Typography>
            <Button
              variant="contained"
              startIcon={<AddIcon />}
              onClick={handleAddClick}
              sx={{ borderRadius: 8 }}
            >
              Add Transaction
            </Button>
          </Box>
        )}

        {/* Transactions list for Mobile */}
        {isMobile && paginatedTransactions.length > 0 && (
          <Box sx={{ px: 2 }}>
            {paginatedTransactions.map((transaction) => (
              <Card 
                key={transaction._id}
                sx={{ 
                  mb: 2, 
                  borderRadius: 4,
                  boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
                  transition: 'transform 0.2s, box-shadow 0.2s',
                  '&:active': {
                    transform: 'scale(0.98)',
                    boxShadow: '0 1px 4px rgba(0,0,0,0.1)'
                  }
                }}
                onClick={() => handleViewClick(transaction)}
              >
                <CardContent sx={{ p: 2, '&:last-child': { pb: 2 } }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                      <Avatar 
                        sx={{ 
                          bgcolor: `${theme.palette[getTypeColor(transaction.type)].light}22`,
                          color: theme.palette[getTypeColor(transaction.type)].main,
                          width: 40,
                          height: 40
                        }}
                      >
                        {getTypeIcon(transaction.type)}
                      </Avatar>
                      <Box sx={{ ml: 2 }}>
                        <Typography variant="body1" sx={{ fontWeight: 'medium' }}>
                          {transaction.description}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          {formatDate(transaction.date)} • {transaction.category}
                        </Typography>
                      </Box>
                    </Box>
                    <Typography 
                      variant="body1" 
                      sx={{ 
                        fontWeight: 'bold',
                        color: transaction.type === 'expense' ? theme.palette.error.main : 
                              transaction.type === 'income' ? theme.palette.success.main : 
                              theme.palette.text.primary
                      }}
                    >
                      {transaction.type === 'expense' ? '-' : transaction.type === 'income' ? '+' : ''}
                      {formatCurrency(transaction.amount)}
                    </Typography>
                  </Box>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 1 }}>
                    <Chip 
                      label={transaction.account}
                      size="small"
                      color={getAccountColor(transaction.account)}
                      variant="outlined"
                      sx={{ borderRadius: 8 }}
                    />
                    <Box>
                      <IconButton 
                        size="small" 
                        color="primary"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleEditClick(transaction);
                        }}
                        sx={{ backgroundColor: 'rgba(25, 118, 210, 0.08)', mr: 1 }}
                      >
                        <EditIcon fontSize="small" />
                      </IconButton>
                      <IconButton 
                        size="small" 
                        color="error"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteClick(transaction);
                        }}
                        sx={{ backgroundColor: 'rgba(211, 47, 47, 0.08)' }}
                      >
                        <DeleteIcon fontSize="small" />
                      </IconButton>
                    </Box>
                  </Box>
                </CardContent>
              </Card>
            ))}
            {filteredTransactions.length > rowsPerPage && (
              <Box sx={{ display: 'flex', justifyContent: 'center', mb: 2 }}>
                <TablePagination
                  component="div"
                  count={filteredTransactions.length}
                  page={page}
                  onPageChange={handleChangePage}
                  rowsPerPage={rowsPerPage}
                  onRowsPerPageChange={handleChangeRowsPerPage}
                  labelRowsPerPage=""
                  rowsPerPageOptions={[5, 10, 25]}
                />
              </Box>
            )}
          </Box>
        )}

        {/* Table for Desktop */}
        {!isMobile && paginatedTransactions.length > 0 && (
          <Paper elevation={2} sx={{ mx: 3, borderRadius: 4, overflow: 'hidden', boxShadow: '0 2px 10px rgba(0,0,0,0.08)' }}>
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow sx={{ bgcolor: theme.palette.mode === 'dark' ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.02)' }}>
                    <TableCell sx={{ fontWeight: 'bold' }}>Date</TableCell>
                    <TableCell sx={{ fontWeight: 'bold' }}>Description</TableCell>
                    <TableCell sx={{ fontWeight: 'bold' }}>Type</TableCell>
                    <TableCell sx={{ fontWeight: 'bold' }}>Account</TableCell>
                    <TableCell sx={{ fontWeight: 'bold' }}>Category</TableCell>
                    <TableCell align="right" sx={{ fontWeight: 'bold' }}>Amount (MYR)</TableCell>
                    <TableCell align="center" sx={{ fontWeight: 'bold' }}>Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {paginatedTransactions.map((transaction) => (
                    <TableRow 
                      key={transaction._id}
                      hover
                      sx={{ 
                        '&:hover': { 
                          bgcolor: theme.palette.action.hover,
                          cursor: 'pointer'
                        }
                      }}
                      onClick={() => handleViewClick(transaction)}
                    >
                      <TableCell>{formatDate(transaction.date)}</TableCell>
                      <TableCell>{transaction.description}</TableCell>
                      <TableCell>
                        <Chip 
                          icon={getTypeIcon(transaction.type)}
                          label={transaction.type.charAt(0).toUpperCase() + transaction.type.slice(1)} 
                          color={getTypeColor(transaction.type)}
                          size="small"
                          sx={{ borderRadius: 8 }}
                        />
                      </TableCell>
                      <TableCell>
                        <Chip 
                          label={transaction.account.charAt(0).toUpperCase() + transaction.account.slice(1)} 
                          color={getAccountColor(transaction.account)}
                          size="small"
                          variant="outlined"
                          sx={{ borderRadius: 8 }}
                        />
                      </TableCell>
                      <TableCell>{transaction.category}</TableCell>
                      <TableCell 
                        align="right" 
                        sx={{ 
                          fontWeight: 'bold',
                          color: transaction.type === 'expense' ? 'error.main' : 
                                transaction.type === 'income' ? 'success.main' : 'inherit'
                        }}
                      >
                        {formatCurrency(transaction.amount)}
                      </TableCell>
                      <TableCell align="center">
                        <IconButton
                          size="small"
                          color="primary"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleViewClick(transaction);
                          }}
                          sx={{ mr: 0.5 }}
                        >
                          <VisibilityIcon fontSize="small" />
                        </IconButton>
                        <IconButton
                          size="small"
                          color="secondary"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleEditClick(transaction);
                          }}
                          sx={{ mr: 0.5 }}
                        >
                          <EditIcon fontSize="small" />
                        </IconButton>
                        <IconButton
                          size="small"
                          color="error"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteClick(transaction);
                          }}
                        >
                          <DeleteIcon fontSize="small" />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
            <TablePagination
              component="div"
              count={filteredTransactions.length}
              rowsPerPage={rowsPerPage}
              page={page}
              onPageChange={handleChangePage}
              onRowsPerPageChange={handleChangeRowsPerPage}
            />
          </Paper>
        )}

        {/* Floating Action Button for Mobile */}
        {isMobile && (
          <Fab
            color="primary"
            aria-label="add"
            sx={{
              position: 'fixed',
              bottom: 72,
              right: 16,
              boxShadow: '0 4px 12px rgba(0,0,0,0.2)'
            }}
            onClick={handleAddClick}
          >
            <AddIcon />
          </Fab>
        )}

        {/* Add filter button for mobile */}
        {isMobile && (
          <Fab
            size="small"
            color="secondary"
            aria-label="filter"
            sx={{
              position: 'fixed',
              bottom: 72,
              left: 16,
              boxShadow: '0 4px 12px rgba(0,0,0,0.2)'
            }}
            onClick={() => setFilterDrawerOpen(true)}
          >
            <FilterAltIcon />
          </Fab>
        )}

        {/* Filter Drawer for Mobile */}
        <SwipeableDrawer
          anchor="bottom"
          open={filterDrawerOpen}
          onClose={() => setFilterDrawerOpen(false)}
          onOpen={() => setFilterDrawerOpen(true)}
          PaperProps={{
            sx: {
              borderTopLeftRadius: 16,
              borderTopRightRadius: 16,
              maxHeight: '80vh'
            }
          }}
          disableSwipeToOpen={false}
          swipeAreaWidth={30}
        >
          <Box sx={{ width: '100%', height: 4, bgcolor: 'rgba(0,0,0,0.1)', mx: 'auto', mt: 1, borderRadius: 2 }} />
          <Box sx={{ p: 2 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="h6" sx={{ fontWeight: 'bold' }}>Filters</Typography>
              <IconButton onClick={() => setFilterDrawerOpen(false)}>
                <CloseIcon />
              </IconButton>
            </Box>
            
            <List disablePadding>
              <ListItem>
                <FormControl fullWidth sx={{ mb: 2 }}>
                  <InputLabel>Transaction Type</InputLabel>
                  <Select
                    value={filterType}
                    onChange={(e) => setFilterType(e.target.value)}
                    label="Transaction Type"
                    sx={{ borderRadius: 8 }}
                  >
                    <MenuItem value="all">All Types</MenuItem>
                    <MenuItem value="income">Income</MenuItem>
                    <MenuItem value="expense">Expense</MenuItem>
                    <MenuItem value="transfer">Transfer</MenuItem>
                    <MenuItem value="investment">Investment</MenuItem>
                  </Select>
                </FormControl>
              </ListItem>
              
              <ListItem>
                <FormControl fullWidth sx={{ mb: 2 }}>
                  <InputLabel>Account</InputLabel>
                  <Select
                    value={filterAccount}
                    onChange={(e) => setFilterAccount(e.target.value)}
                    label="Account"
                    sx={{ borderRadius: 8 }}
                  >
                    <MenuItem value="all">All Accounts</MenuItem>
                    <MenuItem value="main">Main</MenuItem>
                    <MenuItem value="savings">Savings</MenuItem>
                    <MenuItem value="investment">Investment</MenuItem>
                    <MenuItem value="petty-cash">Petty Cash</MenuItem>
                  </Select>
                </FormControl>
              </ListItem>
              
              <ListItem>
                <FormControl fullWidth sx={{ mb: 2 }}>
                  <InputLabel>Date Range</InputLabel>
                  <Select
                    value={filterDateRange}
                    onChange={(e) => setFilterDateRange(e.target.value)}
                    label="Date Range"
                    sx={{ borderRadius: 8 }}
                  >
                    <MenuItem value="all">All Time</MenuItem>
                    <MenuItem value="thisMonth">This Month</MenuItem>
                    <MenuItem value="lastMonth">Last Month</MenuItem>
                    <MenuItem value="custom">Custom Range</MenuItem>
                  </Select>
                </FormControl>
              </ListItem>
              
              {filterDateRange === 'custom' && (
                <>
                  <ListItem>
                    <DatePicker
                      label="Start Date"
                      value={filterStartDate}
                      onChange={(newDate) => setFilterStartDate(newDate)}
                      renderInput={(params) => 
                        <TextField 
                          {...params} 
                          fullWidth 
                          sx={{ mb: 2 }}
                          InputProps={{
                            ...params.InputProps,
                            sx: { borderRadius: 8 }
                          }}
                        />
                      }
                    />
                  </ListItem>
                  
                  <ListItem>
                    <DatePicker
                      label="End Date"
                      value={filterEndDate}
                      onChange={(newDate) => setFilterEndDate(newDate)}
                      renderInput={(params) => 
                        <TextField 
                          {...params} 
                          fullWidth
                          InputProps={{
                            ...params.InputProps,
                            sx: { borderRadius: 8 }
                          }}
                        />
                      }
                    />
                  </ListItem>
                </>
              )}
            </List>
            
            <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 2 }}>
              <Button 
                variant="outlined" 
                onClick={() => {
                  setFilterType('all');
                  setFilterAccount('all');
                  setFilterCategory('all');
                  setFilterDateRange('all');
                  setSearchTerm('');
                }}
                sx={{ borderRadius: 8 }}
              >
                Clear All
              </Button>
              <Button 
                variant="contained" 
                onClick={() => setFilterDrawerOpen(false)}
                sx={{ borderRadius: 8 }}
              >
                Apply Filters
              </Button>
            </Box>
          </Box>
        </SwipeableDrawer>

        {/* Add/Edit/View Transaction Dialog */}
        <Dialog 
          open={openDialog} 
          onClose={handleDialogClose} 
          maxWidth="sm" 
          fullWidth
          fullScreen={isMobile}
          TransitionComponent={Transition}
          PaperProps={{
            sx: {
              borderRadius: isMobile ? 0 : 4,
              overflow: 'hidden'
            }
          }}
        >
          <Box sx={{ 
            bgcolor: theme.palette.mode === 'dark' 
              ? `linear-gradient(135deg, ${theme.palette.primary.dark}, ${theme.palette.secondary.dark})` 
              : `linear-gradient(135deg, ${theme.palette.primary.main}, ${theme.palette.secondary.main})`,
            py: 2,
            px: 3
          }}>
            <DialogTitle sx={{ p: 0, color: 'white', fontWeight: 'medium' }}>
              {dialogMode === 'add'
                ? 'Add New Transaction'
                : dialogMode === 'edit'
                ? 'Edit Transaction'
                : 'Transaction Details'}
            </DialogTitle>
            {isMobile && (
              <IconButton
                edge="end"
                color="inherit"
                onClick={handleDialogClose}
                sx={{ position: 'absolute', right: 8, top: 8 }}
              >
                <CloseIcon />
              </IconButton>
            )}
          </Box>
          
          <DialogContent sx={{ px: isMobile ? 2 : 3, py: 3 }}>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={6}>
                <FormControl fullWidth disabled={dialogMode === 'view'}>
                  <InputLabel>Type</InputLabel>
                  <Select
                    name="type"
                    value={formData.type}
                    onChange={handleInputChange}
                    label="Type"
                    sx={{ borderRadius: 8 }}
                    startAdornment={
                      <InputAdornment position="start">
                        {getTypeIcon(formData.type)}
                      </InputAdornment>
                    }
                  >
                    <MenuItem value="income">
                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <IncomeIcon sx={{ mr: 1, color: theme.palette.success.main }} />
                        Income
                      </Box>
                    </MenuItem>
                    <MenuItem value="expense">
                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <ExpenseIcon sx={{ mr: 1, color: theme.palette.error.main }} />
                        Expense
                      </Box>
                    </MenuItem>
                    <MenuItem value="transfer">
                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <TransferIcon sx={{ mr: 1, color: theme.palette.info.main }} />
                        Transfer
                      </Box>
                    </MenuItem>
                    <MenuItem value="investment">
                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <AccountBalanceIcon sx={{ mr: 1, color: theme.palette.warning.main }} />
                        Investment
                      </Box>
                    </MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              
              <Grid item xs={12} sm={6}>
                <FormControl fullWidth disabled={dialogMode === 'view'}>
                  <InputLabel>Account</InputLabel>
                  <Select
                    name="account"
                    value={formData.account}
                    onChange={handleInputChange}
                    label="Account"
                    sx={{ borderRadius: 8 }}
                    startAdornment={
                      <InputAdornment position="start">
                        {getAccountIcon(formData.account)}
                      </InputAdornment>
                    }
                  >
                    <MenuItem value="main">
                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <WalletIcon sx={{ mr: 1, color: theme.palette.primary.main }} />
                        Main
                      </Box>
                    </MenuItem>
                    <MenuItem value="savings">
                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <AccountBalanceIcon sx={{ mr: 1, color: theme.palette.success.main }} />
                        Savings
                      </Box>
                    </MenuItem>
                    <MenuItem value="investment">
                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <AccountBalanceIcon sx={{ mr: 1, color: theme.palette.warning.main }} />
                        Investment
                      </Box>
                    </MenuItem>
                    <MenuItem value="petty-cash">
                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <PaymentIcon sx={{ mr: 1, color: theme.palette.secondary.main }} />
                        Petty Cash
                      </Box>
                    </MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Description"
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  disabled={dialogMode === 'view'}
                  required
                  sx={{ 
                    '& .MuiOutlinedInput-root': {
                      borderRadius: 4
                    }
                  }}
                />
              </Grid>
              
              <Grid item xs={12} sm={6}>
                <TextField
                  fullWidth
                  label="Amount"
                  name="amount"
                  type="number"
                  value={formData.amount}
                  onChange={handleInputChange}
                  disabled={dialogMode === 'view'}
                  required
                  inputProps={{ min: 0, step: 0.01 }}
                  InputProps={{
                    startAdornment: <InputAdornment position="start">RM</InputAdornment>,
                    sx: { borderRadius: 4 }
                  }}
                />
              </Grid>
              
              <Grid item xs={12} sm={6}>
                <DatePicker
                  label="Date"
                  value={formData.date}
                  onChange={handleDateChange}
                  disabled={dialogMode === 'view'}
                  renderInput={(params) => 
                    <TextField 
                      {...params} 
                      fullWidth
                      InputProps={{
                        ...params.InputProps,
                        sx: { borderRadius: 4 }
                      }}
                    />
                  }
                />
              </Grid>
              
              <Grid item xs={12}>
                <FormControl fullWidth disabled={dialogMode === 'view'}>
                  <InputLabel>Category</InputLabel>
                  <Select
                    name="category"
                    value={formData.category}
                    onChange={handleInputChange}
                    label="Category"
                    sx={{ borderRadius: 4 }}
                  >
                    {getCategoryOptions().map((category) => (
                      <MenuItem key={category} value={category}>
                        {category}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
              
              {/* Display asset checkbox only for relevant expense categories */}
              {formData.type === 'expense' && canBeAsset(formData.category) && (
                <Grid item xs={12}>
                  <Paper 
                    elevation={0} 
                    sx={{ 
                      p: 2, 
                      borderRadius: 4, 
                      bgcolor: theme.palette.mode === 'dark' ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.02)'
                    }}
                  >
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={formData.isAsset}
                          onChange={handleAssetToggle}
                          name="isAsset"
                          color="primary"
                          disabled={dialogMode === 'view'}
                        />
                      }
                      label="Record as an asset (for items that have long-term value)"
                    />
                  </Paper>
                </Grid>
              )}
              
              {/* Asset-specific fields when isAsset is true */}
              {formData.type === 'expense' && formData.isAsset && (
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth
                    label="Depreciation Rate (%)"
                    name="assetDepreciationRate"
                    type="number"
                    value={formData.assetDepreciationRate}
                    onChange={handleInputChange}
                    disabled={dialogMode === 'view'}
                    inputProps={{ min: 0, max: 100, step: 0.1 }}
                    helperText="Annual depreciation rate (0-100%)"
                    InputProps={{
                      sx: { borderRadius: 4 }
                    }}
                  />
                </Grid>
              )}
              
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Notes"
                  name="notes"
                  value={formData.notes}
                  onChange={handleInputChange}
                  disabled={dialogMode === 'view'}
                  multiline
                  rows={3}
                  InputProps={{
                    sx: { borderRadius: 4 }
                  }}
                />
              </Grid>

              {dialogMode === 'view' && (
                <Grid item xs={12}>
                  <Box sx={{ 
                    mt: 2,
                    p: 2,
                    borderRadius: 2,
                    bgcolor: theme.palette.mode === 'dark' ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.02)'
                  }}>
                    <Typography variant="body2" color="text.secondary" gutterBottom>
                      Created: {formatDate(currentTransaction?.createdAt || new Date())}
                    </Typography>
                    {currentTransaction?.updatedAt && currentTransaction.updatedAt !== currentTransaction.createdAt && (
                      <Typography variant="body2" color="text.secondary">
                        Last Updated: {formatDate(currentTransaction.updatedAt)}
                      </Typography>
                    )}
                  </Box>
                </Grid>
              )}
            </Grid>
          </DialogContent>
          
          <DialogActions sx={{ px: 3, pb: 3 }}>
            <Button 
              onClick={handleDialogClose} 
              color="primary"
              sx={{ borderRadius: 8 }}
            >
              {dialogMode === 'view' ? 'Close' : 'Cancel'}
            </Button>
            {dialogMode !== 'view' && (
              <Button
                onClick={handleSubmit}
                color="primary"
                variant="contained"
                disabled={!formData.description || !formData.amount || !formData.category}
                startIcon={dialogMode === 'add' ? <AddIcon /> : <SaveIcon />}
                sx={{ borderRadius: 8 }}
              >
                {dialogMode === 'add' ? 'Add' : 'Save'}
              </Button>
            )}
            {dialogMode === 'view' && (
              <Button
                onClick={() => {
                  handleDialogClose();
                  handleEditClick(currentTransaction);
                }}
                color="primary"
                variant="contained"
                startIcon={<EditIcon />}
                sx={{ borderRadius: 8 }}
              >
                Edit
              </Button>
            )}
          </DialogActions>
        </Dialog>

        {/* Delete Confirmation Dialog */}
        <Dialog 
          open={openDeleteDialog} 
          onClose={handleDeleteDialogClose}
          PaperProps={{
            sx: {
              borderRadius: 4,
              overflow: 'hidden'
            }
          }}
          TransitionComponent={Transition}
        >
          <DialogTitle sx={{ 
            bgcolor: theme.palette.error.light, 
            color: theme.palette.error.contrastText,
            fontWeight: 'medium'
          }}>
            Confirm Delete
          </DialogTitle>
          <DialogContent sx={{ py: 3 }}>
            <Typography variant="body1" gutterBottom>
              Are you sure you want to delete this transaction?
            </Typography>
            {transactionToDelete && (
              <Paper 
                elevation={0}
                sx={{ 
                  p: 2, 
                  mt: 2, 
                  bgcolor: theme.palette.mode === 'dark' ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.02)',
                  borderRadius: 2
                }}
              >
                <Grid container spacing={1}>
                  <Grid item xs={4}>
                    <Typography variant="body2" color="text.secondary">Description:</Typography>
                  </Grid>
                  <Grid item xs={8}>
                    <Typography variant="body2">{transactionToDelete.description}</Typography>
                  </Grid>
                  <Grid item xs={4}>
                    <Typography variant="body2" color="text.secondary">Amount:</Typography>
                  </Grid>
                  <Grid item xs={8}>
                    <Typography variant="body2" sx={{ 
                      fontWeight: 'bold',
                      color: transactionToDelete.type === 'expense' ? 'error.main' : 
                            transactionToDelete.type === 'income' ? 'success.main' : 'inherit'
                    }}>
                      {formatCurrency(transactionToDelete.amount)}
                    </Typography>
                  </Grid>
                  <Grid item xs={4}>
                    <Typography variant="body2" color="text.secondary">Date:</Typography>
                  </Grid>
                  <Grid item xs={8}>
                    <Typography variant="body2">{formatDate(transactionToDelete.date)}</Typography>
                  </Grid>
                  <Grid item xs={4}>
                    <Typography variant="body2" color="text.secondary">Type:</Typography>
                  </Grid>
                  <Grid item xs={8}>
                    <Chip 
                      label={transactionToDelete.type}
                      size="small"
                      color={getTypeColor(transactionToDelete.type)}
                      sx={{ borderRadius: 8 }}
                    />
                  </Grid>
                </Grid>
              </Paper>
            )}
          </DialogContent>
          <DialogActions sx={{ px: 3, pb: 3 }}>
            <Button 
              onClick={handleDeleteDialogClose} 
              startIcon={<CloseIcon />}
              sx={{ borderRadius: 8 }}
            >
              Cancel
            </Button>
            <Button
              onClick={handleDeleteConfirm}
              color="error"
              variant="contained"
              startIcon={<DeleteIcon />}
              sx={{ borderRadius: 8 }}
            >
              Delete
            </Button>
          </DialogActions>
        </Dialog>
      </Box>
    </LocalizationProvider>
  );
} 